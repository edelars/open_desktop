
/private/tmp/s507-stage5-bench/target-candidate/release/deps/od_machine-533ce3e3cf110c1e:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004ef200 <od_machine::page_walk::walk_long64_4k_with_writer>:
1004ef200:     	stp	x28, x27, [sp, #-0x60]!
1004ef204:     	stp	x26, x25, [sp, #0x10]
1004ef208:     	stp	x24, x23, [sp, #0x20]
1004ef20c:     	stp	x22, x21, [sp, #0x30]
1004ef210:     	stp	x20, x19, [sp, #0x40]
1004ef214:     	stp	x29, x30, [sp, #0x50]
1004ef218:     	add	x29, sp, #0x50
1004ef21c:     	sub	sp, sp, #0x220
1004ef220:     	str	x7, [sp, #0x90]
1004ef224:     	mov	x19, x8
1004ef228:     	mov	w8, #0xff               ; =255
1004ef22c:     	strb	w8, [sp, #0xba]
1004ef230:     	strb	w8, [sp, #0xd2]
1004ef234:     	strb	w8, [sp, #0xea]
1004ef238:     	strb	w8, [sp, #0x102]
1004ef23c:     	str	xzr, [sp, #0x108]
1004ef240:     	mov	w8, #0x2                ; =2
1004ef244:     	strb	w8, [sp, #0x129]
1004ef248:     	lsr	x9, x3, #48
1004ef24c:     	sbfx	x10, x3, #47, #1
1004ef250:     	strb	w8, [sp, #0x149]
1004ef254:     	strb	w8, [sp, #0x169]
1004ef258:     	cmp	x9, w10, uxth
1004ef25c:     	add	x9, sp, #0x110
1004ef260:     	strb	w8, [sp, #0x189]
1004ef264:     	b.ne	 <L17>
1004ef268:     	str	x2, [sp, #0x10]
1004ef26c:     	stp	w4, w5, [sp, #0x18]
1004ef270:     	str	w6, [sp, #0x2c]
1004ef274:     	str	wzr, [sp, #0xa4]
1004ef278:     	str	xzr, [sp, #0x58]
1004ef27c:     	mov	w2, #0x0                ; =0
1004ef280:     	mov	x28, #0x0               ; =0
1004ef284:     	ldrb	w8, [x29, #0x28]
1004ef288:     	str	w8, [sp, #0xa0]
1004ef28c:     	ldp	x9, x8, [x29, #0x18]
1004ef290:     	str	x9, [sp, #0x50]
1004ef294:     	ldr	x9, [x29, #0x10]
1004ef298:     	str	x9, [sp, #0x48]
1004ef29c:     	ldr	x9, [x1, #0x8]
1004ef2a0:     	stur	xzr, [x29, #-0xe0]
1004ef2a4:     	stur	xzr, [x29, #-0xd0]
1004ef2a8:     	stur	xzr, [x29, #-0xc0]
1004ef2ac:     	stur	xzr, [x29, #-0xb0]
1004ef2b0:     	and	x15, x9, #0xffffff000
1004ef2b4:     	mov	w9, #0x4                ; =4
1004ef2b8:     	sub	x10, x29, #0xa0
1004ef2bc:     	add	x10, x10, #0x10
1004ef2c0:     	str	x10, [sp, #0x70]
1004ef2c4:     	mov	w10, #0x100             ; =256
1004ef2c8:     	movk	w10, #0x302, lsl #16
1004ef2cc:     	str	x1, [sp, #0x8]
1004ef2d0:     	ldr	x11, [x1, #0x18]
1004ef2d4:     	str	x11, [sp, #0x20]
1004ef2d8:     	tst	x11, #0x800
1004ef2dc:     	mov	x11, #0xfff000000000    ; =281406257233920
1004ef2e0:     	movk	x11, #0x800f, lsl #48
1004ef2e4:     	stur	x9, [x29, #-0x98]
1004ef2e8:     	stur	w10, [x29, #-0x90]
1004ef2ec:     	mov	x9, #0xffff000000000    ; =4503530907893760
1004ef2f0:     	csel	x9, x9, x11, ne
1004ef2f4:     	str	x9, [sp, #0x98]
1004ef2f8:     	mov	w22, #0x58              ; =88
1004ef2fc:     	stur	xzr, [x29, #-0x88]
1004ef300:     	mov	w1, #0x1                ; =1
1004ef304:     	mov	w16, #0x1               ; =1
1004ef308:     	ldr	x8, [x8, #0x20]
1004ef30c:     	str	x8, [sp, #0x40]
1004ef310:     	str	x3, [sp, #0x30]
<L0>:
1004ef314:     	ldr	x8, [sp, #0x70]
1004ef318:     	ldrb	w24, [x8, x28]
1004ef31c:     	sub	x8, x29, #0xe0
1004ef320:     	add	x8, x8, x28, lsl #4
1004ef324:     	mov	w9, #0x1                ; =1
1004ef328:     	stp	x9, x15, [x8]
1004ef32c:     	orr	x8, x24, x24, lsl #3
1004ef330:     	mov	w9, #0x27               ; =39
1004ef334:     	sub	x8, x9, x8
1004ef338:     	lsr	x20, x3, x8
1004ef33c:     	ubfiz	x8, x20, #3, #9
1004ef340:     	orr	x26, x8, x15
1004ef344:     	ldp	x8, x9, [x0, #0x8]
1004ef348:     	adds	x21, x26, #0x8
1004ef34c:     	cset	w25, hs
1004ef350:     	cbz	x9,  <L1>
1004ef354:     	cmp	x9, #0x1
1004ef358:     	b.ne	 <L2>
1004ef35c:     	mov	x10, #0x0               ; =0
1004ef360:     	b	 <L4>
<L1>:
1004ef364:     	mov	x10, x9
1004ef368:     	b	 <L5>
<L2>:
1004ef36c:     	mov	x10, #0x0               ; =0
1004ef370:     	mov	x11, x9
<L3>:
1004ef374:     	lsr	x12, x11, #1
1004ef378:     	add	x13, x12, x10
1004ef37c:     	madd	x14, x13, x22, x8
1004ef380:     	ldr	x14, [x14, #0x40]
1004ef384:     	cmp	x14, x26
1004ef388:     	csel	x10, x10, x13, hi
1004ef38c:     	sub	x11, x11, x12
1004ef390:     	cmp	x11, #0x1
1004ef394:     	b.hi	 <L3>
<L4>:
1004ef398:     	madd	x11, x10, x22, x8
1004ef39c:     	ldr	x11, [x11, #0x40]
1004ef3a0:     	cmp	x11, x26
1004ef3a4:     	b.eq	 <L5>
1004ef3a8:     	cinc	x10, x10, lo
1004ef3ac:     	subs	x10, x10, #0x1
1004ef3b0:     	csel	x10, xzr, x10, lo
<L5>:
1004ef3b4:     	cmp	x10, x9
1004ef3b8:     	b.hs	 <L18>
1004ef3bc:     	madd	x8, x10, x22, x8
1004ef3c0:     	ldr	x9, [x8, #0x40]
1004ef3c4:     	cmp	x26, x9
1004ef3c8:     	b.lo	 <L18>
1004ef3cc:     	ldr	x10, [x8, #0x48]
1004ef3d0:     	adds	x10, x10, x9
1004ef3d4:     	cset	w9, hs
1004ef3d8:     	cmp	x10, x21
1004ef3dc:     	sbcs	xzr, x9, x25
1004ef3e0:     	b.lo	 <L19>
1004ef3e4:     	ldrb	w8, [x8, #0x50]
1004ef3e8:     	cmp	w8, #0x4
1004ef3ec:     	b.eq	 <L21>
1004ef3f0:     	stp	w16, w1, [sp, #0x78]
1004ef3f4:     	str	x15, [sp, #0x80]
1004ef3f8:     	str	w8, [sp, #0xa4]
1004ef3fc:     	str	w2, [sp, #0x8c]
1004ef400:     	sub	x8, x29, #0x80
1004ef404:     	mov	x27, x0
1004ef408:     	mov	x1, x26
1004ef40c:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004ef410:     	ldurb	w8, [x29, #-0x80]
1004ef414:     	cmp	w8, #0xff
1004ef418:     	b.ne	 <L23>
1004ef41c:     	ldr	x0, [sp, #0x108]
1004ef420:     	cmp	x0, #0x3
1004ef424:     	b.hi	 <L41>
1004ef428:     	and	w20, w20, #0x1ff
1004ef42c:     	ldur	x23, [x29, #-0x78]
1004ef430:     	mov	w8, #0x18               ; =24
1004ef434:     	add	x9, sp, #0xa8
1004ef438:     	madd	x8, x0, x8, x9
1004ef43c:     	stp	x26, x23, [x8]
1004ef440:     	strh	w20, [x8, #0x10]
1004ef444:     	strb	w24, [x8, #0x12]
1004ef448:     	ldr	x8, [sp, #0x108]
1004ef44c:     	add	x8, x8, #0x1
1004ef450:     	str	x8, [sp, #0x108]
1004ef454:     	tbz	w23, #0x0,  <L24>
1004ef458:     	stp	x25, x21, [sp, #0x60]
1004ef45c:     	cmp	w24, #0x2
1004ef460:     	cset	w9, ne
1004ef464:     	ands	x8, x23, #0x80
1004ef468:     	csinc	w25, w9, wzr, ne
1004ef46c:     	ldr	w9, [sp, #0xa0]
1004ef470:     	tbnz	w9, #0x0,  <L6>
1004ef474:     	cbz	w25,  <L25>
<L6>:
1004ef478:     	ldr	x9, [sp, #0x98]
1004ef47c:     	and	x9, x23, x9
1004ef480:     	cmp	w24, #0x2
1004ef484:     	csel	x8, x8, xzr, lo
1004ef488:     	and	x10, x23, #0x1fe000
1004ef48c:     	cmp	w25, #0x0
1004ef490:     	csel	x10, xzr, x10, ne
1004ef494:     	orr	x8, x8, x9
1004ef498:     	orr	x8, x8, x10
1004ef49c:     	cbnz	x8,  <L26>
1004ef4a0:     	tbnz	w23, #0x5,  <L13>
1004ef4a4:     	str	x24, [sp, #0x38]
1004ef4a8:     	orr	x24, x23, #0x20
1004ef4ac:     	sub	x8, x29, #0x80
1004ef4b0:     	orr	x4, x23, #0x20
1004ef4b4:     	ldp	x6, x0, [sp, #0x48]
1004ef4b8:     	mov	x1, x27
1004ef4bc:     	mov	x2, x26
1004ef4c0:     	mov	x3, x23
1004ef4c4:     	ldr	x5, [sp, #0x90]
1004ef4c8:     	ldr	x9, [sp, #0x40]
1004ef4cc:     	blr	x9
1004ef4d0:     	ldurb	w8, [x29, #-0x80]
1004ef4d4:     	cmp	w8, #0xff
1004ef4d8:     	b.ne	 <L28>
1004ef4dc:     	ldur	x8, [x29, #-0x78]
1004ef4e0:     	cbz	x8,  <L14>
1004ef4e4:     	mov	w21, #0x1               ; =1
1004ef4e8:     	ldr	x24, [sp, #0x38]
<L7>:
1004ef4ec:     	mov	x0, x27
1004ef4f0:     	ldp	x8, x9, [x27, #0x8]
1004ef4f4:     	cbz	x9,  <L10>
1004ef4f8:     	cmp	x9, #0x1
1004ef4fc:     	ldp	x16, x15, [sp, #0x60]
1004ef500:     	mov	x10, #0x0               ; =0
1004ef504:     	b.eq	 <L9>
1004ef508:     	mov	x11, x9
<L8>:
1004ef50c:     	lsr	x12, x11, #1
1004ef510:     	add	x13, x12, x10
1004ef514:     	madd	x14, x13, x22, x8
1004ef518:     	ldr	x14, [x14, #0x40]
1004ef51c:     	cmp	x14, x26
1004ef520:     	csel	x10, x10, x13, hi
1004ef524:     	sub	x11, x11, x12
1004ef528:     	cmp	x11, #0x1
1004ef52c:     	b.hi	 <L8>
<L9>:
1004ef530:     	madd	x11, x10, x22, x8
1004ef534:     	ldr	x11, [x11, #0x40]
1004ef538:     	cmp	x11, x26
1004ef53c:     	b.eq	 <L11>
1004ef540:     	cinc	x10, x10, lo
1004ef544:     	subs	x10, x10, #0x1
1004ef548:     	csel	x10, xzr, x10, lo
1004ef54c:     	b	 <L11>
<L10>:
1004ef550:     	mov	x10, x9
1004ef554:     	ldp	x16, x15, [sp, #0x60]
<L11>:
1004ef558:     	cmp	x10, x9
1004ef55c:     	b.hs	 <L18>
1004ef560:     	madd	x8, x10, x22, x8
1004ef564:     	ldr	x9, [x8, #0x40]
1004ef568:     	cmp	x26, x9
1004ef56c:     	b.lo	 <L18>
1004ef570:     	ldr	x10, [x8, #0x48]
1004ef574:     	adds	x10, x10, x9
1004ef578:     	cset	w9, hs
1004ef57c:     	cmp	x10, x15
1004ef580:     	sbcs	xzr, x9, x16
1004ef584:     	b.lo	 <L19>
1004ef588:     	ldrb	w8, [x8, #0x50]
1004ef58c:     	cmp	w8, #0x4
1004ef590:     	b.eq	 <L21>
1004ef594:     	str	w8, [sp, #0xa4]
1004ef598:     	sub	x8, x29, #0x80
1004ef59c:     	mov	x1, x26
1004ef5a0:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004ef5a4:     	ldurb	w8, [x29, #-0x80]
1004ef5a8:     	cmp	w8, #0xff
1004ef5ac:     	b.ne	 <L23>
1004ef5b0:     	ldr	x8, [sp, #0x108]
1004ef5b4:     	sub	x0, x8, #0x1
1004ef5b8:     	cmp	x0, #0x4
1004ef5bc:     	b.hs	 <L42>
1004ef5c0:     	ldur	x23, [x29, #-0x78]
1004ef5c4:     	mov	w8, #0x18               ; =24
1004ef5c8:     	add	x9, sp, #0xa8
1004ef5cc:     	madd	x8, x0, x8, x9
1004ef5d0:     	stp	x26, x23, [x8]
1004ef5d4:     	strh	w20, [x8, #0x10]
1004ef5d8:     	strb	w24, [x8, #0x12]
1004ef5dc:     	tbz	w23, #0x0,  <L24>
1004ef5e0:     	cmp	w24, #0x2
1004ef5e4:     	cset	w9, ne
1004ef5e8:     	ands	x8, x23, #0x80
1004ef5ec:     	csinc	w25, w9, wzr, ne
1004ef5f0:     	ldr	w9, [sp, #0xa0]
1004ef5f4:     	tbnz	w9, #0x0,  <L12>
1004ef5f8:     	cbz	w25,  <L25>
<L12>:
1004ef5fc:     	ldr	x9, [sp, #0x98]
1004ef600:     	and	x9, x23, x9
1004ef604:     	cmp	w24, #0x2
1004ef608:     	csel	x8, x8, xzr, lo
1004ef60c:     	and	x10, x23, #0x1fe000
1004ef610:     	cmp	w25, #0x0
1004ef614:     	csel	x10, xzr, x10, ne
1004ef618:     	orr	x8, x8, x9
1004ef61c:     	orr	x8, x8, x10
1004ef620:     	cbnz	x8,  <L26>
1004ef624:     	tbnz	w23, #0x5,  <L13>
1004ef628:     	orr	x24, x23, #0x20
1004ef62c:     	sub	x8, x29, #0x80
1004ef630:     	orr	x4, x23, #0x20
1004ef634:     	ldp	x6, x0, [sp, #0x48]
1004ef638:     	mov	x1, x27
1004ef63c:     	mov	x2, x26
1004ef640:     	mov	x3, x23
1004ef644:     	ldr	x5, [sp, #0x90]
1004ef648:     	ldr	x9, [sp, #0x40]
1004ef64c:     	blr	x9
1004ef650:     	ldurb	w8, [x29, #-0x80]
1004ef654:     	cmp	w8, #0xff
1004ef658:     	b.ne	 <L28>
1004ef65c:     	ldur	x8, [x29, #-0x78]
1004ef660:     	cbz	x8,  <L14>
1004ef664:     	cmp	w21, #0x10
1004ef668:     	add	w21, w21, #0x1
1004ef66c:     	ldr	x24, [sp, #0x38]
1004ef670:     	b.ne	 <L7>
1004ef674:     	b	 <L31>
<L13>:
1004ef678:     	ldr	x3, [sp, #0x30]
1004ef67c:     	ldr	w2, [sp, #0x8c]
1004ef680:     	b	 <L15>
<L14>:
1004ef684:     	ldr	x0, [sp, #0x58]
1004ef688:     	cmp	x0, #0x3
1004ef68c:     	ldr	x3, [sp, #0x30]
1004ef690:     	ldr	w2, [sp, #0x8c]
1004ef694:     	b.hi	 <L43>
1004ef698:     	add	x8, sp, #0x110
1004ef69c:     	add	x8, x8, x0, lsl #5
1004ef6a0:     	stp	x26, x23, [x8]
1004ef6a4:     	str	x24, [x8, #0x10]
1004ef6a8:     	ldr	x24, [sp, #0x38]
1004ef6ac:     	strb	w24, [x8, #0x18]
1004ef6b0:     	strb	wzr, [x8, #0x19]
1004ef6b4:     	add	x0, x0, #0x1
1004ef6b8:     	str	x0, [sp, #0x58]
<L15>:
1004ef6bc:     	mov	x0, x27
1004ef6c0:     	ubfx	x8, x23, #2, #1
1004ef6c4:     	ldp	w16, w1, [sp, #0x78]
1004ef6c8:     	and	w16, w16, w8
1004ef6cc:     	ubfx	x8, x23, #1, #1
1004ef6d0:     	and	w1, w1, w8
1004ef6d4:     	lsr	x8, x23, #63
1004ef6d8:     	orr	w2, w2, w8
1004ef6dc:     	ldr	x15, [sp, #0x80]
1004ef6e0:     	tbz	w25, #0x0,  <L16>
1004ef6e4:     	add	x28, x28, #0x1
1004ef6e8:     	and	x8, x23, #0xffffff000
1004ef6ec:     	cmp	w24, #0x3
1004ef6f0:     	csel	x15, x15, x8, eq
1004ef6f4:     	cmp	x28, #0x4
1004ef6f8:     	b.ne	 <L0>
<L16>:
1004ef6fc:     	ldp	w0, w17, [sp, #0x18]
1004ef700:     	and	w8, w0, #0xff
1004ef704:     	cmp	w8, #0x2
1004ef708:     	and	w8, w17, #0xff
1004ef70c:     	ccmp	w8, #0x3, #0x0, ne
1004ef710:     	cset	w9, eq
1004ef714:     	b.ne	 <L29>
1004ef718:     	eor	w8, w16, #0x1
1004ef71c:     	ldr	w16, [sp, #0x2c]
1004ef720:     	and	w10, w16, #0xff
1004ef724:     	cmp	w10, #0x2
1004ef728:     	cset	w10, ne
1004ef72c:     	orr	w10, w10, w1
1004ef730:     	add	x15, sp, #0x110
1004ef734:     	tbnz	w10, #0x0,  <L30>
1004ef738:     	mov	w2, #0x0                ; =0
1004ef73c:     	mov	w10, #0x1               ; =1
1004ef740:     	ldr	x12, [sp, #0x20]
1004ef744:     	b	 <L35>
<L17>:
1004ef748:     	adrp	x8, 0x10082c000 <_anon.46955161eb1c9d064970950154d48426.3215+0x6c0>
1004ef74c:     	ldr	q0, [x8, #0x930]
1004ef750:     	str	q0, [x19]
1004ef754:     	str	x3, [x19, #0x10]
1004ef758:     	ldur	q0, [sp, #0xe8]
1004ef75c:     	ldur	q1, [sp, #0xf8]
1004ef760:     	stp	q0, q1, [x19, #0x120]
1004ef764:     	ldr	x8, [sp, #0x108]
1004ef768:     	ldur	q0, [sp, #0xa8]
1004ef76c:     	ldur	q1, [sp, #0xb8]
1004ef770:     	stp	q0, q1, [x19, #0xe0]
1004ef774:     	ldur	q0, [sp, #0xc8]
1004ef778:     	ldur	q1, [sp, #0xd8]
1004ef77c:     	stp	q0, q1, [x19, #0x100]
1004ef780:     	ldp	q0, q1, [sp, #0x110]
1004ef784:     	ldp	q2, q3, [x9, #0x20]
1004ef788:     	stp	q2, q3, [x19, #0x80]
1004ef78c:     	stp	q0, q1, [x19, #0x60]
1004ef790:     	ldp	q0, q1, [x9, #0x40]
1004ef794:     	ldp	q2, q3, [x9, #0x60]
1004ef798:     	stp	q2, q3, [x19, #0xc0]
1004ef79c:     	stp	q0, q1, [x19, #0xa0]
1004ef7a0:     	stp	x8, xzr, [x19, #0x140]
1004ef7a4:     	b	 <L40>
<L18>:
1004ef7a8:     	mov	w8, #0xa                ; =10
1004ef7ac:     	b	 <L20>
<L19>:
1004ef7b0:     	cmp	x26, x10
1004ef7b4:     	ngcs	xzr, x9
1004ef7b8:     	cset	w8, lo
1004ef7bc:     	cmp	w8, #0x0
1004ef7c0:     	mov	w8, #0xa                ; =10
1004ef7c4:     	cinc	w8, w8, ne
<L20>:
1004ef7c8:     	mov	w9, #0x8                ; =8
1004ef7cc:     	stp	x26, x9, [x29, #-0x78]
1004ef7d0:     	ldr	w9, [sp, #0xa4]
1004ef7d4:     	b	 <L22>
<L21>:
1004ef7d8:     	mov	w9, #0x4                ; =4
1004ef7dc:     	mov	w8, #0xc                ; =12
<L22>:
1004ef7e0:     	sturb	w8, [x29, #-0x80]
1004ef7e4:     	sturb	w9, [x29, #-0x7f]
<L23>:
1004ef7e8:     	add	x9, sp, #0x110
1004ef7ec:     	ldp	q0, q1, [x9, #0xe0]
1004ef7f0:     	stp	q0, q1, [x19, #0x10]
1004ef7f4:     	adrp	x8, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef7f8:     	ldr	q1, [x8, #0xe80]
1004ef7fc:     	ldur	x8, [x29, #-0x60]
1004ef800:     	str	q1, [x19]
1004ef804:     	stp	x8, x26, [x19, #0x30]
1004ef808:     	strb	w24, [x19, #0x40]
1004ef80c:     	ldur	q0, [sp, #0xe8]
1004ef810:     	ldur	q1, [sp, #0xf8]
1004ef814:     	stp	q0, q1, [x19, #0x120]
1004ef818:     	ldr	x8, [sp, #0x108]
1004ef81c:     	ldur	q0, [sp, #0xa8]
1004ef820:     	ldur	q1, [sp, #0xb8]
1004ef824:     	stp	q0, q1, [x19, #0xe0]
1004ef828:     	ldur	q0, [sp, #0xc8]
1004ef82c:     	ldur	q1, [sp, #0xd8]
1004ef830:     	stp	q0, q1, [x19, #0x100]
1004ef834:     	ldp	q1, q0, [x9, #0x60]
1004ef838:     	stp	q1, q0, [x19, #0xc0]
1004ef83c:     	ldp	q1, q0, [x9, #0x40]
1004ef840:     	stp	q1, q0, [x19, #0xa0]
1004ef844:     	ldp	q1, q0, [x9, #0x20]
1004ef848:     	stp	q1, q0, [x19, #0x80]
1004ef84c:     	ldp	q1, q0, [sp, #0x110]
1004ef850:     	stp	q1, q0, [x19, #0x60]
1004ef854:     	b	 <L39>
<L24>:
1004ef858:     	adrp	x8, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef85c:     	ldr	q0, [x8, #0xcd0]
1004ef860:     	ldr	x8, [sp, #0x20]
1004ef864:     	ubfx	x8, x8, #11, #1
1004ef868:     	ldp	w15, w14, [sp, #0x18]
1004ef86c:     	and	w9, w15, #0xff
1004ef870:     	str	q0, [x19]
1004ef874:     	ldr	w13, [sp, #0x2c]
1004ef878:     	ands	w10, w13, #0xff
1004ef87c:     	cset	w11, eq
1004ef880:     	ldr	x12, [sp, #0x30]
1004ef884:     	str	x12, [x19, #0x10]
1004ef888:     	cmp	w10, #0x2
1004ef88c:     	csel	w10, w10, wzr, eq
1004ef890:     	and	w12, w14, #0xff
1004ef894:     	cmp	w12, #0x3
1004ef898:     	ccmp	w9, #0x2, #0x4, eq
1004ef89c:     	mov	w9, #0x4                ; =4
1004ef8a0:     	csel	w9, w9, wzr, ne
1004ef8a4:     	orr	w9, w10, w9
1004ef8a8:     	tst	w11, w8
1004ef8ac:     	mov	w8, #0x10               ; =16
1004ef8b0:     	csel	w8, w8, wzr, ne
1004ef8b4:     	orr	w8, w9, w8
1004ef8b8:     	mov	w9, #0x1                ; =1
1004ef8bc:     	stp	w9, w8, [x19, #0x18]
1004ef8c0:     	mov	w8, #0xe                ; =14
1004ef8c4:     	strb	w8, [x19, #0x20]
1004ef8c8:     	ldr	x8, [sp, #0x10]
1004ef8cc:     	str	x8, [x19, #0x28]
1004ef8d0:     	strb	w15, [x19, #0x30]
1004ef8d4:     	strb	w14, [x19, #0x31]
1004ef8d8:     	strb	w13, [x19, #0x32]
1004ef8dc:     	strb	wzr, [x19, #0x38]
1004ef8e0:     	strb	w24, [x19, #0x39]
1004ef8e4:     	b	 <L27>
<L25>:
1004ef8e8:     	adrp	x8, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef8ec:     	ldr	q0, [x8, #0xfc0]
1004ef8f0:     	str	q0, [x19]
1004ef8f4:     	stp	x26, x23, [x19, #0x10]
1004ef8f8:     	mov	w8, #0x2                ; =2
1004ef8fc:     	strb	w8, [x19, #0x20]
1004ef900:     	b	 <L27>
<L26>:
1004ef904:     	ldr	x13, [sp, #0x30]
1004ef908:     	adrp	x9, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef90c:     	ldr	q0, [x9, #0xcd0]
1004ef910:     	ldr	x9, [sp, #0x20]
1004ef914:     	ubfx	x9, x9, #11, #1
1004ef918:     	ldp	w16, w15, [sp, #0x18]
1004ef91c:     	and	w10, w16, #0xff
1004ef920:     	str	q0, [x19]
1004ef924:     	ldr	w14, [sp, #0x2c]
1004ef928:     	ands	w11, w14, #0xff
1004ef92c:     	cset	w12, eq
1004ef930:     	str	x13, [x19, #0x10]
1004ef934:     	cmp	w11, #0x2
1004ef938:     	mov	w11, #0x3               ; =3
1004ef93c:     	csinc	w11, w11, wzr, eq
1004ef940:     	and	w13, w15, #0xff
1004ef944:     	tst	w12, w9
1004ef948:     	mov	w9, #0x10               ; =16
1004ef94c:     	csel	w9, w9, wzr, ne
1004ef950:     	cmp	w13, #0x3
1004ef954:     	ccmp	w10, #0x2, #0x4, eq
1004ef958:     	mov	w10, #0x8               ; =8
1004ef95c:     	mov	w12, #0xc               ; =12
1004ef960:     	csel	w10, w12, w10, ne
1004ef964:     	orr	w10, w10, w11
1004ef968:     	orr	w9, w10, w9
1004ef96c:     	mov	w10, #0x1               ; =1
1004ef970:     	stp	w10, w9, [x19, #0x18]
1004ef974:     	mov	w9, #0xe                ; =14
1004ef978:     	strb	w9, [x19, #0x20]
1004ef97c:     	ldr	x9, [sp, #0x10]
1004ef980:     	str	x9, [x19, #0x28]
1004ef984:     	strb	w16, [x19, #0x30]
1004ef988:     	strb	w15, [x19, #0x31]
1004ef98c:     	strb	w14, [x19, #0x32]
1004ef990:     	strb	w10, [x19, #0x38]
1004ef994:     	strb	w24, [x19, #0x39]
1004ef998:     	str	x8, [x19, #0x40]
<L27>:
1004ef99c:     	ldur	q0, [sp, #0xe8]
1004ef9a0:     	ldur	q1, [sp, #0xf8]
1004ef9a4:     	stp	q0, q1, [x19, #0x120]
1004ef9a8:     	ldr	x8, [sp, #0x108]
1004ef9ac:     	ldur	q0, [sp, #0xa8]
1004ef9b0:     	ldur	q1, [sp, #0xb8]
1004ef9b4:     	stp	q0, q1, [x19, #0xe0]
1004ef9b8:     	ldur	q0, [sp, #0xc8]
1004ef9bc:     	ldur	q1, [sp, #0xd8]
1004ef9c0:     	stp	q0, q1, [x19, #0x100]
1004ef9c4:     	add	x9, sp, #0x110
1004ef9c8:     	ldp	q0, q1, [x9, #0x40]
1004ef9cc:     	stp	q0, q1, [x19, #0xa0]
1004ef9d0:     	ldp	q0, q1, [x9, #0x60]
1004ef9d4:     	stp	q0, q1, [x19, #0xc0]
1004ef9d8:     	ldp	q0, q1, [sp, #0x110]
1004ef9dc:     	stp	q0, q1, [x19, #0x60]
1004ef9e0:     	ldp	q0, q1, [x9, #0x20]
1004ef9e4:     	b	 <L38>
<L28>:
1004ef9e8:     	add	x13, sp, #0x110
1004ef9ec:     	ldp	q0, q1, [x13, #0xe0]
1004ef9f0:     	stur	q0, [x19, #0x18]
1004ef9f4:     	stur	q1, [x19, #0x28]
1004ef9f8:     	ldur	x9, [x29, #-0x60]
1004ef9fc:     	mov	w10, #0x2               ; =2
1004efa00:     	mov	w8, #0x41               ; =65
1004efa04:     	str	x9, [x19, #0x38]
1004efa08:     	str	x10, [x19]
1004efa0c:     	mov	w10, #0x40              ; =64
1004efa10:     	mov	w11, #0x10              ; =16
1004efa14:     	mov	w9, #0x7                ; =7
1004efa18:     	mov	w12, #0x8               ; =8
1004efa1c:     	ldr	x24, [sp, #0x38]
1004efa20:     	b	 <L32>
<L29>:
1004efa24:     	ldr	w16, [sp, #0x2c]
1004efa28:     	and	w8, w16, #0xff
1004efa2c:     	cmp	w8, #0x2
1004efa30:     	cset	w8, ne
1004efa34:     	orr	w8, w8, w1
1004efa38:     	add	x15, sp, #0x110
1004efa3c:     	tbz	w8, #0x0,  <L33>
1004efa40:     	mov	w8, #0x0                ; =0
<L30>:
1004efa44:     	ldr	x12, [sp, #0x20]
1004efa48:     	mov	w10, #0x0               ; =0
1004efa4c:     	tst	w16, #0xff
1004efa50:     	b.ne	 <L34>
1004efa54:     	tbz	w12, #0xb,  <L34>
1004efa58:     	mov	w10, #0x0               ; =0
1004efa5c:     	tbnz	w8, #0x0,  <L35>
1004efa60:     	tbz	w2, #0x0,  <L36>
1004efa64:     	b	 <L35>
<L31>:
1004efa68:     	mov	x9, x26
1004efa6c:     	ldur	x26, [x29, #-0x70]
1004efa70:     	mov	w8, #0x21               ; =33
1004efa74:     	adrp	x10, 0x100839000 <_anon.ff0337c78e95b70e8401eb32eaf46e94.1617+0x43b>
1004efa78:     	ldr	q0, [x10, #0xa60]
1004efa7c:     	str	q0, [x19]
1004efa80:     	mov	w10, #0x20              ; =32
1004efa84:     	mov	w11, #0x18              ; =24
1004efa88:     	mov	w12, #0x10              ; =16
1004efa8c:     	add	x13, sp, #0x110
<L32>:
1004efa90:     	str	x9, [x19, x12]
1004efa94:     	str	x26, [x19, x11]
1004efa98:     	strb	w24, [x19, x10]
1004efa9c:     	strb	wzr, [x19, x8]
1004efaa0:     	ldur	q0, [sp, #0xe8]
1004efaa4:     	ldur	q1, [sp, #0xf8]
1004efaa8:     	stp	q0, q1, [x19, #0x120]
1004efaac:     	ldr	x8, [sp, #0x108]
1004efab0:     	ldur	q0, [sp, #0xa8]
1004efab4:     	ldur	q1, [sp, #0xb8]
1004efab8:     	stp	q0, q1, [x19, #0xe0]
1004efabc:     	ldur	q0, [sp, #0xc8]
1004efac0:     	ldur	q1, [sp, #0xd8]
1004efac4:     	stp	q0, q1, [x19, #0x100]
1004efac8:     	ldp	q0, q1, [sp, #0x110]
1004efacc:     	ldp	q2, q3, [x13, #0x20]
1004efad0:     	stp	q2, q3, [x19, #0x80]
1004efad4:     	stp	q0, q1, [x19, #0x60]
1004efad8:     	ldp	q0, q1, [x13, #0x40]
1004efadc:     	ldp	q2, q3, [x13, #0x60]
1004efae0:     	stp	q2, q3, [x19, #0xc0]
1004efae4:     	stp	q0, q1, [x19, #0xa0]
1004efae8:     	b	 <L39>
<L33>:
1004efaec:     	mov	w8, #0x0                ; =0
1004efaf0:     	ldr	x10, [sp, #0x8]
1004efaf4:     	ldr	w10, [x10]
1004efaf8:     	ubfx	w10, w10, #16, #1
1004efafc:     	ldr	x12, [sp, #0x20]
<L34>:
1004efb00:     	orr	w11, w8, w10
1004efb04:     	cbz	w11,  <L36>
1004efb08:     	mov	w2, #0x0                ; =0
<L35>:
1004efb0c:     	adrp	x11, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004efb10:     	ldr	q0, [x11, #0xcd0]
1004efb14:     	ubfx	x11, x12, #11, #1
1004efb18:     	ands	w12, w16, #0xff
1004efb1c:     	str	q0, [x19]
1004efb20:     	cset	w13, eq
1004efb24:     	cmp	w12, #0x2
1004efb28:     	str	x3, [x19, #0x10]
1004efb2c:     	mov	w12, #0x3               ; =3
1004efb30:     	csinc	w12, w12, wzr, eq
1004efb34:     	mov	w14, #0x4               ; =4
1004efb38:     	cmp	w9, #0x0
1004efb3c:     	csel	w9, w14, wzr, ne
1004efb40:     	tst	w13, w11
1004efb44:     	mov	w11, #0x10              ; =16
1004efb48:     	csel	w11, w11, wzr, ne
1004efb4c:     	orr	w11, w12, w11
1004efb50:     	orr	w9, w11, w9
1004efb54:     	mov	w11, #0x1               ; =1
1004efb58:     	stp	w11, w9, [x19, #0x18]
1004efb5c:     	mov	w9, #0xe                ; =14
1004efb60:     	strb	w9, [x19, #0x20]
1004efb64:     	ldr	x9, [sp, #0x10]
1004efb68:     	str	x9, [x19, #0x28]
1004efb6c:     	strb	w0, [x19, #0x30]
1004efb70:     	strb	w17, [x19, #0x31]
1004efb74:     	strb	w16, [x19, #0x32]
1004efb78:     	mov	w9, #0x2                ; =2
1004efb7c:     	strb	w9, [x19, #0x38]
1004efb80:     	strb	w8, [x19, #0x39]
1004efb84:     	strb	w10, [x19, #0x3a]
1004efb88:     	strb	w2, [x19, #0x3b]
1004efb8c:     	ldur	q0, [sp, #0xe8]
1004efb90:     	ldur	q1, [sp, #0xf8]
1004efb94:     	stp	q0, q1, [x19, #0x120]
1004efb98:     	ldr	x8, [sp, #0x108]
1004efb9c:     	ldur	q0, [sp, #0xa8]
1004efba0:     	ldur	q1, [sp, #0xb8]
1004efba4:     	stp	q0, q1, [x19, #0xe0]
1004efba8:     	ldur	q0, [sp, #0xc8]
1004efbac:     	ldur	q1, [sp, #0xd8]
1004efbb0:     	stp	q0, q1, [x19, #0x100]
1004efbb4:     	b	 <L37>
<L36>:
1004efbb8:     	orr	x8, x23, #0x20
1004efbbc:     	cmp	w25, #0x0
1004efbc0:     	mov	w9, #0x1fffff           ; =2097151
1004efbc4:     	ldp	q0, q1, [x15, #0x80]
1004efbc8:     	mov	w10, #0xfff             ; =4095
1004efbcc:     	csel	x9, x10, x9, ne
1004efbd0:     	and	x10, x9, #0x1ff000
1004efbd4:     	eor	x10, x10, #0xffffff000
1004efbd8:     	stp	q0, q1, [x19]
1004efbdc:     	and	x10, x10, x23
1004efbe0:     	and	x9, x9, x3
1004efbe4:     	orr	x9, x10, x9
1004efbe8:     	mov	w10, #0x2               ; =2
1004efbec:     	ldp	q0, q1, [x15, #0xa0]
1004efbf0:     	cinc	w10, w10, ne
1004efbf4:     	stp	q0, q1, [x19, #0x20]
1004efbf8:     	stp	x9, x26, [x19, #0x40]
1004efbfc:     	str	x8, [x19, #0x50]
1004efc00:     	strb	w10, [x19, #0x58]
1004efc04:     	ldur	q0, [sp, #0xa8]
1004efc08:     	ldur	q1, [sp, #0xb8]
1004efc0c:     	stp	q0, q1, [x19, #0xe0]
1004efc10:     	ldur	q0, [sp, #0xc8]
1004efc14:     	ldur	q1, [sp, #0xd8]
1004efc18:     	stp	q0, q1, [x19, #0x100]
1004efc1c:     	ldur	q0, [sp, #0xe8]
1004efc20:     	ldur	q1, [sp, #0xf8]
1004efc24:     	stp	q0, q1, [x19, #0x120]
1004efc28:     	ldr	x8, [sp, #0x108]
<L37>:
1004efc2c:     	ldp	q0, q1, [x15, #0x40]
1004efc30:     	stp	q0, q1, [x19, #0xa0]
1004efc34:     	ldp	q0, q1, [x15, #0x60]
1004efc38:     	stp	q0, q1, [x19, #0xc0]
1004efc3c:     	ldp	q0, q1, [sp, #0x110]
1004efc40:     	stp	q0, q1, [x19, #0x60]
1004efc44:     	ldp	q0, q1, [x15, #0x20]
<L38>:
1004efc48:     	stp	q0, q1, [x19, #0x80]
<L39>:
1004efc4c:     	str	x8, [x19, #0x140]
1004efc50:     	ldr	x8, [sp, #0x58]
1004efc54:     	str	x8, [x19, #0x148]
<L40>:
1004efc58:     	add	sp, sp, #0x220
1004efc5c:     	ldp	x29, x30, [sp, #0x50]
1004efc60:     	ldp	x20, x19, [sp, #0x40]
1004efc64:     	ldp	x22, x21, [sp, #0x30]
1004efc68:     	ldp	x24, x23, [sp, #0x20]
1004efc6c:     	ldp	x26, x25, [sp, #0x10]
1004efc70:     	ldp	x28, x27, [sp], #0x60
1004efc74:     	ret
<L41>:
1004efc78:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efc7c:     	add	x2, x2, #0xc60
1004efc80:     	mov	w1, #0x4                ; =4
1004efc84:     	bl	 <core::panicking::panic_bounds_check>
<L42>:
1004efc88:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efc8c:     	add	x2, x2, #0xc78
1004efc90:     	mov	w1, #0x4                ; =4
1004efc94:     	bl	 <core::panicking::panic_bounds_check>
<L43>:
1004efc98:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efc9c:     	add	x2, x2, #0xc90
1004efca0:     	mov	w1, #0x4                ; =4
1004efca4:     	bl	 <core::panicking::panic_bounds_check>
		...
