
/private/tmp/s507-stage5-bench/result-enum/original-candidate-run-matrix:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004ef200 <od_machine::page_walk::walk_long64_4k_with_writer>:
1004ef200:     	stp	x28, x27, [sp, #-0x60]!
1004ef204:     	stp	x26, x25, [sp, #0x10]
1004ef208:     	stp	x24, x23, [sp, #0x20]
1004ef20c:     	stp	x22, x21, [sp, #0x30]
1004ef210:     	stp	x20, x19, [sp, #0x40]
1004ef214:     	stp	x29, x30, [sp, #0x50]
1004ef218:     	add	x29, sp, #0x50
1004ef21c:     	sub	sp, sp, #0x230
1004ef220:     	str	x7, [sp, #0xa0]
1004ef224:     	mov	x19, x8
1004ef228:     	mov	w8, #0xff               ; =255
1004ef22c:     	strb	w8, [sp, #0xca]
1004ef230:     	strb	w8, [sp, #0xe2]
1004ef234:     	strb	w8, [sp, #0xfa]
1004ef238:     	strb	w8, [sp, #0x112]
1004ef23c:     	str	xzr, [sp, #0x118]
1004ef240:     	mov	w8, #0x2                ; =2
1004ef244:     	strb	w8, [sp, #0x139]
1004ef248:     	lsr	x9, x3, #48
1004ef24c:     	sbfx	x10, x3, #47, #1
1004ef250:     	strb	w8, [sp, #0x159]
1004ef254:     	strb	w8, [sp, #0x179]
1004ef258:     	cmp	x9, w10, uxth
1004ef25c:     	add	x9, sp, #0x120
1004ef260:     	strb	w8, [sp, #0x199]
1004ef264:     	b.ne	 <L15>
1004ef268:     	str	x2, [sp, #0x10]
1004ef26c:     	stp	w4, w5, [sp, #0x1c]
1004ef270:     	str	w6, [sp, #0x24]
1004ef274:     	str	wzr, [sp, #0xb0]
1004ef278:     	str	xzr, [sp, #0x58]
1004ef27c:     	mov	w2, #0x0                ; =0
1004ef280:     	mov	x15, #0x0               ; =0
1004ef284:     	ldrb	w8, [x29, #0x28]
1004ef288:     	str	w8, [sp, #0x6c]
1004ef28c:     	ldp	x9, x8, [x29, #0x18]
1004ef290:     	str	x9, [sp, #0x50]
1004ef294:     	ldr	x9, [x29, #0x10]
1004ef298:     	str	x9, [sp, #0x48]
1004ef29c:     	ldr	x9, [x1, #0x8]
1004ef2a0:     	stur	xzr, [x29, #-0xe0]
1004ef2a4:     	stur	xzr, [x29, #-0xd0]
1004ef2a8:     	stur	xzr, [x29, #-0xc0]
1004ef2ac:     	stur	xzr, [x29, #-0xb0]
1004ef2b0:     	and	x16, x9, #0xffffff000
1004ef2b4:     	mov	w9, #0x4                ; =4
1004ef2b8:     	sub	x10, x29, #0xa0
1004ef2bc:     	add	x10, x10, #0x10
1004ef2c0:     	str	x10, [sp, #0x60]
1004ef2c4:     	mov	w10, #0x100             ; =256
1004ef2c8:     	movk	w10, #0x302, lsl #16
1004ef2cc:     	str	x1, [sp, #0x8]
1004ef2d0:     	ldr	x11, [x1, #0x18]
1004ef2d4:     	stp	x11, x3, [sp, #0x28]
1004ef2d8:     	tst	x11, #0x800
1004ef2dc:     	mov	x11, #0xfff000000000    ; =281406257233920
1004ef2e0:     	movk	x11, #0x800f, lsl #48
1004ef2e4:     	stur	x9, [x29, #-0x98]
1004ef2e8:     	stur	w10, [x29, #-0x90]
1004ef2ec:     	mov	x9, #0xffff000000000    ; =4503530907893760
1004ef2f0:     	csel	x9, x9, x11, ne
1004ef2f4:     	str	x9, [sp, #0xa8]
1004ef2f8:     	mov	w22, #0x58              ; =88
1004ef2fc:     	stur	xzr, [x29, #-0x88]
1004ef300:     	mov	w1, #0x1                ; =1
1004ef304:     	mov	w4, #0x1                ; =1
1004ef308:     	ldr	x8, [x8, #0x20]
1004ef30c:     	str	x8, [sp, #0x40]
<L0>:
1004ef310:     	ldr	x8, [sp, #0x60]
1004ef314:     	ldrb	w27, [x8, x15]
1004ef318:     	orr	x8, x27, x27, lsl #3
1004ef31c:     	mov	w9, #0x27               ; =39
1004ef320:     	sub	x8, x9, x8
1004ef324:     	sub	x9, x29, #0xe0
1004ef328:     	add	x9, x9, x15, lsl #4
1004ef32c:     	mov	w10, #0x1               ; =1
1004ef330:     	stp	x10, x16, [x9]
1004ef334:     	lsr	x20, x3, x8
1004ef338:     	ubfiz	x8, x20, #3, #9
1004ef33c:     	orr	x26, x8, x16
1004ef340:     	cmp	w27, #0x2
1004ef344:     	ldr	w8, [sp, #0x6c]
1004ef348:     	csel	w17, wzr, w8, ne
1004ef34c:     	ldp	x8, x9, [x0, #0x8]
1004ef350:     	adds	x21, x26, #0x8
1004ef354:     	cset	w23, hs
1004ef358:     	cbz	x9,  <L1>
1004ef35c:     	cmp	x9, #0x1
1004ef360:     	b.ne	 <L2>
1004ef364:     	mov	x10, #0x0               ; =0
1004ef368:     	b	 <L4>
<L1>:
1004ef36c:     	mov	x10, x9
1004ef370:     	b	 <L5>
<L2>:
1004ef374:     	mov	x10, #0x0               ; =0
1004ef378:     	mov	x11, x9
<L3>:
1004ef37c:     	lsr	x12, x11, #1
1004ef380:     	add	x13, x12, x10
1004ef384:     	madd	x14, x13, x22, x8
1004ef388:     	ldr	x14, [x14, #0x40]
1004ef38c:     	cmp	x14, x26
1004ef390:     	csel	x10, x10, x13, hi
1004ef394:     	sub	x11, x11, x12
1004ef398:     	cmp	x11, #0x1
1004ef39c:     	b.hi	 <L3>
<L4>:
1004ef3a0:     	madd	x11, x10, x22, x8
1004ef3a4:     	ldr	x11, [x11, #0x40]
1004ef3a8:     	cmp	x11, x26
1004ef3ac:     	b.eq	 <L5>
1004ef3b0:     	cinc	x10, x10, lo
1004ef3b4:     	subs	x10, x10, #0x1
1004ef3b8:     	csel	x10, xzr, x10, lo
<L5>:
1004ef3bc:     	cmp	x10, x9
1004ef3c0:     	b.hs	 <L16>
1004ef3c4:     	madd	x8, x10, x22, x8
1004ef3c8:     	ldr	x9, [x8, #0x40]
1004ef3cc:     	cmp	x26, x9
1004ef3d0:     	b.lo	 <L16>
1004ef3d4:     	ldr	x10, [x8, #0x48]
1004ef3d8:     	adds	x10, x10, x9
1004ef3dc:     	cset	w9, hs
1004ef3e0:     	cmp	x10, x21
1004ef3e4:     	sbcs	xzr, x9, x23
1004ef3e8:     	b.lo	 <L17>
1004ef3ec:     	ldrb	w8, [x8, #0x50]
1004ef3f0:     	cmp	w8, #0x4
1004ef3f4:     	b.eq	 <L19>
1004ef3f8:     	stp	w8, w17, [sp, #0xb0]
1004ef3fc:     	stp	w4, w1, [sp, #0x80]
1004ef400:     	stp	x16, x15, [sp, #0x88]
1004ef404:     	str	w2, [sp, #0x9c]
1004ef408:     	sub	x8, x29, #0x80
1004ef40c:     	mov	x28, x0
1004ef410:     	mov	x1, x26
1004ef414:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004ef418:     	ldurb	w8, [x29, #-0x80]
1004ef41c:     	cmp	w8, #0xff
1004ef420:     	b.ne	 <L21>
1004ef424:     	stp	x23, x21, [sp, #0x70]
1004ef428:     	ldr	x0, [sp, #0x118]
1004ef42c:     	cmp	x0, #0x3
1004ef430:     	b.hi	 <L39>
1004ef434:     	and	w21, w20, #0x1ff
1004ef438:     	ldur	x23, [x29, #-0x78]
1004ef43c:     	mov	w8, #0x18               ; =24
1004ef440:     	add	x9, sp, #0xb8
1004ef444:     	madd	x8, x0, x8, x9
1004ef448:     	stp	x26, x23, [x8]
1004ef44c:     	strh	w21, [x8, #0x10]
1004ef450:     	strb	w27, [x8, #0x12]
1004ef454:     	ldr	x8, [sp, #0x118]
1004ef458:     	add	x8, x8, #0x1
1004ef45c:     	str	x8, [sp, #0x118]
1004ef460:     	and	x9, x23, #0x80
1004ef464:     	ubfx	x10, x23, #7, #1
1004ef468:     	cmp	w27, #0x2
1004ef46c:     	csel	x8, x9, xzr, lo
1004ef470:     	ldr	w12, [sp, #0xb4]
1004ef474:     	ands	w25, w12, w10
1004ef478:     	and	x10, x23, #0x1fe000
1004ef47c:     	csel	x10, x10, xzr, ne
1004ef480:     	tbz	w23, #0x0,  <L22>
1004ef484:     	cmp	w27, #0x2
1004ef488:     	cset	w11, eq
1004ef48c:     	cmp	x9, #0x0
1004ef490:     	eor	w20, w11, w12
1004ef494:     	csel	w9, wzr, w20, eq
1004ef498:     	tbnz	w9, #0x0,  <L23>
1004ef49c:     	ldr	x9, [sp, #0xa8]
1004ef4a0:     	and	x9, x23, x9
1004ef4a4:     	orr	x8, x8, x9
1004ef4a8:     	orr	x8, x8, x10
1004ef4ac:     	cbnz	x8,  <L24>
1004ef4b0:     	tbnz	w23, #0x5,  <L11>
1004ef4b4:     	str	x27, [sp, #0x38]
1004ef4b8:     	orr	x27, x23, #0x20
1004ef4bc:     	sub	x8, x29, #0x80
1004ef4c0:     	orr	x4, x23, #0x20
1004ef4c4:     	ldp	x6, x0, [sp, #0x48]
1004ef4c8:     	mov	x1, x28
1004ef4cc:     	mov	x2, x26
1004ef4d0:     	mov	x3, x23
1004ef4d4:     	ldr	x5, [sp, #0xa0]
1004ef4d8:     	ldr	x9, [sp, #0x40]
1004ef4dc:     	blr	x9
1004ef4e0:     	ldurb	w8, [x29, #-0x80]
1004ef4e4:     	cmp	w8, #0xff
1004ef4e8:     	b.ne	 <L26>
1004ef4ec:     	ldur	x8, [x29, #-0x78]
1004ef4f0:     	cbz	x8,  <L12>
1004ef4f4:     	mov	w24, #0x1               ; =1
1004ef4f8:     	ldr	x27, [sp, #0x38]
<L6>:
1004ef4fc:     	mov	x0, x28
1004ef500:     	ldp	x8, x9, [x28, #0x8]
1004ef504:     	cbz	x9,  <L9>
1004ef508:     	cmp	x9, #0x1
1004ef50c:     	ldp	x16, x15, [sp, #0x70]
1004ef510:     	mov	x10, #0x0               ; =0
1004ef514:     	b.eq	 <L8>
1004ef518:     	mov	x11, x9
<L7>:
1004ef51c:     	lsr	x12, x11, #1
1004ef520:     	add	x13, x12, x10
1004ef524:     	madd	x14, x13, x22, x8
1004ef528:     	ldr	x14, [x14, #0x40]
1004ef52c:     	cmp	x14, x26
1004ef530:     	csel	x10, x10, x13, hi
1004ef534:     	sub	x11, x11, x12
1004ef538:     	cmp	x11, #0x1
1004ef53c:     	b.hi	 <L7>
<L8>:
1004ef540:     	madd	x11, x10, x22, x8
1004ef544:     	ldr	x11, [x11, #0x40]
1004ef548:     	cmp	x11, x26
1004ef54c:     	b.eq	 <L10>
1004ef550:     	cinc	x10, x10, lo
1004ef554:     	subs	x10, x10, #0x1
1004ef558:     	csel	x10, xzr, x10, lo
1004ef55c:     	b	 <L10>
<L9>:
1004ef560:     	mov	x10, x9
1004ef564:     	ldp	x16, x15, [sp, #0x70]
<L10>:
1004ef568:     	cmp	x10, x9
1004ef56c:     	b.hs	 <L16>
1004ef570:     	madd	x8, x10, x22, x8
1004ef574:     	ldr	x9, [x8, #0x40]
1004ef578:     	cmp	x26, x9
1004ef57c:     	b.lo	 <L16>
1004ef580:     	ldr	x10, [x8, #0x48]
1004ef584:     	adds	x10, x10, x9
1004ef588:     	cset	w9, hs
1004ef58c:     	cmp	x10, x15
1004ef590:     	sbcs	xzr, x9, x16
1004ef594:     	b.lo	 <L17>
1004ef598:     	ldrb	w8, [x8, #0x50]
1004ef59c:     	cmp	w8, #0x4
1004ef5a0:     	b.eq	 <L19>
1004ef5a4:     	str	w8, [sp, #0xb0]
1004ef5a8:     	sub	x8, x29, #0x80
1004ef5ac:     	mov	x1, x26
1004ef5b0:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004ef5b4:     	ldurb	w8, [x29, #-0x80]
1004ef5b8:     	cmp	w8, #0xff
1004ef5bc:     	b.ne	 <L21>
1004ef5c0:     	ldr	x8, [sp, #0x118]
1004ef5c4:     	sub	x0, x8, #0x1
1004ef5c8:     	cmp	x0, #0x4
1004ef5cc:     	b.hs	 <L40>
1004ef5d0:     	ldur	x23, [x29, #-0x78]
1004ef5d4:     	mov	w8, #0x18               ; =24
1004ef5d8:     	add	x9, sp, #0xb8
1004ef5dc:     	madd	x8, x0, x8, x9
1004ef5e0:     	stp	x26, x23, [x8]
1004ef5e4:     	strh	w21, [x8, #0x10]
1004ef5e8:     	strb	w27, [x8, #0x12]
1004ef5ec:     	and	x8, x23, #0x80
1004ef5f0:     	ubfx	x10, x23, #7, #1
1004ef5f4:     	cmp	w27, #0x2
1004ef5f8:     	csel	x9, x8, xzr, lo
1004ef5fc:     	ldr	w11, [sp, #0xb4]
1004ef600:     	ands	w25, w11, w10
1004ef604:     	and	x10, x23, #0x1fe000
1004ef608:     	csel	x10, x10, xzr, ne
1004ef60c:     	tbz	w23, #0x0,  <L22>
1004ef610:     	cmp	x8, #0x0
1004ef614:     	csel	w8, wzr, w20, eq
1004ef618:     	tbnz	w8, #0x0,  <L23>
1004ef61c:     	ldr	x8, [sp, #0xa8]
1004ef620:     	and	x8, x23, x8
1004ef624:     	orr	x8, x9, x8
1004ef628:     	orr	x8, x8, x10
1004ef62c:     	cbnz	x8,  <L24>
1004ef630:     	tbnz	w23, #0x5,  <L11>
1004ef634:     	orr	x27, x23, #0x20
1004ef638:     	sub	x8, x29, #0x80
1004ef63c:     	orr	x4, x23, #0x20
1004ef640:     	ldp	x6, x0, [sp, #0x48]
1004ef644:     	mov	x1, x28
1004ef648:     	mov	x2, x26
1004ef64c:     	mov	x3, x23
1004ef650:     	ldr	x5, [sp, #0xa0]
1004ef654:     	ldr	x9, [sp, #0x40]
1004ef658:     	blr	x9
1004ef65c:     	ldurb	w8, [x29, #-0x80]
1004ef660:     	cmp	w8, #0xff
1004ef664:     	b.ne	 <L26>
1004ef668:     	ldur	x8, [x29, #-0x78]
1004ef66c:     	cbz	x8,  <L12>
1004ef670:     	cmp	w24, #0x10
1004ef674:     	add	w24, w24, #0x1
1004ef678:     	ldr	x27, [sp, #0x38]
1004ef67c:     	b.ne	 <L6>
1004ef680:     	b	 <L29>
<L11>:
1004ef684:     	ldr	x3, [sp, #0x30]
1004ef688:     	ldr	w2, [sp, #0x9c]
1004ef68c:     	b	 <L13>
<L12>:
1004ef690:     	ldr	x0, [sp, #0x58]
1004ef694:     	cmp	x0, #0x3
1004ef698:     	ldr	x3, [sp, #0x30]
1004ef69c:     	ldr	w2, [sp, #0x9c]
1004ef6a0:     	b.hi	 <L41>
1004ef6a4:     	add	x8, sp, #0x120
1004ef6a8:     	add	x8, x8, x0, lsl #5
1004ef6ac:     	stp	x26, x23, [x8]
1004ef6b0:     	str	x27, [x8, #0x10]
1004ef6b4:     	ldr	x27, [sp, #0x38]
1004ef6b8:     	strb	w27, [x8, #0x18]
1004ef6bc:     	strb	wzr, [x8, #0x19]
1004ef6c0:     	add	x0, x0, #0x1
1004ef6c4:     	str	x0, [sp, #0x58]
<L13>:
1004ef6c8:     	mov	x0, x28
1004ef6cc:     	ubfx	x8, x23, #2, #1
1004ef6d0:     	ldp	w4, w1, [sp, #0x80]
1004ef6d4:     	and	w4, w4, w8
1004ef6d8:     	ubfx	x8, x23, #1, #1
1004ef6dc:     	and	w1, w1, w8
1004ef6e0:     	lsr	x8, x23, #63
1004ef6e4:     	orr	w2, w2, w8
1004ef6e8:     	ldp	x16, x15, [sp, #0x88]
1004ef6ec:     	tbnz	w25, #0x0,  <L14>
1004ef6f0:     	add	x15, x15, #0x1
1004ef6f4:     	and	x8, x23, #0xffffff000
1004ef6f8:     	cmp	w27, #0x3
1004ef6fc:     	csel	x16, x16, x8, eq
1004ef700:     	cmp	x15, #0x4
1004ef704:     	b.ne	 <L0>
<L14>:
1004ef708:     	ldp	w0, w17, [sp, #0x1c]
1004ef70c:     	and	w8, w0, #0xff
1004ef710:     	cmp	w8, #0x2
1004ef714:     	and	w8, w17, #0xff
1004ef718:     	ccmp	w8, #0x3, #0x0, ne
1004ef71c:     	cset	w9, eq
1004ef720:     	b.ne	 <L27>
1004ef724:     	eor	w8, w4, #0x1
1004ef728:     	ldr	w16, [sp, #0x24]
1004ef72c:     	and	w10, w16, #0xff
1004ef730:     	cmp	w10, #0x2
1004ef734:     	cset	w10, ne
1004ef738:     	orr	w10, w10, w1
1004ef73c:     	add	x15, sp, #0x120
1004ef740:     	tbnz	w10, #0x0,  <L28>
1004ef744:     	mov	w2, #0x0                ; =0
1004ef748:     	mov	w10, #0x1               ; =1
1004ef74c:     	ldr	x12, [sp, #0x28]
1004ef750:     	b	 <L33>
<L15>:
1004ef754:     	adrp	x8, 0x10082c000 <_anon.46955161eb1c9d064970950154d48426.3215+0x600>
1004ef758:     	ldr	q0, [x8, #0x9f0]
1004ef75c:     	str	q0, [x19]
1004ef760:     	str	x3, [x19, #0x10]
1004ef764:     	ldur	q0, [sp, #0xf8]
1004ef768:     	add	x8, sp, #0x9
1004ef76c:     	ldur	q1, [x8, #0xff]
1004ef770:     	stp	q0, q1, [x19, #0x120]
1004ef774:     	ldr	x8, [sp, #0x118]
1004ef778:     	ldur	q0, [sp, #0xb8]
1004ef77c:     	ldur	q1, [sp, #0xc8]
1004ef780:     	stp	q0, q1, [x19, #0xe0]
1004ef784:     	ldur	q0, [sp, #0xd8]
1004ef788:     	ldur	q1, [sp, #0xe8]
1004ef78c:     	stp	q0, q1, [x19, #0x100]
1004ef790:     	ldp	q0, q1, [sp, #0x120]
1004ef794:     	ldp	q2, q3, [x9, #0x20]
1004ef798:     	stp	q2, q3, [x19, #0x80]
1004ef79c:     	stp	q0, q1, [x19, #0x60]
1004ef7a0:     	ldp	q0, q1, [x9, #0x40]
1004ef7a4:     	ldp	q2, q3, [x9, #0x60]
1004ef7a8:     	stp	q2, q3, [x19, #0xc0]
1004ef7ac:     	stp	q0, q1, [x19, #0xa0]
1004ef7b0:     	stp	x8, xzr, [x19, #0x140]
1004ef7b4:     	b	 <L38>
<L16>:
1004ef7b8:     	mov	w8, #0xa                ; =10
1004ef7bc:     	b	 <L18>
<L17>:
1004ef7c0:     	cmp	x26, x10
1004ef7c4:     	ngcs	xzr, x9
1004ef7c8:     	cset	w8, lo
1004ef7cc:     	cmp	w8, #0x0
1004ef7d0:     	mov	w8, #0xa                ; =10
1004ef7d4:     	cinc	w8, w8, ne
<L18>:
1004ef7d8:     	mov	w9, #0x8                ; =8
1004ef7dc:     	stp	x26, x9, [x29, #-0x78]
1004ef7e0:     	ldr	w9, [sp, #0xb0]
1004ef7e4:     	b	 <L20>
<L19>:
1004ef7e8:     	mov	w9, #0x4                ; =4
1004ef7ec:     	mov	w8, #0xc                ; =12
<L20>:
1004ef7f0:     	sturb	w8, [x29, #-0x80]
1004ef7f4:     	sturb	w9, [x29, #-0x7f]
<L21>:
1004ef7f8:     	add	x9, sp, #0x120
1004ef7fc:     	ldp	q0, q1, [x9, #0xe0]
1004ef800:     	stp	q0, q1, [x19, #0x10]
1004ef804:     	adrp	x8, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef808:     	ldr	q1, [x8, #0xf40]
1004ef80c:     	ldur	x8, [x29, #-0x60]
1004ef810:     	str	q1, [x19]
1004ef814:     	stp	x8, x26, [x19, #0x30]
1004ef818:     	strb	w27, [x19, #0x40]
1004ef81c:     	ldur	q0, [sp, #0xf8]
1004ef820:     	add	x8, sp, #0x9
1004ef824:     	ldur	q1, [x8, #0xff]
1004ef828:     	stp	q0, q1, [x19, #0x120]
1004ef82c:     	ldr	x8, [sp, #0x118]
1004ef830:     	ldur	q0, [sp, #0xb8]
1004ef834:     	ldur	q1, [sp, #0xc8]
1004ef838:     	stp	q0, q1, [x19, #0xe0]
1004ef83c:     	ldur	q0, [sp, #0xd8]
1004ef840:     	ldur	q1, [sp, #0xe8]
1004ef844:     	stp	q0, q1, [x19, #0x100]
1004ef848:     	ldp	q1, q0, [x9, #0x60]
1004ef84c:     	stp	q1, q0, [x19, #0xc0]
1004ef850:     	ldp	q1, q0, [x9, #0x40]
1004ef854:     	stp	q1, q0, [x19, #0xa0]
1004ef858:     	ldp	q1, q0, [x9, #0x20]
1004ef85c:     	stp	q1, q0, [x19, #0x80]
1004ef860:     	ldp	q1, q0, [sp, #0x120]
1004ef864:     	stp	q1, q0, [x19, #0x60]
1004ef868:     	b	 <L37>
<L22>:
1004ef86c:     	adrp	x8, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef870:     	ldr	q0, [x8, #0xd90]
1004ef874:     	ldp	x8, x12, [sp, #0x28]
1004ef878:     	ubfx	x8, x8, #11, #1
1004ef87c:     	ldp	w15, w14, [sp, #0x1c]
1004ef880:     	and	w9, w15, #0xff
1004ef884:     	str	q0, [x19]
1004ef888:     	ldr	w13, [sp, #0x24]
1004ef88c:     	ands	w10, w13, #0xff
1004ef890:     	cset	w11, eq
1004ef894:     	str	x12, [x19, #0x10]
1004ef898:     	cmp	w10, #0x2
1004ef89c:     	csel	w10, w10, wzr, eq
1004ef8a0:     	and	w12, w14, #0xff
1004ef8a4:     	cmp	w12, #0x3
1004ef8a8:     	ccmp	w9, #0x2, #0x4, eq
1004ef8ac:     	mov	w9, #0x4                ; =4
1004ef8b0:     	csel	w9, w9, wzr, ne
1004ef8b4:     	orr	w9, w10, w9
1004ef8b8:     	tst	w11, w8
1004ef8bc:     	mov	w8, #0x10               ; =16
1004ef8c0:     	csel	w8, w8, wzr, ne
1004ef8c4:     	orr	w8, w9, w8
1004ef8c8:     	mov	w9, #0x1                ; =1
1004ef8cc:     	stp	w9, w8, [x19, #0x18]
1004ef8d0:     	mov	w8, #0xe                ; =14
1004ef8d4:     	strb	w8, [x19, #0x20]
1004ef8d8:     	ldr	x8, [sp, #0x10]
1004ef8dc:     	str	x8, [x19, #0x28]
1004ef8e0:     	strb	w15, [x19, #0x30]
1004ef8e4:     	strb	w14, [x19, #0x31]
1004ef8e8:     	strb	w13, [x19, #0x32]
1004ef8ec:     	strb	wzr, [x19, #0x38]
1004ef8f0:     	strb	w27, [x19, #0x39]
1004ef8f4:     	b	 <L25>
<L23>:
1004ef8f8:     	adrp	x8, 0x1007e4000 <_anon.bd1ea81803b8ca00c3db2ae4266198e2.358+0x551>
1004ef8fc:     	ldr	q0, [x8, #0x80]
1004ef900:     	str	q0, [x19]
1004ef904:     	stp	x26, x23, [x19, #0x10]
1004ef908:     	strb	w27, [x19, #0x20]
1004ef90c:     	ldur	q0, [sp, #0xf8]
1004ef910:     	add	x8, sp, #0x9
1004ef914:     	ldur	q1, [x8, #0xff]
1004ef918:     	stp	q0, q1, [x19, #0x120]
1004ef91c:     	ldr	x8, [sp, #0x118]
1004ef920:     	ldur	q0, [sp, #0xb8]
1004ef924:     	ldur	q1, [sp, #0xc8]
1004ef928:     	stp	q0, q1, [x19, #0xe0]
1004ef92c:     	ldur	q0, [sp, #0xd8]
1004ef930:     	ldur	q1, [sp, #0xe8]
1004ef934:     	stp	q0, q1, [x19, #0x100]
1004ef938:     	add	x9, sp, #0x120
1004ef93c:     	ldp	q1, q0, [x9, #0x20]
1004ef940:     	stp	q1, q0, [x19, #0x80]
1004ef944:     	ldp	q1, q0, [sp, #0x120]
1004ef948:     	stp	q1, q0, [x19, #0x60]
1004ef94c:     	ldp	q1, q0, [x9, #0x60]
1004ef950:     	stp	q1, q0, [x19, #0xc0]
1004ef954:     	ldp	q1, q0, [x9, #0x40]
1004ef958:     	stp	q1, q0, [x19, #0xa0]
1004ef95c:     	b	 <L37>
<L24>:
1004ef960:     	adrp	x9, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef964:     	ldr	q0, [x9, #0xd90]
1004ef968:     	ldp	x9, x13, [sp, #0x28]
1004ef96c:     	ubfx	x9, x9, #11, #1
1004ef970:     	ldp	w16, w15, [sp, #0x1c]
1004ef974:     	and	w10, w16, #0xff
1004ef978:     	str	q0, [x19]
1004ef97c:     	ldr	w14, [sp, #0x24]
1004ef980:     	ands	w11, w14, #0xff
1004ef984:     	cset	w12, eq
1004ef988:     	str	x13, [x19, #0x10]
1004ef98c:     	cmp	w11, #0x2
1004ef990:     	mov	w11, #0x3               ; =3
1004ef994:     	csinc	w11, w11, wzr, eq
1004ef998:     	and	w13, w15, #0xff
1004ef99c:     	tst	w12, w9
1004ef9a0:     	mov	w9, #0x10               ; =16
1004ef9a4:     	csel	w9, w9, wzr, ne
1004ef9a8:     	cmp	w13, #0x3
1004ef9ac:     	ccmp	w10, #0x2, #0x4, eq
1004ef9b0:     	mov	w10, #0x8               ; =8
1004ef9b4:     	mov	w12, #0xc               ; =12
1004ef9b8:     	csel	w10, w12, w10, ne
1004ef9bc:     	orr	w10, w10, w11
1004ef9c0:     	orr	w9, w10, w9
1004ef9c4:     	mov	w10, #0x1               ; =1
1004ef9c8:     	stp	w10, w9, [x19, #0x18]
1004ef9cc:     	mov	w9, #0xe                ; =14
1004ef9d0:     	strb	w9, [x19, #0x20]
1004ef9d4:     	ldr	x9, [sp, #0x10]
1004ef9d8:     	str	x9, [x19, #0x28]
1004ef9dc:     	strb	w16, [x19, #0x30]
1004ef9e0:     	strb	w15, [x19, #0x31]
1004ef9e4:     	strb	w14, [x19, #0x32]
1004ef9e8:     	strb	w10, [x19, #0x38]
1004ef9ec:     	strb	w27, [x19, #0x39]
1004ef9f0:     	str	x8, [x19, #0x40]
<L25>:
1004ef9f4:     	ldur	q0, [sp, #0xf8]
1004ef9f8:     	add	x8, sp, #0x9
1004ef9fc:     	ldur	q1, [x8, #0xff]
1004efa00:     	stp	q0, q1, [x19, #0x120]
1004efa04:     	ldr	x8, [sp, #0x118]
1004efa08:     	ldur	q0, [sp, #0xb8]
1004efa0c:     	ldur	q1, [sp, #0xc8]
1004efa10:     	stp	q0, q1, [x19, #0xe0]
1004efa14:     	ldur	q0, [sp, #0xd8]
1004efa18:     	ldur	q1, [sp, #0xe8]
1004efa1c:     	stp	q0, q1, [x19, #0x100]
1004efa20:     	add	x9, sp, #0x120
1004efa24:     	ldp	q0, q1, [x9, #0x40]
1004efa28:     	stp	q0, q1, [x19, #0xa0]
1004efa2c:     	ldp	q0, q1, [x9, #0x60]
1004efa30:     	stp	q0, q1, [x19, #0xc0]
1004efa34:     	ldp	q0, q1, [sp, #0x120]
1004efa38:     	stp	q0, q1, [x19, #0x60]
1004efa3c:     	ldp	q0, q1, [x9, #0x20]
1004efa40:     	b	 <L36>
<L26>:
1004efa44:     	add	x13, sp, #0x120
1004efa48:     	ldp	q0, q1, [x13, #0xe0]
1004efa4c:     	stur	q0, [x19, #0x18]
1004efa50:     	stur	q1, [x19, #0x28]
1004efa54:     	ldur	x9, [x29, #-0x60]
1004efa58:     	mov	w10, #0x2               ; =2
1004efa5c:     	mov	w8, #0x41               ; =65
1004efa60:     	str	x9, [x19, #0x38]
1004efa64:     	str	x10, [x19]
1004efa68:     	mov	w10, #0x40              ; =64
1004efa6c:     	mov	w11, #0x10              ; =16
1004efa70:     	mov	w9, #0x7                ; =7
1004efa74:     	mov	w12, #0x8               ; =8
1004efa78:     	ldr	x27, [sp, #0x38]
1004efa7c:     	b	 <L30>
<L27>:
1004efa80:     	ldr	w16, [sp, #0x24]
1004efa84:     	and	w8, w16, #0xff
1004efa88:     	cmp	w8, #0x2
1004efa8c:     	cset	w8, ne
1004efa90:     	orr	w8, w8, w1
1004efa94:     	add	x15, sp, #0x120
1004efa98:     	tbz	w8, #0x0,  <L31>
1004efa9c:     	mov	w8, #0x0                ; =0
<L28>:
1004efaa0:     	ldr	x12, [sp, #0x28]
1004efaa4:     	mov	w10, #0x0               ; =0
1004efaa8:     	tst	w16, #0xff
1004efaac:     	b.ne	 <L32>
1004efab0:     	tbz	w12, #0xb,  <L32>
1004efab4:     	mov	w10, #0x0               ; =0
1004efab8:     	tbnz	w8, #0x0,  <L33>
1004efabc:     	tbz	w2, #0x0,  <L34>
1004efac0:     	b	 <L33>
<L29>:
1004efac4:     	mov	x9, x26
1004efac8:     	ldur	x26, [x29, #-0x70]
1004efacc:     	mov	w8, #0x21               ; =33
1004efad0:     	adrp	x10, 0x100839000 <_anon.ff0337c78e95b70e8401eb32eaf46e94.1617+0x37b>
1004efad4:     	ldr	q0, [x10, #0xb20]
1004efad8:     	str	q0, [x19]
1004efadc:     	mov	w10, #0x20              ; =32
1004efae0:     	mov	w11, #0x18              ; =24
1004efae4:     	mov	w12, #0x10              ; =16
1004efae8:     	add	x13, sp, #0x120
<L30>:
1004efaec:     	str	x9, [x19, x12]
1004efaf0:     	str	x26, [x19, x11]
1004efaf4:     	strb	w27, [x19, x10]
1004efaf8:     	strb	wzr, [x19, x8]
1004efafc:     	ldur	q0, [sp, #0xf8]
1004efb00:     	add	x8, sp, #0x9
1004efb04:     	ldur	q1, [x8, #0xff]
1004efb08:     	stp	q0, q1, [x19, #0x120]
1004efb0c:     	ldr	x8, [sp, #0x118]
1004efb10:     	ldur	q0, [sp, #0xb8]
1004efb14:     	ldur	q1, [sp, #0xc8]
1004efb18:     	stp	q0, q1, [x19, #0xe0]
1004efb1c:     	ldur	q0, [sp, #0xd8]
1004efb20:     	ldur	q1, [sp, #0xe8]
1004efb24:     	stp	q0, q1, [x19, #0x100]
1004efb28:     	ldp	q0, q1, [sp, #0x120]
1004efb2c:     	ldp	q2, q3, [x13, #0x20]
1004efb30:     	stp	q2, q3, [x19, #0x80]
1004efb34:     	stp	q0, q1, [x19, #0x60]
1004efb38:     	ldp	q0, q1, [x13, #0x40]
1004efb3c:     	ldp	q2, q3, [x13, #0x60]
1004efb40:     	stp	q2, q3, [x19, #0xc0]
1004efb44:     	stp	q0, q1, [x19, #0xa0]
1004efb48:     	b	 <L37>
<L31>:
1004efb4c:     	mov	w8, #0x0                ; =0
1004efb50:     	ldr	x10, [sp, #0x8]
1004efb54:     	ldr	w10, [x10]
1004efb58:     	ubfx	w10, w10, #16, #1
1004efb5c:     	ldr	x12, [sp, #0x28]
<L32>:
1004efb60:     	orr	w11, w8, w10
1004efb64:     	cbz	w11,  <L34>
1004efb68:     	mov	w2, #0x0                ; =0
<L33>:
1004efb6c:     	adrp	x11, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004efb70:     	ldr	q0, [x11, #0xd90]
1004efb74:     	ubfx	x11, x12, #11, #1
1004efb78:     	ands	w12, w16, #0xff
1004efb7c:     	str	q0, [x19]
1004efb80:     	cset	w13, eq
1004efb84:     	cmp	w12, #0x2
1004efb88:     	str	x3, [x19, #0x10]
1004efb8c:     	mov	w12, #0x3               ; =3
1004efb90:     	csinc	w12, w12, wzr, eq
1004efb94:     	mov	w14, #0x4               ; =4
1004efb98:     	cmp	w9, #0x0
1004efb9c:     	csel	w9, w14, wzr, ne
1004efba0:     	tst	w13, w11
1004efba4:     	mov	w11, #0x10              ; =16
1004efba8:     	csel	w11, w11, wzr, ne
1004efbac:     	orr	w11, w12, w11
1004efbb0:     	orr	w9, w11, w9
1004efbb4:     	mov	w11, #0x1               ; =1
1004efbb8:     	stp	w11, w9, [x19, #0x18]
1004efbbc:     	mov	w9, #0xe                ; =14
1004efbc0:     	strb	w9, [x19, #0x20]
1004efbc4:     	ldr	x9, [sp, #0x10]
1004efbc8:     	str	x9, [x19, #0x28]
1004efbcc:     	strb	w0, [x19, #0x30]
1004efbd0:     	strb	w17, [x19, #0x31]
1004efbd4:     	strb	w16, [x19, #0x32]
1004efbd8:     	mov	w9, #0x2                ; =2
1004efbdc:     	strb	w9, [x19, #0x38]
1004efbe0:     	strb	w8, [x19, #0x39]
1004efbe4:     	strb	w10, [x19, #0x3a]
1004efbe8:     	strb	w2, [x19, #0x3b]
1004efbec:     	ldur	q0, [sp, #0xf8]
1004efbf0:     	add	x8, sp, #0x9
1004efbf4:     	ldur	q1, [x8, #0xff]
1004efbf8:     	stp	q0, q1, [x19, #0x120]
1004efbfc:     	ldr	x8, [sp, #0x118]
1004efc00:     	ldur	q0, [sp, #0xb8]
1004efc04:     	ldur	q1, [sp, #0xc8]
1004efc08:     	stp	q0, q1, [x19, #0xe0]
1004efc0c:     	ldur	q0, [sp, #0xd8]
1004efc10:     	ldur	q1, [sp, #0xe8]
1004efc14:     	stp	q0, q1, [x19, #0x100]
1004efc18:     	b	 <L35>
<L34>:
1004efc1c:     	orr	x8, x23, #0x20
1004efc20:     	tst	w25, #0x1
1004efc24:     	mov	w9, #0xfff              ; =4095
1004efc28:     	ldp	q0, q1, [x15, #0x80]
1004efc2c:     	mov	w10, #0x1fffff          ; =2097151
1004efc30:     	csel	x9, x10, x9, ne
1004efc34:     	and	x10, x9, #0x1ff000
1004efc38:     	eor	x10, x10, #0xffffff000
1004efc3c:     	stp	q0, q1, [x19]
1004efc40:     	and	x10, x10, x23
1004efc44:     	and	x9, x9, x3
1004efc48:     	orr	x9, x10, x9
1004efc4c:     	mov	w10, #0x2               ; =2
1004efc50:     	ldp	q0, q1, [x15, #0xa0]
1004efc54:     	cinc	w10, w10, eq
1004efc58:     	stp	q0, q1, [x19, #0x20]
1004efc5c:     	stp	x9, x26, [x19, #0x40]
1004efc60:     	str	x8, [x19, #0x50]
1004efc64:     	strb	w10, [x19, #0x58]
1004efc68:     	ldur	q0, [sp, #0xb8]
1004efc6c:     	ldur	q1, [sp, #0xc8]
1004efc70:     	stp	q0, q1, [x19, #0xe0]
1004efc74:     	ldur	q0, [sp, #0xd8]
1004efc78:     	ldur	q1, [sp, #0xe8]
1004efc7c:     	stp	q0, q1, [x19, #0x100]
1004efc80:     	ldur	q0, [sp, #0xf8]
1004efc84:     	add	x8, sp, #0x9
1004efc88:     	ldur	q1, [x8, #0xff]
1004efc8c:     	stp	q0, q1, [x19, #0x120]
1004efc90:     	ldr	x8, [sp, #0x118]
<L35>:
1004efc94:     	ldp	q0, q1, [x15, #0x40]
1004efc98:     	stp	q0, q1, [x19, #0xa0]
1004efc9c:     	ldp	q0, q1, [x15, #0x60]
1004efca0:     	stp	q0, q1, [x19, #0xc0]
1004efca4:     	ldp	q0, q1, [sp, #0x120]
1004efca8:     	stp	q0, q1, [x19, #0x60]
1004efcac:     	ldp	q0, q1, [x15, #0x20]
<L36>:
1004efcb0:     	stp	q0, q1, [x19, #0x80]
<L37>:
1004efcb4:     	str	x8, [x19, #0x140]
1004efcb8:     	ldr	x8, [sp, #0x58]
1004efcbc:     	str	x8, [x19, #0x148]
<L38>:
1004efcc0:     	add	sp, sp, #0x230
1004efcc4:     	ldp	x29, x30, [sp, #0x50]
1004efcc8:     	ldp	x20, x19, [sp, #0x40]
1004efccc:     	ldp	x22, x21, [sp, #0x30]
1004efcd0:     	ldp	x24, x23, [sp, #0x20]
1004efcd4:     	ldp	x26, x25, [sp, #0x10]
1004efcd8:     	ldp	x28, x27, [sp], #0x60
1004efcdc:     	ret
<L39>:
1004efce0:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efce4:     	add	x2, x2, #0xc60
1004efce8:     	mov	w1, #0x4                ; =4
1004efcec:     	bl	 <core::panicking::panic_bounds_check>
<L40>:
1004efcf0:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efcf4:     	add	x2, x2, #0xc78
1004efcf8:     	mov	w1, #0x4                ; =4
1004efcfc:     	bl	 <core::panicking::panic_bounds_check>
<L41>:
1004efd00:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efd04:     	add	x2, x2, #0xc90
1004efd08:     	mov	w1, #0x4                ; =4
1004efd0c:     	bl	 <core::panicking::panic_bounds_check>
		...
