
/private/tmp/s507-stage5-bench/target-baseline/release/deps/od_machine-533ce3e3cf110c1e:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004ef640 <od_machine::page_walk::walk_long64_4k_with_writer>:
1004ef640:     	stp	x28, x27, [sp, #-0x60]!
1004ef644:     	stp	x26, x25, [sp, #0x10]
1004ef648:     	stp	x24, x23, [sp, #0x20]
1004ef64c:     	stp	x22, x21, [sp, #0x30]
1004ef650:     	stp	x20, x19, [sp, #0x40]
1004ef654:     	stp	x29, x30, [sp, #0x50]
1004ef658:     	add	x29, sp, #0x50
1004ef65c:     	sub	sp, sp, #0x230
1004ef660:     	str	x7, [sp, #0xa0]
1004ef664:     	mov	x19, x8
1004ef668:     	mov	w8, #0xff               ; =255
1004ef66c:     	strb	w8, [sp, #0xca]
1004ef670:     	strb	w8, [sp, #0xe2]
1004ef674:     	strb	w8, [sp, #0xfa]
1004ef678:     	strb	w8, [sp, #0x112]
1004ef67c:     	str	xzr, [sp, #0x118]
1004ef680:     	mov	w8, #0x2                ; =2
1004ef684:     	strb	w8, [sp, #0x139]
1004ef688:     	lsr	x9, x3, #48
1004ef68c:     	sbfx	x10, x3, #47, #1
1004ef690:     	strb	w8, [sp, #0x159]
1004ef694:     	strb	w8, [sp, #0x179]
1004ef698:     	cmp	x9, w10, uxth
1004ef69c:     	add	x9, sp, #0x120
1004ef6a0:     	strb	w8, [sp, #0x199]
1004ef6a4:     	b.ne	 <L19>
1004ef6a8:     	mov	x24, x0
1004ef6ac:     	str	x2, [sp, #0x10]
1004ef6b0:     	stp	w4, w5, [sp, #0x24]
1004ef6b4:     	str	w6, [sp, #0x2c]
1004ef6b8:     	str	wzr, [sp, #0xb0]
1004ef6bc:     	str	xzr, [sp, #0x48]
1004ef6c0:     	mov	w2, #0x0                ; =0
1004ef6c4:     	mov	x27, #0x0               ; =0
1004ef6c8:     	ldrb	w8, [x29, #0x28]
1004ef6cc:     	str	w8, [sp, #0x7c]
1004ef6d0:     	ldp	x9, x8, [x29, #0x18]
1004ef6d4:     	str	x9, [sp, #0x68]
1004ef6d8:     	ldr	x9, [x29, #0x10]
1004ef6dc:     	str	x9, [sp, #0x60]
1004ef6e0:     	ldr	x9, [x1, #0x8]
1004ef6e4:     	stur	xzr, [x29, #-0xe0]
1004ef6e8:     	stur	xzr, [x29, #-0xd0]
1004ef6ec:     	stur	xzr, [x29, #-0xc0]
1004ef6f0:     	stur	xzr, [x29, #-0xb0]
1004ef6f4:     	and	x28, x9, #0xffffff000
1004ef6f8:     	mov	w9, #0x4                ; =4
1004ef6fc:     	stur	x9, [x29, #-0x98]
1004ef700:     	sub	x9, x29, #0xa0
1004ef704:     	add	x9, x9, #0x10
1004ef708:     	str	x9, [sp, #0x70]
1004ef70c:     	mov	w9, #0x100              ; =256
1004ef710:     	movk	w9, #0x302, lsl #16
1004ef714:     	stur	w9, [x29, #-0x90]
1004ef718:     	str	x1, [sp, #0x8]
1004ef71c:     	ldr	x9, [x1, #0x18]
1004ef720:     	str	x9, [sp, #0x18]
1004ef724:     	tst	x9, #0x800
1004ef728:     	mov	x9, #0xffff000000000    ; =4503530907893760
1004ef72c:     	stur	xzr, [x29, #-0x88]
1004ef730:     	mov	x10, #0xfff000000000    ; =281406257233920
1004ef734:     	movk	x10, #0x800f, lsl #48
1004ef738:     	csel	x9, x10, x9, eq
1004ef73c:     	str	x9, [sp, #0xa8]
1004ef740:     	orr	x9, x9, #0x1fe000
1004ef744:     	stp	x9, x3, [sp, #0x30]
1004ef748:     	mov	w20, #0x58              ; =88
1004ef74c:     	ldr	x8, [x8, #0x20]
1004ef750:     	str	x8, [sp, #0x58]
1004ef754:     	mov	w15, #0x1               ; =1
1004ef758:     	mov	w16, #0x1               ; =1
<L0>:
1004ef75c:     	ldr	x8, [sp, #0x70]
1004ef760:     	ldrb	w21, [x8, x27]
1004ef764:     	orr	x8, x21, x21, lsl #3
1004ef768:     	mov	w9, #0x27               ; =39
1004ef76c:     	sub	x8, x9, x8
1004ef770:     	sub	x9, x29, #0xe0
1004ef774:     	add	x9, x9, x27, lsl #4
1004ef778:     	mov	w10, #0x1               ; =1
1004ef77c:     	stp	x10, x28, [x9]
1004ef780:     	lsr	x22, x3, x8
1004ef784:     	ubfiz	x8, x22, #3, #9
1004ef788:     	orr	x26, x8, x28
1004ef78c:     	cmp	w21, #0x2
1004ef790:     	ldr	w8, [sp, #0x7c]
1004ef794:     	csel	w8, wzr, w8, ne
1004ef798:     	str	w8, [sp, #0xb4]
1004ef79c:     	ldp	x8, x9, [x24, #0x8]
1004ef7a0:     	adds	x23, x26, #0x8
1004ef7a4:     	cset	w17, hs
1004ef7a8:     	cbz	x9,  <L1>
1004ef7ac:     	cmp	x9, #0x1
1004ef7b0:     	b.ne	 <L2>
1004ef7b4:     	mov	x10, #0x0               ; =0
1004ef7b8:     	b	 <L4>
<L1>:
1004ef7bc:     	mov	x10, x9
1004ef7c0:     	b	 <L5>
<L2>:
1004ef7c4:     	mov	x10, #0x0               ; =0
1004ef7c8:     	mov	x11, x9
<L3>:
1004ef7cc:     	lsr	x12, x11, #1
1004ef7d0:     	add	x13, x12, x10
1004ef7d4:     	madd	x14, x13, x20, x8
1004ef7d8:     	ldr	x14, [x14, #0x40]
1004ef7dc:     	cmp	x14, x26
1004ef7e0:     	csel	x10, x10, x13, hi
1004ef7e4:     	sub	x11, x11, x12
1004ef7e8:     	cmp	x11, #0x1
1004ef7ec:     	b.hi	 <L3>
<L4>:
1004ef7f0:     	madd	x11, x10, x20, x8
1004ef7f4:     	ldr	x11, [x11, #0x40]
1004ef7f8:     	cmp	x11, x26
1004ef7fc:     	b.eq	 <L5>
1004ef800:     	cinc	x10, x10, lo
1004ef804:     	subs	x10, x10, #0x1
1004ef808:     	csel	x10, xzr, x10, lo
<L5>:
1004ef80c:     	cmp	x10, x9
1004ef810:     	b.hs	 <L20>
1004ef814:     	madd	x8, x10, x20, x8
1004ef818:     	ldr	x9, [x8, #0x40]
1004ef81c:     	cmp	x26, x9
1004ef820:     	b.lo	 <L20>
1004ef824:     	ldr	x10, [x8, #0x48]
1004ef828:     	adds	x10, x10, x9
1004ef82c:     	cset	w9, hs
1004ef830:     	cmp	x10, x23
1004ef834:     	sbcs	xzr, x9, x17
1004ef838:     	b.lo	 <L21>
1004ef83c:     	ldrb	w8, [x8, #0x50]
1004ef840:     	cmp	w8, #0x4
1004ef844:     	b.eq	 <L23>
1004ef848:     	str	x17, [sp, #0x80]
1004ef84c:     	stp	w16, w15, [sp, #0x94]
1004ef850:     	str	w8, [sp, #0xb0]
1004ef854:     	str	w2, [sp, #0x9c]
1004ef858:     	sub	x8, x29, #0x80
1004ef85c:     	mov	x0, x24
1004ef860:     	mov	x1, x26
1004ef864:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004ef868:     	ldurb	w8, [x29, #-0x80]
1004ef86c:     	cmp	w8, #0xff
1004ef870:     	b.ne	 <L25>
1004ef874:     	str	x23, [sp, #0x88]
1004ef878:     	ldr	x0, [sp, #0x118]
1004ef87c:     	cmp	x0, #0x3
1004ef880:     	b.hi	 <L43>
1004ef884:     	and	w25, w22, #0x1ff
1004ef888:     	ldur	x23, [x29, #-0x78]
1004ef88c:     	mov	w8, #0x18               ; =24
1004ef890:     	add	x9, sp, #0xb8
1004ef894:     	madd	x8, x0, x8, x9
1004ef898:     	stp	x26, x23, [x8]
1004ef89c:     	strh	w25, [x8, #0x10]
1004ef8a0:     	strb	w21, [x8, #0x12]
1004ef8a4:     	ldr	x8, [sp, #0x118]
1004ef8a8:     	add	x8, x8, #0x1
1004ef8ac:     	str	x8, [sp, #0x118]
1004ef8b0:     	tbz	w23, #0x0,  <L26>
1004ef8b4:     	ldr	x8, [sp, #0xa8]
1004ef8b8:     	and	x8, x23, x8
1004ef8bc:     	and	x9, x23, #0x80
1004ef8c0:     	ldr	w10, [sp, #0xb4]
1004ef8c4:     	tbz	w10, #0x0,  <L6>
1004ef8c8:     	ldr	x10, [sp, #0x30]
1004ef8cc:     	and	x10, x23, x10
1004ef8d0:     	cmp	x9, #0x0
1004ef8d4:     	csel	x8, x10, x8, ne
1004ef8d8:     	cset	w13, ne
1004ef8dc:     	cbz	x8,  <L7>
1004ef8e0:     	b	 <L27>
<L6>:
1004ef8e4:     	cmp	w21, #0x2
1004ef8e8:     	csel	x10, x9, xzr, lo
1004ef8ec:     	cmp	x9, #0x0
1004ef8f0:     	ccmp	w21, #0x2, #0x0, ne
1004ef8f4:     	b.eq	 <L30>
1004ef8f8:     	mov	w13, #0x0               ; =0
1004ef8fc:     	orr	x8, x10, x8
1004ef900:     	cbnz	x8,  <L27>
<L7>:
1004ef904:     	tbnz	w23, #0x5,  <L15>
1004ef908:     	mov	x1, x24
1004ef90c:     	mov	x24, x13
1004ef910:     	str	x21, [sp, #0x50]
1004ef914:     	orr	x21, x23, #0x20
1004ef918:     	sub	x8, x29, #0x80
1004ef91c:     	orr	x4, x23, #0x20
1004ef920:     	ldp	x6, x0, [sp, #0x60]
1004ef924:     	str	x1, [sp, #0x40]
1004ef928:     	mov	x2, x26
1004ef92c:     	mov	x3, x23
1004ef930:     	ldr	x5, [sp, #0xa0]
1004ef934:     	ldr	x9, [sp, #0x58]
1004ef938:     	blr	x9
1004ef93c:     	ldurb	w8, [x29, #-0x80]
1004ef940:     	cmp	w8, #0xff
1004ef944:     	b.ne	 <L29>
1004ef948:     	ldur	x8, [x29, #-0x78]
1004ef94c:     	cbz	x8,  <L16>
1004ef950:     	mov	w22, #0x1               ; =1
1004ef954:     	ldr	x21, [sp, #0x50]
<L8>:
1004ef958:     	ldr	x24, [sp, #0x40]
1004ef95c:     	ldp	x8, x9, [x24, #0x8]
1004ef960:     	cbz	x9,  <L11>
1004ef964:     	cmp	x9, #0x1
1004ef968:     	ldr	x15, [sp, #0x88]
1004ef96c:     	mov	x10, #0x0               ; =0
1004ef970:     	b.eq	 <L10>
1004ef974:     	mov	x11, x9
<L9>:
1004ef978:     	lsr	x12, x11, #1
1004ef97c:     	add	x13, x12, x10
1004ef980:     	madd	x14, x13, x20, x8
1004ef984:     	ldr	x14, [x14, #0x40]
1004ef988:     	cmp	x14, x26
1004ef98c:     	csel	x10, x10, x13, hi
1004ef990:     	sub	x11, x11, x12
1004ef994:     	cmp	x11, #0x1
1004ef998:     	b.hi	 <L9>
<L10>:
1004ef99c:     	madd	x11, x10, x20, x8
1004ef9a0:     	ldr	x11, [x11, #0x40]
1004ef9a4:     	cmp	x11, x26
1004ef9a8:     	b.eq	 <L12>
1004ef9ac:     	cinc	x10, x10, lo
1004ef9b0:     	subs	x10, x10, #0x1
1004ef9b4:     	csel	x10, xzr, x10, lo
1004ef9b8:     	b	 <L12>
<L11>:
1004ef9bc:     	mov	x10, x9
1004ef9c0:     	ldr	x15, [sp, #0x88]
<L12>:
1004ef9c4:     	cmp	x10, x9
1004ef9c8:     	b.hs	 <L20>
1004ef9cc:     	madd	x8, x10, x20, x8
1004ef9d0:     	ldr	x9, [x8, #0x40]
1004ef9d4:     	cmp	x26, x9
1004ef9d8:     	b.lo	 <L20>
1004ef9dc:     	ldr	x10, [x8, #0x48]
1004ef9e0:     	adds	x10, x10, x9
1004ef9e4:     	cset	w9, hs
1004ef9e8:     	cmp	x10, x15
1004ef9ec:     	ldr	x11, [sp, #0x80]
1004ef9f0:     	sbcs	xzr, x9, x11
1004ef9f4:     	b.lo	 <L21>
1004ef9f8:     	ldrb	w8, [x8, #0x50]
1004ef9fc:     	cmp	w8, #0x4
1004efa00:     	b.eq	 <L23>
1004efa04:     	str	w8, [sp, #0xb0]
1004efa08:     	sub	x8, x29, #0x80
1004efa0c:     	mov	x0, x24
1004efa10:     	mov	x1, x26
1004efa14:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004efa18:     	ldurb	w8, [x29, #-0x80]
1004efa1c:     	cmp	w8, #0xff
1004efa20:     	b.ne	 <L25>
1004efa24:     	ldr	x8, [sp, #0x118]
1004efa28:     	sub	x0, x8, #0x1
1004efa2c:     	cmp	x0, #0x4
1004efa30:     	b.hs	 <L44>
1004efa34:     	ldur	x23, [x29, #-0x78]
1004efa38:     	mov	w8, #0x18               ; =24
1004efa3c:     	add	x9, sp, #0xb8
1004efa40:     	madd	x8, x0, x8, x9
1004efa44:     	stp	x26, x23, [x8]
1004efa48:     	strh	w25, [x8, #0x10]
1004efa4c:     	strb	w21, [x8, #0x12]
1004efa50:     	tbz	w23, #0x0,  <L26>
1004efa54:     	ldr	x8, [sp, #0xa8]
1004efa58:     	and	x8, x23, x8
1004efa5c:     	and	x9, x23, #0x80
1004efa60:     	ldr	w10, [sp, #0xb4]
1004efa64:     	tbz	w10, #0x0,  <L13>
1004efa68:     	ldr	x10, [sp, #0x30]
1004efa6c:     	and	x10, x23, x10
1004efa70:     	cmp	x9, #0x0
1004efa74:     	csel	x8, x10, x8, ne
1004efa78:     	cset	w13, ne
1004efa7c:     	b	 <L14>
<L13>:
1004efa80:     	cmp	w21, #0x2
1004efa84:     	csel	x10, x9, xzr, lo
1004efa88:     	cmp	x9, #0x0
1004efa8c:     	ccmp	w21, #0x2, #0x0, ne
1004efa90:     	b.eq	 <L30>
1004efa94:     	mov	w13, #0x0               ; =0
1004efa98:     	orr	x8, x10, x8
<L14>:
1004efa9c:     	cbnz	x8,  <L27>
1004efaa0:     	tbnz	w23, #0x5,  <L15>
1004efaa4:     	mov	x1, x24
1004efaa8:     	mov	x24, x13
1004efaac:     	orr	x21, x23, #0x20
1004efab0:     	sub	x8, x29, #0x80
1004efab4:     	orr	x4, x23, #0x20
1004efab8:     	ldp	x6, x0, [sp, #0x60]
1004efabc:     	mov	x2, x26
1004efac0:     	mov	x3, x23
1004efac4:     	ldr	x5, [sp, #0xa0]
1004efac8:     	ldr	x9, [sp, #0x58]
1004efacc:     	blr	x9
1004efad0:     	ldurb	w8, [x29, #-0x80]
1004efad4:     	cmp	w8, #0xff
1004efad8:     	b.ne	 <L29>
1004efadc:     	ldur	x8, [x29, #-0x78]
1004efae0:     	cbz	x8,  <L16>
1004efae4:     	cmp	w22, #0x10
1004efae8:     	add	w22, w22, #0x1
1004efaec:     	ldr	x21, [sp, #0x50]
1004efaf0:     	b.ne	 <L8>
1004efaf4:     	b	 <L33>
<L15>:
1004efaf8:     	ldr	x3, [sp, #0x38]
1004efafc:     	ldp	w15, w2, [sp, #0x98]
1004efb00:     	ldr	w16, [sp, #0x94]
1004efb04:     	b	 <L17>
<L16>:
1004efb08:     	ldr	x0, [sp, #0x48]
1004efb0c:     	cmp	x0, #0x3
1004efb10:     	ldr	x3, [sp, #0x38]
1004efb14:     	ldp	w15, w2, [sp, #0x98]
1004efb18:     	ldr	w16, [sp, #0x94]
1004efb1c:     	b.hi	 <L45>
1004efb20:     	mov	x13, x24
1004efb24:     	add	x8, sp, #0x120
1004efb28:     	add	x8, x8, x0, lsl #5
1004efb2c:     	stp	x26, x23, [x8]
1004efb30:     	str	x21, [x8, #0x10]
1004efb34:     	ldr	x21, [sp, #0x50]
1004efb38:     	strb	w21, [x8, #0x18]
1004efb3c:     	strb	wzr, [x8, #0x19]
1004efb40:     	add	x0, x0, #0x1
1004efb44:     	str	x0, [sp, #0x48]
1004efb48:     	ldr	x24, [sp, #0x40]
<L17>:
1004efb4c:     	ubfx	x8, x23, #2, #1
1004efb50:     	and	w16, w16, w8
1004efb54:     	ubfx	x8, x23, #1, #1
1004efb58:     	and	w15, w15, w8
1004efb5c:     	lsr	x8, x23, #63
1004efb60:     	orr	w2, w2, w8
1004efb64:     	tbnz	w13, #0x0,  <L18>
1004efb68:     	add	x27, x27, #0x1
1004efb6c:     	and	x8, x23, #0xffffff000
1004efb70:     	cmp	w21, #0x3
1004efb74:     	csel	x28, x28, x8, eq
1004efb78:     	cmp	x27, #0x4
1004efb7c:     	b.ne	 <L0>
<L18>:
1004efb80:     	ldp	w0, w17, [sp, #0x24]
1004efb84:     	and	w8, w0, #0xff
1004efb88:     	cmp	w8, #0x2
1004efb8c:     	and	w8, w17, #0xff
1004efb90:     	ccmp	w8, #0x3, #0x0, ne
1004efb94:     	cset	w9, eq
1004efb98:     	b.ne	 <L31>
1004efb9c:     	eor	w8, w16, #0x1
1004efba0:     	ldr	w16, [sp, #0x2c]
1004efba4:     	and	w10, w16, #0xff
1004efba8:     	cmp	w10, #0x2
1004efbac:     	cset	w10, ne
1004efbb0:     	orr	w10, w10, w15
1004efbb4:     	add	x15, sp, #0x120
1004efbb8:     	ldr	x12, [sp, #0x18]
1004efbbc:     	tbnz	w10, #0x0,  <L32>
1004efbc0:     	mov	w2, #0x0                ; =0
1004efbc4:     	mov	w10, #0x1               ; =1
1004efbc8:     	b	 <L37>
<L19>:
1004efbcc:     	adrp	x8, 0x100809000 <_anon.a86c0f9c22846514d6613526b04d73a2.3300+0x538>
1004efbd0:     	ldr	q0, [x8, #0xdd0]
1004efbd4:     	str	q0, [x19]
1004efbd8:     	str	x3, [x19, #0x10]
1004efbdc:     	ldur	q0, [sp, #0xf8]
1004efbe0:     	add	x8, sp, #0x9
1004efbe4:     	ldur	q1, [x8, #0xff]
1004efbe8:     	stp	q0, q1, [x19, #0x120]
1004efbec:     	ldr	x8, [sp, #0x118]
1004efbf0:     	ldur	q0, [sp, #0xb8]
1004efbf4:     	ldur	q1, [sp, #0xc8]
1004efbf8:     	stp	q0, q1, [x19, #0xe0]
1004efbfc:     	ldur	q0, [sp, #0xd8]
1004efc00:     	ldur	q1, [sp, #0xe8]
1004efc04:     	stp	q0, q1, [x19, #0x100]
1004efc08:     	ldp	q0, q1, [sp, #0x120]
1004efc0c:     	ldp	q2, q3, [x9, #0x20]
1004efc10:     	stp	q2, q3, [x19, #0x80]
1004efc14:     	stp	q0, q1, [x19, #0x60]
1004efc18:     	ldp	q0, q1, [x9, #0x40]
1004efc1c:     	ldp	q2, q3, [x9, #0x60]
1004efc20:     	stp	q2, q3, [x19, #0xc0]
1004efc24:     	stp	q0, q1, [x19, #0xa0]
1004efc28:     	stp	x8, xzr, [x19, #0x140]
1004efc2c:     	b	 <L42>
<L20>:
1004efc30:     	mov	w8, #0xa                ; =10
1004efc34:     	b	 <L22>
<L21>:
1004efc38:     	cmp	x26, x10
1004efc3c:     	ngcs	xzr, x9
1004efc40:     	cset	w8, lo
1004efc44:     	cmp	w8, #0x0
1004efc48:     	mov	w8, #0xa                ; =10
1004efc4c:     	cinc	w8, w8, ne
<L22>:
1004efc50:     	mov	w9, #0x8                ; =8
1004efc54:     	stp	x26, x9, [x29, #-0x78]
1004efc58:     	ldr	w9, [sp, #0xb0]
1004efc5c:     	b	 <L24>
<L23>:
1004efc60:     	mov	w9, #0x4                ; =4
1004efc64:     	mov	w8, #0xc                ; =12
<L24>:
1004efc68:     	sturb	w8, [x29, #-0x80]
1004efc6c:     	sturb	w9, [x29, #-0x7f]
<L25>:
1004efc70:     	add	x9, sp, #0x120
1004efc74:     	ldp	q0, q1, [x9, #0xe0]
1004efc78:     	stp	q0, q1, [x19, #0x10]
1004efc7c:     	adrp	x8, 0x1007e1000 <_anon.7d21e1e64ade75f84441d57ff85e6bcb.154+0x61>
1004efc80:     	ldr	q1, [x8, #0xbc0]
1004efc84:     	ldur	x8, [x29, #-0x60]
1004efc88:     	str	q1, [x19]
1004efc8c:     	stp	x8, x26, [x19, #0x30]
1004efc90:     	strb	w21, [x19, #0x40]
1004efc94:     	ldur	q0, [sp, #0xf8]
1004efc98:     	add	x8, sp, #0x9
1004efc9c:     	ldur	q1, [x8, #0xff]
1004efca0:     	stp	q0, q1, [x19, #0x120]
1004efca4:     	ldr	x8, [sp, #0x118]
1004efca8:     	ldur	q0, [sp, #0xb8]
1004efcac:     	ldur	q1, [sp, #0xc8]
1004efcb0:     	stp	q0, q1, [x19, #0xe0]
1004efcb4:     	ldur	q0, [sp, #0xd8]
1004efcb8:     	ldur	q1, [sp, #0xe8]
1004efcbc:     	stp	q0, q1, [x19, #0x100]
1004efcc0:     	ldp	q1, q0, [x9, #0x60]
1004efcc4:     	stp	q1, q0, [x19, #0xc0]
1004efcc8:     	ldp	q1, q0, [x9, #0x40]
1004efccc:     	stp	q1, q0, [x19, #0xa0]
1004efcd0:     	ldp	q1, q0, [x9, #0x20]
1004efcd4:     	stp	q1, q0, [x19, #0x80]
1004efcd8:     	ldp	q1, q0, [sp, #0x120]
1004efcdc:     	stp	q1, q0, [x19, #0x60]
1004efce0:     	b	 <L41>
<L26>:
1004efce4:     	adrp	x8, 0x1007e1000 <_anon.7d21e1e64ade75f84441d57ff85e6bcb.154+0x61>
1004efce8:     	ldr	q0, [x8, #0xa10]
1004efcec:     	ldr	x8, [sp, #0x18]
1004efcf0:     	ubfx	x8, x8, #11, #1
1004efcf4:     	ldp	w15, w14, [sp, #0x24]
1004efcf8:     	and	w9, w15, #0xff
1004efcfc:     	str	q0, [x19]
1004efd00:     	ldr	w13, [sp, #0x2c]
1004efd04:     	ands	w10, w13, #0xff
1004efd08:     	cset	w11, eq
1004efd0c:     	ldr	x12, [sp, #0x38]
1004efd10:     	str	x12, [x19, #0x10]
1004efd14:     	cmp	w10, #0x2
1004efd18:     	csel	w10, w10, wzr, eq
1004efd1c:     	and	w12, w14, #0xff
1004efd20:     	cmp	w12, #0x3
1004efd24:     	ccmp	w9, #0x2, #0x4, eq
1004efd28:     	mov	w9, #0x4                ; =4
1004efd2c:     	csel	w9, w9, wzr, ne
1004efd30:     	orr	w9, w10, w9
1004efd34:     	tst	w11, w8
1004efd38:     	mov	w8, #0x10               ; =16
1004efd3c:     	csel	w8, w8, wzr, ne
1004efd40:     	orr	w8, w9, w8
1004efd44:     	mov	w9, #0x1                ; =1
1004efd48:     	stp	w9, w8, [x19, #0x18]
1004efd4c:     	mov	w8, #0xe                ; =14
1004efd50:     	strb	w8, [x19, #0x20]
1004efd54:     	ldr	x8, [sp, #0x10]
1004efd58:     	str	x8, [x19, #0x28]
1004efd5c:     	strb	w15, [x19, #0x30]
1004efd60:     	strb	w14, [x19, #0x31]
1004efd64:     	strb	w13, [x19, #0x32]
1004efd68:     	strb	wzr, [x19, #0x38]
1004efd6c:     	strb	w21, [x19, #0x39]
1004efd70:     	b	 <L28>
<L27>:
1004efd74:     	adrp	x9, 0x1007e1000 <_anon.7d21e1e64ade75f84441d57ff85e6bcb.154+0x61>
1004efd78:     	ldr	q0, [x9, #0xa10]
1004efd7c:     	ldr	x9, [sp, #0x18]
1004efd80:     	ubfx	x9, x9, #11, #1
1004efd84:     	ldp	w16, w15, [sp, #0x24]
1004efd88:     	and	w10, w16, #0xff
1004efd8c:     	str	q0, [x19]
1004efd90:     	ldr	w14, [sp, #0x2c]
1004efd94:     	ands	w11, w14, #0xff
1004efd98:     	cset	w12, eq
1004efd9c:     	ldr	x13, [sp, #0x38]
1004efda0:     	str	x13, [x19, #0x10]
1004efda4:     	cmp	w11, #0x2
1004efda8:     	mov	w11, #0x3               ; =3
1004efdac:     	csinc	w11, w11, wzr, eq
1004efdb0:     	and	w13, w15, #0xff
1004efdb4:     	tst	w12, w9
1004efdb8:     	mov	w9, #0x10               ; =16
1004efdbc:     	csel	w9, w9, wzr, ne
1004efdc0:     	cmp	w13, #0x3
1004efdc4:     	ccmp	w10, #0x2, #0x4, eq
1004efdc8:     	mov	w10, #0x8               ; =8
1004efdcc:     	mov	w12, #0xc               ; =12
1004efdd0:     	csel	w10, w12, w10, ne
1004efdd4:     	orr	w10, w10, w11
1004efdd8:     	orr	w9, w10, w9
1004efddc:     	mov	w10, #0x1               ; =1
1004efde0:     	stp	w10, w9, [x19, #0x18]
1004efde4:     	mov	w9, #0xe                ; =14
1004efde8:     	strb	w9, [x19, #0x20]
1004efdec:     	ldr	x9, [sp, #0x10]
1004efdf0:     	str	x9, [x19, #0x28]
1004efdf4:     	strb	w16, [x19, #0x30]
1004efdf8:     	strb	w15, [x19, #0x31]
1004efdfc:     	strb	w14, [x19, #0x32]
1004efe00:     	strb	w10, [x19, #0x38]
1004efe04:     	strb	w21, [x19, #0x39]
1004efe08:     	str	x8, [x19, #0x40]
<L28>:
1004efe0c:     	ldur	q0, [sp, #0xf8]
1004efe10:     	add	x8, sp, #0x9
1004efe14:     	ldur	q1, [x8, #0xff]
1004efe18:     	stp	q0, q1, [x19, #0x120]
1004efe1c:     	ldr	x8, [sp, #0x118]
1004efe20:     	ldur	q0, [sp, #0xb8]
1004efe24:     	ldur	q1, [sp, #0xc8]
1004efe28:     	stp	q0, q1, [x19, #0xe0]
1004efe2c:     	ldur	q0, [sp, #0xd8]
1004efe30:     	ldur	q1, [sp, #0xe8]
1004efe34:     	stp	q0, q1, [x19, #0x100]
1004efe38:     	add	x9, sp, #0x120
1004efe3c:     	ldp	q0, q1, [x9, #0x40]
1004efe40:     	stp	q0, q1, [x19, #0xa0]
1004efe44:     	ldp	q0, q1, [x9, #0x60]
1004efe48:     	stp	q0, q1, [x19, #0xc0]
1004efe4c:     	ldp	q0, q1, [sp, #0x120]
1004efe50:     	stp	q0, q1, [x19, #0x60]
1004efe54:     	ldp	q0, q1, [x9, #0x20]
1004efe58:     	b	 <L40>
<L29>:
1004efe5c:     	add	x13, sp, #0x120
1004efe60:     	ldp	q0, q1, [x13, #0xe0]
1004efe64:     	stur	q0, [x19, #0x18]
1004efe68:     	stur	q1, [x19, #0x28]
1004efe6c:     	ldur	x9, [x29, #-0x60]
1004efe70:     	mov	w10, #0x2               ; =2
1004efe74:     	mov	w8, #0x41               ; =65
1004efe78:     	str	x9, [x19, #0x38]
1004efe7c:     	str	x10, [x19]
1004efe80:     	mov	w10, #0x40              ; =64
1004efe84:     	mov	w11, #0x10              ; =16
1004efe88:     	mov	w9, #0x7                ; =7
1004efe8c:     	mov	w12, #0x8               ; =8
1004efe90:     	ldr	x21, [sp, #0x50]
1004efe94:     	b	 <L34>
<L30>:
1004efe98:     	ldr	x9, [sp, #0x48]
1004efe9c:     	adrp	x8, 0x1007e1000 <_anon.7d21e1e64ade75f84441d57ff85e6bcb.154+0x61>
1004efea0:     	ldr	q0, [x8, #0xd00]
1004efea4:     	str	q0, [x19]
1004efea8:     	stp	x26, x23, [x19, #0x10]
1004efeac:     	mov	w8, #0x2                ; =2
1004efeb0:     	strb	w8, [x19, #0x20]
1004efeb4:     	ldur	q0, [sp, #0xf8]
1004efeb8:     	add	x8, sp, #0x9
1004efebc:     	ldur	q1, [x8, #0xff]
1004efec0:     	stp	q0, q1, [x19, #0x120]
1004efec4:     	ldr	x8, [sp, #0x118]
1004efec8:     	ldur	q0, [sp, #0xb8]
1004efecc:     	ldur	q1, [sp, #0xc8]
1004efed0:     	stp	q0, q1, [x19, #0xe0]
1004efed4:     	ldur	q0, [sp, #0xd8]
1004efed8:     	ldur	q1, [sp, #0xe8]
1004efedc:     	stp	q0, q1, [x19, #0x100]
1004efee0:     	add	x10, sp, #0x120
1004efee4:     	ldp	q0, q1, [x10, #0x40]
1004efee8:     	stp	q0, q1, [x19, #0xa0]
1004efeec:     	ldp	q0, q1, [x10, #0x60]
1004efef0:     	stp	q0, q1, [x19, #0xc0]
1004efef4:     	ldp	q0, q1, [sp, #0x120]
1004efef8:     	stp	q0, q1, [x19, #0x60]
1004efefc:     	ldp	q0, q1, [x10, #0x20]
1004eff00:     	stp	q0, q1, [x19, #0x80]
1004eff04:     	stp	x8, x9, [x19, #0x140]
1004eff08:     	b	 <L42>
<L31>:
1004eff0c:     	ldr	w16, [sp, #0x2c]
1004eff10:     	and	w8, w16, #0xff
1004eff14:     	cmp	w8, #0x2
1004eff18:     	cset	w8, ne
1004eff1c:     	orr	w8, w8, w15
1004eff20:     	add	x15, sp, #0x120
1004eff24:     	ldr	x12, [sp, #0x18]
1004eff28:     	tbz	w8, #0x0,  <L35>
1004eff2c:     	mov	w8, #0x0                ; =0
<L32>:
1004eff30:     	mov	w10, #0x0               ; =0
1004eff34:     	tst	w16, #0xff
1004eff38:     	b.ne	 <L36>
1004eff3c:     	tbz	w12, #0xb,  <L36>
1004eff40:     	mov	w10, #0x0               ; =0
1004eff44:     	tbnz	w8, #0x0,  <L37>
1004eff48:     	tbz	w2, #0x0,  <L38>
1004eff4c:     	b	 <L37>
<L33>:
1004eff50:     	mov	x9, x26
1004eff54:     	ldur	x26, [x29, #-0x70]
1004eff58:     	mov	w8, #0x21               ; =33
1004eff5c:     	adrp	x10, 0x10082e000 <_anon.e51bf8c4619cd0c33e8d93be91f1c6e5.3192+0xc6a>
1004eff60:     	ldr	q0, [x10, #0x960]
1004eff64:     	str	q0, [x19]
1004eff68:     	mov	w10, #0x20              ; =32
1004eff6c:     	mov	w11, #0x18              ; =24
1004eff70:     	mov	w12, #0x10              ; =16
1004eff74:     	add	x13, sp, #0x120
<L34>:
1004eff78:     	str	x9, [x19, x12]
1004eff7c:     	str	x26, [x19, x11]
1004eff80:     	strb	w21, [x19, x10]
1004eff84:     	strb	wzr, [x19, x8]
1004eff88:     	ldur	q0, [sp, #0xf8]
1004eff8c:     	add	x8, sp, #0x9
1004eff90:     	ldur	q1, [x8, #0xff]
1004eff94:     	stp	q0, q1, [x19, #0x120]
1004eff98:     	ldr	x8, [sp, #0x118]
1004eff9c:     	ldur	q0, [sp, #0xb8]
1004effa0:     	ldur	q1, [sp, #0xc8]
1004effa4:     	stp	q0, q1, [x19, #0xe0]
1004effa8:     	ldur	q0, [sp, #0xd8]
1004effac:     	ldur	q1, [sp, #0xe8]
1004effb0:     	stp	q0, q1, [x19, #0x100]
1004effb4:     	ldp	q0, q1, [sp, #0x120]
1004effb8:     	ldp	q2, q3, [x13, #0x20]
1004effbc:     	stp	q2, q3, [x19, #0x80]
1004effc0:     	stp	q0, q1, [x19, #0x60]
1004effc4:     	ldp	q0, q1, [x13, #0x40]
1004effc8:     	ldp	q2, q3, [x13, #0x60]
1004effcc:     	stp	q2, q3, [x19, #0xc0]
1004effd0:     	stp	q0, q1, [x19, #0xa0]
1004effd4:     	b	 <L41>
<L35>:
1004effd8:     	mov	w8, #0x0                ; =0
1004effdc:     	ldr	x10, [sp, #0x8]
1004effe0:     	ldr	w10, [x10]
1004effe4:     	ubfx	w10, w10, #16, #1
<L36>:
1004effe8:     	orr	w11, w8, w10
1004effec:     	cbz	w11,  <L38>
1004efff0:     	mov	w2, #0x0                ; =0
<L37>:
1004efff4:     	adrp	x11, 0x1007e1000 <_anon.7d21e1e64ade75f84441d57ff85e6bcb.154+0x61>
1004efff8:     	ldr	q0, [x11, #0xa10]
1004efffc:     	ubfx	x11, x12, #11, #1
1004f0000:     	ands	w12, w16, #0xff
1004f0004:     	str	q0, [x19]
1004f0008:     	cset	w13, eq
1004f000c:     	cmp	w12, #0x2
1004f0010:     	str	x3, [x19, #0x10]
1004f0014:     	mov	w12, #0x3               ; =3
1004f0018:     	csinc	w12, w12, wzr, eq
1004f001c:     	mov	w14, #0x4               ; =4
1004f0020:     	cmp	w9, #0x0
1004f0024:     	csel	w9, w14, wzr, ne
1004f0028:     	tst	w13, w11
1004f002c:     	mov	w11, #0x10              ; =16
1004f0030:     	csel	w11, w11, wzr, ne
1004f0034:     	orr	w11, w12, w11
1004f0038:     	orr	w9, w11, w9
1004f003c:     	mov	w11, #0x1               ; =1
1004f0040:     	stp	w11, w9, [x19, #0x18]
1004f0044:     	mov	w9, #0xe                ; =14
1004f0048:     	strb	w9, [x19, #0x20]
1004f004c:     	ldr	x9, [sp, #0x10]
1004f0050:     	str	x9, [x19, #0x28]
1004f0054:     	strb	w0, [x19, #0x30]
1004f0058:     	strb	w17, [x19, #0x31]
1004f005c:     	strb	w16, [x19, #0x32]
1004f0060:     	mov	w9, #0x2                ; =2
1004f0064:     	strb	w9, [x19, #0x38]
1004f0068:     	strb	w8, [x19, #0x39]
1004f006c:     	strb	w10, [x19, #0x3a]
1004f0070:     	strb	w2, [x19, #0x3b]
1004f0074:     	ldur	q0, [sp, #0xf8]
1004f0078:     	add	x8, sp, #0x9
1004f007c:     	ldur	q1, [x8, #0xff]
1004f0080:     	stp	q0, q1, [x19, #0x120]
1004f0084:     	ldr	x8, [sp, #0x118]
1004f0088:     	ldur	q0, [sp, #0xb8]
1004f008c:     	ldur	q1, [sp, #0xc8]
1004f0090:     	stp	q0, q1, [x19, #0xe0]
1004f0094:     	ldur	q0, [sp, #0xd8]
1004f0098:     	ldur	q1, [sp, #0xe8]
1004f009c:     	stp	q0, q1, [x19, #0x100]
1004f00a0:     	b	 <L39>
<L38>:
1004f00a4:     	orr	x8, x23, #0x20
1004f00a8:     	cmp	w13, #0x0
1004f00ac:     	mov	w9, #0xfff              ; =4095
1004f00b0:     	ldp	q0, q1, [x15, #0x80]
1004f00b4:     	mov	w10, #0x1fffff          ; =2097151
1004f00b8:     	csel	x9, x10, x9, ne
1004f00bc:     	and	x10, x9, #0x1ff000
1004f00c0:     	eor	x10, x10, #0xffffff000
1004f00c4:     	stp	q0, q1, [x19]
1004f00c8:     	and	x10, x10, x23
1004f00cc:     	and	x9, x9, x3
1004f00d0:     	orr	x9, x10, x9
1004f00d4:     	mov	w10, #0x2               ; =2
1004f00d8:     	ldp	q0, q1, [x15, #0xa0]
1004f00dc:     	cinc	w10, w10, eq
1004f00e0:     	stp	q0, q1, [x19, #0x20]
1004f00e4:     	stp	x9, x26, [x19, #0x40]
1004f00e8:     	str	x8, [x19, #0x50]
1004f00ec:     	strb	w10, [x19, #0x58]
1004f00f0:     	ldur	q0, [sp, #0xb8]
1004f00f4:     	ldur	q1, [sp, #0xc8]
1004f00f8:     	stp	q0, q1, [x19, #0xe0]
1004f00fc:     	ldur	q0, [sp, #0xd8]
1004f0100:     	ldur	q1, [sp, #0xe8]
1004f0104:     	stp	q0, q1, [x19, #0x100]
1004f0108:     	ldur	q0, [sp, #0xf8]
1004f010c:     	add	x8, sp, #0x9
1004f0110:     	ldur	q1, [x8, #0xff]
1004f0114:     	stp	q0, q1, [x19, #0x120]
1004f0118:     	ldr	x8, [sp, #0x118]
<L39>:
1004f011c:     	ldp	q0, q1, [x15, #0x40]
1004f0120:     	stp	q0, q1, [x19, #0xa0]
1004f0124:     	ldp	q0, q1, [x15, #0x60]
1004f0128:     	stp	q0, q1, [x19, #0xc0]
1004f012c:     	ldp	q0, q1, [sp, #0x120]
1004f0130:     	stp	q0, q1, [x19, #0x60]
1004f0134:     	ldp	q0, q1, [x15, #0x20]
<L40>:
1004f0138:     	stp	q0, q1, [x19, #0x80]
<L41>:
1004f013c:     	str	x8, [x19, #0x140]
1004f0140:     	ldr	x8, [sp, #0x48]
1004f0144:     	str	x8, [x19, #0x148]
<L42>:
1004f0148:     	add	sp, sp, #0x230
1004f014c:     	ldp	x29, x30, [sp, #0x50]
1004f0150:     	ldp	x20, x19, [sp, #0x40]
1004f0154:     	ldp	x22, x21, [sp, #0x30]
1004f0158:     	ldp	x24, x23, [sp, #0x20]
1004f015c:     	ldp	x26, x25, [sp, #0x10]
1004f0160:     	ldp	x28, x27, [sp], #0x60
1004f0164:     	ret
<L43>:
1004f0168:     	adrp	x2, 0x100a0e000 <_anon.e0e09f93f1da433393e4729f404e13b9.13+0x418>
1004f016c:     	add	x2, x2, #0xc00
1004f0170:     	mov	w1, #0x4                ; =4
1004f0174:     	bl	 <core::panicking::panic_bounds_check>
<L44>:
1004f0178:     	adrp	x2, 0x100a0e000 <_anon.e0e09f93f1da433393e4729f404e13b9.13+0x418>
1004f017c:     	add	x2, x2, #0xc18
1004f0180:     	mov	w1, #0x4                ; =4
1004f0184:     	bl	 <core::panicking::panic_bounds_check>
<L45>:
1004f0188:     	adrp	x2, 0x100a0e000 <_anon.e0e09f93f1da433393e4729f404e13b9.13+0x418>
1004f018c:     	add	x2, x2, #0xc30
1004f0190:     	mov	w1, #0x4                ; =4
1004f0194:     	bl	 <core::panicking::panic_bounds_check>
		...
