from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
for access in ('read', 'write'):
    results = {}
    for label in ('baseline', 'enum'):
        cases = []
        for sample in range(1, 4):
            log = (root / f'{label}-{sample}.log').read_text()
            assert '1 passed; 0 failed' in log
            prefix = f'BENCH_FIRST_AD,{label},{sample},4k,{access},'
            row, = [line for line in log.splitlines() if line.startswith(prefix)]
            fields = dict(item.split('=', 1) for item in row.removeprefix(prefix).split(','))
            assert int(fields['timed_ns']) >= 200_000_000
            assert int(fields['paths']) == 512
            assert int(fields['calls']) == int(fields['cycles']) * 512
            import struct
            data = Path(fields['raw_batch_path']).read_bytes()
            counts = tuple(n for (n,) in struct.iter_unpack('<Q', data))
            assert len(counts) == int(fields['cycles'])
            assert sum(counts) == int(fields['timed_ns'])
            cases.append(float(fields['ns_per_call']))
        results[label] = cases
        print(f'4K first-A {access} {label}: individual {cases}; median {median(cases):.3f}; range {min(cases):.3f}–{max(cases):.3f} ns/walk')
    base, enum = results['baseline'], results['enum']
    paired = [(new/old-1)*100 for new, old in zip(enum, base)]
    print(f'4K first-A {access} median change {(median(enum)/median(base)-1)*100:+.2f}%; paired changes {[round(p, 2) for p in paired]}')
