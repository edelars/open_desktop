S5-07 schema-v20 direct page-walker benchmark evidence

This archive contains raw direct-walker timings, run logs, harness source, release codegen/disassembly, and the exploratory extraction variants. No guest Linux or operand-store throughput is measured. Read/write are access kinds passed to page translation; the direct walker updates A, while D/operand commit is outside the measured function. First-A fixtures reset 512 independent canonical paths outside each timed packet, so describe them as first-A with prepared host-cache state, never as a cold-cache run.

`retained-walker/` is the candidate that preserves the baseline production walker body and adds only the read-only schema20 sidecar validator and parity tests. `balanced/` is six complete pairs with three baseline→candidate and three candidate→baseline orders. `raw-series/` is the earlier five-pair measurement of the initial shared extraction. `result-enum/` and `scalar-mask/` retain the two rejected codegen experiments and their raw evidence.

The candidate source patch from base commit 7a7c9ec, page_walk snapshots, exact baseline/candidate binary hashes, balanced execution order, host hardware, environment, and reproduction commands are included. Temporary build binaries and target directories are intentionally excluded.
