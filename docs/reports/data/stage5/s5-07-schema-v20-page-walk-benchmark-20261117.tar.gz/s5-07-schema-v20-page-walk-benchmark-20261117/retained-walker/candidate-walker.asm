
/private/tmp/s507-stage5-bench/target-candidate/release/deps/od_machine-533ce3e3cf110c1e:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100527e40 <od_machine::page_walk::walk_long64_4k_with_writer>:
100527e40:     	stp	x28, x27, [sp, #-0x60]!
100527e44:     	stp	x26, x25, [sp, #0x10]
100527e48:     	stp	x24, x23, [sp, #0x20]
100527e4c:     	stp	x22, x21, [sp, #0x30]
100527e50:     	stp	x20, x19, [sp, #0x40]
100527e54:     	stp	x29, x30, [sp, #0x50]
100527e58:     	add	x29, sp, #0x50
100527e5c:     	sub	sp, sp, #0x230
100527e60:     	str	x7, [sp, #0xa0]
100527e64:     	mov	x19, x8
100527e68:     	mov	w8, #0xff               ; =255
100527e6c:     	strb	w8, [sp, #0xca]
100527e70:     	strb	w8, [sp, #0xe2]
100527e74:     	strb	w8, [sp, #0xfa]
100527e78:     	strb	w8, [sp, #0x112]
100527e7c:     	str	xzr, [sp, #0x118]
100527e80:     	mov	w8, #0x2                ; =2
100527e84:     	strb	w8, [sp, #0x139]
100527e88:     	lsr	x9, x3, #48
100527e8c:     	sbfx	x10, x3, #47, #1
100527e90:     	strb	w8, [sp, #0x159]
100527e94:     	strb	w8, [sp, #0x179]
100527e98:     	cmp	x9, w10, uxth
100527e9c:     	add	x9, sp, #0x120
100527ea0:     	strb	w8, [sp, #0x199]
100527ea4:     	b.ne	 <L19>
100527ea8:     	mov	x24, x0
100527eac:     	str	x2, [sp, #0x10]
100527eb0:     	stp	w4, w5, [sp, #0x24]
100527eb4:     	str	w6, [sp, #0x2c]
100527eb8:     	str	wzr, [sp, #0xb0]
100527ebc:     	str	xzr, [sp, #0x48]
100527ec0:     	mov	w2, #0x0                ; =0
100527ec4:     	mov	x27, #0x0               ; =0
100527ec8:     	ldrb	w8, [x29, #0x28]
100527ecc:     	str	w8, [sp, #0x7c]
100527ed0:     	ldp	x9, x8, [x29, #0x18]
100527ed4:     	str	x9, [sp, #0x68]
100527ed8:     	ldr	x9, [x29, #0x10]
100527edc:     	str	x9, [sp, #0x60]
100527ee0:     	ldr	x9, [x1, #0x8]
100527ee4:     	stur	xzr, [x29, #-0xe0]
100527ee8:     	stur	xzr, [x29, #-0xd0]
100527eec:     	stur	xzr, [x29, #-0xc0]
100527ef0:     	stur	xzr, [x29, #-0xb0]
100527ef4:     	and	x28, x9, #0xffffff000
100527ef8:     	mov	w9, #0x4                ; =4
100527efc:     	stur	x9, [x29, #-0x98]
100527f00:     	sub	x9, x29, #0xa0
100527f04:     	add	x9, x9, #0x10
100527f08:     	str	x9, [sp, #0x70]
100527f0c:     	mov	w9, #0x100              ; =256
100527f10:     	movk	w9, #0x302, lsl #16
100527f14:     	stur	w9, [x29, #-0x90]
100527f18:     	str	x1, [sp, #0x8]
100527f1c:     	ldr	x9, [x1, #0x18]
100527f20:     	str	x9, [sp, #0x18]
100527f24:     	tst	x9, #0x800
100527f28:     	mov	x9, #0xffff000000000    ; =4503530907893760
100527f2c:     	stur	xzr, [x29, #-0x88]
100527f30:     	mov	x10, #0xfff000000000    ; =281406257233920
100527f34:     	movk	x10, #0x800f, lsl #48
100527f38:     	csel	x9, x10, x9, eq
100527f3c:     	str	x9, [sp, #0xa8]
100527f40:     	orr	x9, x9, #0x1fe000
100527f44:     	stp	x9, x3, [sp, #0x30]
100527f48:     	mov	w20, #0x58              ; =88
100527f4c:     	ldr	x8, [x8, #0x20]
100527f50:     	str	x8, [sp, #0x58]
100527f54:     	mov	w15, #0x1               ; =1
100527f58:     	mov	w16, #0x1               ; =1
<L0>:
100527f5c:     	ldr	x8, [sp, #0x70]
100527f60:     	ldrb	w21, [x8, x27]
100527f64:     	orr	x8, x21, x21, lsl #3
100527f68:     	mov	w9, #0x27               ; =39
100527f6c:     	sub	x8, x9, x8
100527f70:     	sub	x9, x29, #0xe0
100527f74:     	add	x9, x9, x27, lsl #4
100527f78:     	mov	w10, #0x1               ; =1
100527f7c:     	stp	x10, x28, [x9]
100527f80:     	lsr	x22, x3, x8
100527f84:     	ubfiz	x8, x22, #3, #9
100527f88:     	orr	x26, x8, x28
100527f8c:     	cmp	w21, #0x2
100527f90:     	ldr	w8, [sp, #0x7c]
100527f94:     	csel	w8, wzr, w8, ne
100527f98:     	str	w8, [sp, #0xb4]
100527f9c:     	ldp	x8, x9, [x24, #0x8]
100527fa0:     	adds	x23, x26, #0x8
100527fa4:     	cset	w17, hs
100527fa8:     	cbz	x9,  <L1>
100527fac:     	cmp	x9, #0x1
100527fb0:     	b.ne	 <L2>
100527fb4:     	mov	x10, #0x0               ; =0
100527fb8:     	b	 <L4>
<L1>:
100527fbc:     	mov	x10, x9
100527fc0:     	b	 <L5>
<L2>:
100527fc4:     	mov	x10, #0x0               ; =0
100527fc8:     	mov	x11, x9
<L3>:
100527fcc:     	lsr	x12, x11, #1
100527fd0:     	add	x13, x12, x10
100527fd4:     	madd	x14, x13, x20, x8
100527fd8:     	ldr	x14, [x14, #0x40]
100527fdc:     	cmp	x14, x26
100527fe0:     	csel	x10, x10, x13, hi
100527fe4:     	sub	x11, x11, x12
100527fe8:     	cmp	x11, #0x1
100527fec:     	b.hi	 <L3>
<L4>:
100527ff0:     	madd	x11, x10, x20, x8
100527ff4:     	ldr	x11, [x11, #0x40]
100527ff8:     	cmp	x11, x26
100527ffc:     	b.eq	 <L5>
100528000:     	cinc	x10, x10, lo
100528004:     	subs	x10, x10, #0x1
100528008:     	csel	x10, xzr, x10, lo
<L5>:
10052800c:     	cmp	x10, x9
100528010:     	b.hs	 <L20>
100528014:     	madd	x8, x10, x20, x8
100528018:     	ldr	x9, [x8, #0x40]
10052801c:     	cmp	x26, x9
100528020:     	b.lo	 <L20>
100528024:     	ldr	x10, [x8, #0x48]
100528028:     	adds	x10, x10, x9
10052802c:     	cset	w9, hs
100528030:     	cmp	x10, x23
100528034:     	sbcs	xzr, x9, x17
100528038:     	b.lo	 <L21>
10052803c:     	ldrb	w8, [x8, #0x50]
100528040:     	cmp	w8, #0x4
100528044:     	b.eq	 <L23>
100528048:     	str	x17, [sp, #0x80]
10052804c:     	stp	w16, w15, [sp, #0x94]
100528050:     	str	w8, [sp, #0xb0]
100528054:     	str	w2, [sp, #0x9c]
100528058:     	sub	x8, x29, #0x80
10052805c:     	mov	x0, x24
100528060:     	mov	x1, x26
100528064:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
100528068:     	ldurb	w8, [x29, #-0x80]
10052806c:     	cmp	w8, #0xff
100528070:     	b.ne	 <L25>
100528074:     	str	x23, [sp, #0x88]
100528078:     	ldr	x0, [sp, #0x118]
10052807c:     	cmp	x0, #0x3
100528080:     	b.hi	 <L43>
100528084:     	and	w25, w22, #0x1ff
100528088:     	ldur	x23, [x29, #-0x78]
10052808c:     	mov	w8, #0x18               ; =24
100528090:     	add	x9, sp, #0xb8
100528094:     	madd	x8, x0, x8, x9
100528098:     	stp	x26, x23, [x8]
10052809c:     	strh	w25, [x8, #0x10]
1005280a0:     	strb	w21, [x8, #0x12]
1005280a4:     	ldr	x8, [sp, #0x118]
1005280a8:     	add	x8, x8, #0x1
1005280ac:     	str	x8, [sp, #0x118]
1005280b0:     	tbz	w23, #0x0,  <L26>
1005280b4:     	ldr	x8, [sp, #0xa8]
1005280b8:     	and	x8, x23, x8
1005280bc:     	and	x9, x23, #0x80
1005280c0:     	ldr	w10, [sp, #0xb4]
1005280c4:     	tbz	w10, #0x0,  <L6>
1005280c8:     	ldr	x10, [sp, #0x30]
1005280cc:     	and	x10, x23, x10
1005280d0:     	cmp	x9, #0x0
1005280d4:     	csel	x8, x10, x8, ne
1005280d8:     	cset	w13, ne
1005280dc:     	cbz	x8,  <L7>
1005280e0:     	b	 <L27>
<L6>:
1005280e4:     	cmp	w21, #0x2
1005280e8:     	csel	x10, x9, xzr, lo
1005280ec:     	cmp	x9, #0x0
1005280f0:     	ccmp	w21, #0x2, #0x0, ne
1005280f4:     	b.eq	 <L30>
1005280f8:     	mov	w13, #0x0               ; =0
1005280fc:     	orr	x8, x10, x8
100528100:     	cbnz	x8,  <L27>
<L7>:
100528104:     	tbnz	w23, #0x5,  <L15>
100528108:     	mov	x1, x24
10052810c:     	mov	x24, x13
100528110:     	str	x21, [sp, #0x50]
100528114:     	orr	x21, x23, #0x20
100528118:     	sub	x8, x29, #0x80
10052811c:     	orr	x4, x23, #0x20
100528120:     	ldp	x6, x0, [sp, #0x60]
100528124:     	str	x1, [sp, #0x40]
100528128:     	mov	x2, x26
10052812c:     	mov	x3, x23
100528130:     	ldr	x5, [sp, #0xa0]
100528134:     	ldr	x9, [sp, #0x58]
100528138:     	blr	x9
10052813c:     	ldurb	w8, [x29, #-0x80]
100528140:     	cmp	w8, #0xff
100528144:     	b.ne	 <L29>
100528148:     	ldur	x8, [x29, #-0x78]
10052814c:     	cbz	x8,  <L16>
100528150:     	mov	w22, #0x1               ; =1
100528154:     	ldr	x21, [sp, #0x50]
<L8>:
100528158:     	ldr	x24, [sp, #0x40]
10052815c:     	ldp	x8, x9, [x24, #0x8]
100528160:     	cbz	x9,  <L11>
100528164:     	cmp	x9, #0x1
100528168:     	ldr	x15, [sp, #0x88]
10052816c:     	mov	x10, #0x0               ; =0
100528170:     	b.eq	 <L10>
100528174:     	mov	x11, x9
<L9>:
100528178:     	lsr	x12, x11, #1
10052817c:     	add	x13, x12, x10
100528180:     	madd	x14, x13, x20, x8
100528184:     	ldr	x14, [x14, #0x40]
100528188:     	cmp	x14, x26
10052818c:     	csel	x10, x10, x13, hi
100528190:     	sub	x11, x11, x12
100528194:     	cmp	x11, #0x1
100528198:     	b.hi	 <L9>
<L10>:
10052819c:     	madd	x11, x10, x20, x8
1005281a0:     	ldr	x11, [x11, #0x40]
1005281a4:     	cmp	x11, x26
1005281a8:     	b.eq	 <L12>
1005281ac:     	cinc	x10, x10, lo
1005281b0:     	subs	x10, x10, #0x1
1005281b4:     	csel	x10, xzr, x10, lo
1005281b8:     	b	 <L12>
<L11>:
1005281bc:     	mov	x10, x9
1005281c0:     	ldr	x15, [sp, #0x88]
<L12>:
1005281c4:     	cmp	x10, x9
1005281c8:     	b.hs	 <L20>
1005281cc:     	madd	x8, x10, x20, x8
1005281d0:     	ldr	x9, [x8, #0x40]
1005281d4:     	cmp	x26, x9
1005281d8:     	b.lo	 <L20>
1005281dc:     	ldr	x10, [x8, #0x48]
1005281e0:     	adds	x10, x10, x9
1005281e4:     	cset	w9, hs
1005281e8:     	cmp	x10, x15
1005281ec:     	ldr	x11, [sp, #0x80]
1005281f0:     	sbcs	xzr, x9, x11
1005281f4:     	b.lo	 <L21>
1005281f8:     	ldrb	w8, [x8, #0x50]
1005281fc:     	cmp	w8, #0x4
100528200:     	b.eq	 <L23>
100528204:     	str	w8, [sp, #0xb0]
100528208:     	sub	x8, x29, #0x80
10052820c:     	mov	x0, x24
100528210:     	mov	x1, x26
100528214:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
100528218:     	ldurb	w8, [x29, #-0x80]
10052821c:     	cmp	w8, #0xff
100528220:     	b.ne	 <L25>
100528224:     	ldr	x8, [sp, #0x118]
100528228:     	sub	x0, x8, #0x1
10052822c:     	cmp	x0, #0x4
100528230:     	b.hs	 <L44>
100528234:     	ldur	x23, [x29, #-0x78]
100528238:     	mov	w8, #0x18               ; =24
10052823c:     	add	x9, sp, #0xb8
100528240:     	madd	x8, x0, x8, x9
100528244:     	stp	x26, x23, [x8]
100528248:     	strh	w25, [x8, #0x10]
10052824c:     	strb	w21, [x8, #0x12]
100528250:     	tbz	w23, #0x0,  <L26>
100528254:     	ldr	x8, [sp, #0xa8]
100528258:     	and	x8, x23, x8
10052825c:     	and	x9, x23, #0x80
100528260:     	ldr	w10, [sp, #0xb4]
100528264:     	tbz	w10, #0x0,  <L13>
100528268:     	ldr	x10, [sp, #0x30]
10052826c:     	and	x10, x23, x10
100528270:     	cmp	x9, #0x0
100528274:     	csel	x8, x10, x8, ne
100528278:     	cset	w13, ne
10052827c:     	b	 <L14>
<L13>:
100528280:     	cmp	w21, #0x2
100528284:     	csel	x10, x9, xzr, lo
100528288:     	cmp	x9, #0x0
10052828c:     	ccmp	w21, #0x2, #0x0, ne
100528290:     	b.eq	 <L30>
100528294:     	mov	w13, #0x0               ; =0
100528298:     	orr	x8, x10, x8
<L14>:
10052829c:     	cbnz	x8,  <L27>
1005282a0:     	tbnz	w23, #0x5,  <L15>
1005282a4:     	mov	x1, x24
1005282a8:     	mov	x24, x13
1005282ac:     	orr	x21, x23, #0x20
1005282b0:     	sub	x8, x29, #0x80
1005282b4:     	orr	x4, x23, #0x20
1005282b8:     	ldp	x6, x0, [sp, #0x60]
1005282bc:     	mov	x2, x26
1005282c0:     	mov	x3, x23
1005282c4:     	ldr	x5, [sp, #0xa0]
1005282c8:     	ldr	x9, [sp, #0x58]
1005282cc:     	blr	x9
1005282d0:     	ldurb	w8, [x29, #-0x80]
1005282d4:     	cmp	w8, #0xff
1005282d8:     	b.ne	 <L29>
1005282dc:     	ldur	x8, [x29, #-0x78]
1005282e0:     	cbz	x8,  <L16>
1005282e4:     	cmp	w22, #0x10
1005282e8:     	add	w22, w22, #0x1
1005282ec:     	ldr	x21, [sp, #0x50]
1005282f0:     	b.ne	 <L8>
1005282f4:     	b	 <L33>
<L15>:
1005282f8:     	ldr	x3, [sp, #0x38]
1005282fc:     	ldp	w15, w2, [sp, #0x98]
100528300:     	ldr	w16, [sp, #0x94]
100528304:     	b	 <L17>
<L16>:
100528308:     	ldr	x0, [sp, #0x48]
10052830c:     	cmp	x0, #0x3
100528310:     	ldr	x3, [sp, #0x38]
100528314:     	ldp	w15, w2, [sp, #0x98]
100528318:     	ldr	w16, [sp, #0x94]
10052831c:     	b.hi	 <L45>
100528320:     	mov	x13, x24
100528324:     	add	x8, sp, #0x120
100528328:     	add	x8, x8, x0, lsl #5
10052832c:     	stp	x26, x23, [x8]
100528330:     	str	x21, [x8, #0x10]
100528334:     	ldr	x21, [sp, #0x50]
100528338:     	strb	w21, [x8, #0x18]
10052833c:     	strb	wzr, [x8, #0x19]
100528340:     	add	x0, x0, #0x1
100528344:     	str	x0, [sp, #0x48]
100528348:     	ldr	x24, [sp, #0x40]
<L17>:
10052834c:     	ubfx	x8, x23, #2, #1
100528350:     	and	w16, w16, w8
100528354:     	ubfx	x8, x23, #1, #1
100528358:     	and	w15, w15, w8
10052835c:     	lsr	x8, x23, #63
100528360:     	orr	w2, w2, w8
100528364:     	tbnz	w13, #0x0,  <L18>
100528368:     	add	x27, x27, #0x1
10052836c:     	and	x8, x23, #0xffffff000
100528370:     	cmp	w21, #0x3
100528374:     	csel	x28, x28, x8, eq
100528378:     	cmp	x27, #0x4
10052837c:     	b.ne	 <L0>
<L18>:
100528380:     	ldp	w0, w17, [sp, #0x24]
100528384:     	and	w8, w0, #0xff
100528388:     	cmp	w8, #0x2
10052838c:     	and	w8, w17, #0xff
100528390:     	ccmp	w8, #0x3, #0x0, ne
100528394:     	cset	w9, eq
100528398:     	b.ne	 <L31>
10052839c:     	eor	w8, w16, #0x1
1005283a0:     	ldr	w16, [sp, #0x2c]
1005283a4:     	and	w10, w16, #0xff
1005283a8:     	cmp	w10, #0x2
1005283ac:     	cset	w10, ne
1005283b0:     	orr	w10, w10, w15
1005283b4:     	add	x15, sp, #0x120
1005283b8:     	ldr	x12, [sp, #0x18]
1005283bc:     	tbnz	w10, #0x0,  <L32>
1005283c0:     	mov	w2, #0x0                ; =0
1005283c4:     	mov	w10, #0x1               ; =1
1005283c8:     	b	 <L37>
<L19>:
1005283cc:     	adrp	x8, 0x100817000 <_anon.2d7624cb36b6b54afd9d12c6d9d284da.1409+0xec0>
1005283d0:     	ldr	q0, [x8, #0x870]
1005283d4:     	str	q0, [x19]
1005283d8:     	str	x3, [x19, #0x10]
1005283dc:     	ldur	q0, [sp, #0xf8]
1005283e0:     	add	x8, sp, #0x9
1005283e4:     	ldur	q1, [x8, #0xff]
1005283e8:     	stp	q0, q1, [x19, #0x120]
1005283ec:     	ldr	x8, [sp, #0x118]
1005283f0:     	ldur	q0, [sp, #0xb8]
1005283f4:     	ldur	q1, [sp, #0xc8]
1005283f8:     	stp	q0, q1, [x19, #0xe0]
1005283fc:     	ldur	q0, [sp, #0xd8]
100528400:     	ldur	q1, [sp, #0xe8]
100528404:     	stp	q0, q1, [x19, #0x100]
100528408:     	ldp	q0, q1, [sp, #0x120]
10052840c:     	ldp	q2, q3, [x9, #0x20]
100528410:     	stp	q2, q3, [x19, #0x80]
100528414:     	stp	q0, q1, [x19, #0x60]
100528418:     	ldp	q0, q1, [x9, #0x40]
10052841c:     	ldp	q2, q3, [x9, #0x60]
100528420:     	stp	q2, q3, [x19, #0xc0]
100528424:     	stp	q0, q1, [x19, #0xa0]
100528428:     	stp	x8, xzr, [x19, #0x140]
10052842c:     	b	 <L42>
<L20>:
100528430:     	mov	w8, #0xa                ; =10
100528434:     	b	 <L22>
<L21>:
100528438:     	cmp	x26, x10
10052843c:     	ngcs	xzr, x9
100528440:     	cset	w8, lo
100528444:     	cmp	w8, #0x0
100528448:     	mov	w8, #0xa                ; =10
10052844c:     	cinc	w8, w8, ne
<L22>:
100528450:     	mov	w9, #0x8                ; =8
100528454:     	stp	x26, x9, [x29, #-0x78]
100528458:     	ldr	w9, [sp, #0xb0]
10052845c:     	b	 <L24>
<L23>:
100528460:     	mov	w9, #0x4                ; =4
100528464:     	mov	w8, #0xc                ; =12
<L24>:
100528468:     	sturb	w8, [x29, #-0x80]
10052846c:     	sturb	w9, [x29, #-0x7f]
<L25>:
100528470:     	add	x9, sp, #0x120
100528474:     	ldp	q0, q1, [x9, #0xe0]
100528478:     	stp	q0, q1, [x19, #0x10]
10052847c:     	adrp	x8, 0x1007e7000 <_anon.bd1ea81803b8ca00c3db2ae4266198e2.358+0x51>
100528480:     	ldr	q1, [x8, #0x440]
100528484:     	ldur	x8, [x29, #-0x60]
100528488:     	str	q1, [x19]
10052848c:     	stp	x8, x26, [x19, #0x30]
100528490:     	strb	w21, [x19, #0x40]
100528494:     	ldur	q0, [sp, #0xf8]
100528498:     	add	x8, sp, #0x9
10052849c:     	ldur	q1, [x8, #0xff]
1005284a0:     	stp	q0, q1, [x19, #0x120]
1005284a4:     	ldr	x8, [sp, #0x118]
1005284a8:     	ldur	q0, [sp, #0xb8]
1005284ac:     	ldur	q1, [sp, #0xc8]
1005284b0:     	stp	q0, q1, [x19, #0xe0]
1005284b4:     	ldur	q0, [sp, #0xd8]
1005284b8:     	ldur	q1, [sp, #0xe8]
1005284bc:     	stp	q0, q1, [x19, #0x100]
1005284c0:     	ldp	q1, q0, [x9, #0x60]
1005284c4:     	stp	q1, q0, [x19, #0xc0]
1005284c8:     	ldp	q1, q0, [x9, #0x40]
1005284cc:     	stp	q1, q0, [x19, #0xa0]
1005284d0:     	ldp	q1, q0, [x9, #0x20]
1005284d4:     	stp	q1, q0, [x19, #0x80]
1005284d8:     	ldp	q1, q0, [sp, #0x120]
1005284dc:     	stp	q1, q0, [x19, #0x60]
1005284e0:     	b	 <L41>
<L26>:
1005284e4:     	adrp	x8, 0x1007e7000 <_anon.bd1ea81803b8ca00c3db2ae4266198e2.358+0x51>
1005284e8:     	ldr	q0, [x8, #0x290]
1005284ec:     	ldr	x8, [sp, #0x18]
1005284f0:     	ubfx	x8, x8, #11, #1
1005284f4:     	ldp	w15, w14, [sp, #0x24]
1005284f8:     	and	w9, w15, #0xff
1005284fc:     	str	q0, [x19]
100528500:     	ldr	w13, [sp, #0x2c]
100528504:     	ands	w10, w13, #0xff
100528508:     	cset	w11, eq
10052850c:     	ldr	x12, [sp, #0x38]
100528510:     	str	x12, [x19, #0x10]
100528514:     	cmp	w10, #0x2
100528518:     	csel	w10, w10, wzr, eq
10052851c:     	and	w12, w14, #0xff
100528520:     	cmp	w12, #0x3
100528524:     	ccmp	w9, #0x2, #0x4, eq
100528528:     	mov	w9, #0x4                ; =4
10052852c:     	csel	w9, w9, wzr, ne
100528530:     	orr	w9, w10, w9
100528534:     	tst	w11, w8
100528538:     	mov	w8, #0x10               ; =16
10052853c:     	csel	w8, w8, wzr, ne
100528540:     	orr	w8, w9, w8
100528544:     	mov	w9, #0x1                ; =1
100528548:     	stp	w9, w8, [x19, #0x18]
10052854c:     	mov	w8, #0xe                ; =14
100528550:     	strb	w8, [x19, #0x20]
100528554:     	ldr	x8, [sp, #0x10]
100528558:     	str	x8, [x19, #0x28]
10052855c:     	strb	w15, [x19, #0x30]
100528560:     	strb	w14, [x19, #0x31]
100528564:     	strb	w13, [x19, #0x32]
100528568:     	strb	wzr, [x19, #0x38]
10052856c:     	strb	w21, [x19, #0x39]
100528570:     	b	 <L28>
<L27>:
100528574:     	adrp	x9, 0x1007e7000 <_anon.bd1ea81803b8ca00c3db2ae4266198e2.358+0x51>
100528578:     	ldr	q0, [x9, #0x290]
10052857c:     	ldr	x9, [sp, #0x18]
100528580:     	ubfx	x9, x9, #11, #1
100528584:     	ldp	w16, w15, [sp, #0x24]
100528588:     	and	w10, w16, #0xff
10052858c:     	str	q0, [x19]
100528590:     	ldr	w14, [sp, #0x2c]
100528594:     	ands	w11, w14, #0xff
100528598:     	cset	w12, eq
10052859c:     	ldr	x13, [sp, #0x38]
1005285a0:     	str	x13, [x19, #0x10]
1005285a4:     	cmp	w11, #0x2
1005285a8:     	mov	w11, #0x3               ; =3
1005285ac:     	csinc	w11, w11, wzr, eq
1005285b0:     	and	w13, w15, #0xff
1005285b4:     	tst	w12, w9
1005285b8:     	mov	w9, #0x10               ; =16
1005285bc:     	csel	w9, w9, wzr, ne
1005285c0:     	cmp	w13, #0x3
1005285c4:     	ccmp	w10, #0x2, #0x4, eq
1005285c8:     	mov	w10, #0x8               ; =8
1005285cc:     	mov	w12, #0xc               ; =12
1005285d0:     	csel	w10, w12, w10, ne
1005285d4:     	orr	w10, w10, w11
1005285d8:     	orr	w9, w10, w9
1005285dc:     	mov	w10, #0x1               ; =1
1005285e0:     	stp	w10, w9, [x19, #0x18]
1005285e4:     	mov	w9, #0xe                ; =14
1005285e8:     	strb	w9, [x19, #0x20]
1005285ec:     	ldr	x9, [sp, #0x10]
1005285f0:     	str	x9, [x19, #0x28]
1005285f4:     	strb	w16, [x19, #0x30]
1005285f8:     	strb	w15, [x19, #0x31]
1005285fc:     	strb	w14, [x19, #0x32]
100528600:     	strb	w10, [x19, #0x38]
100528604:     	strb	w21, [x19, #0x39]
100528608:     	str	x8, [x19, #0x40]
<L28>:
10052860c:     	ldur	q0, [sp, #0xf8]
100528610:     	add	x8, sp, #0x9
100528614:     	ldur	q1, [x8, #0xff]
100528618:     	stp	q0, q1, [x19, #0x120]
10052861c:     	ldr	x8, [sp, #0x118]
100528620:     	ldur	q0, [sp, #0xb8]
100528624:     	ldur	q1, [sp, #0xc8]
100528628:     	stp	q0, q1, [x19, #0xe0]
10052862c:     	ldur	q0, [sp, #0xd8]
100528630:     	ldur	q1, [sp, #0xe8]
100528634:     	stp	q0, q1, [x19, #0x100]
100528638:     	add	x9, sp, #0x120
10052863c:     	ldp	q0, q1, [x9, #0x40]
100528640:     	stp	q0, q1, [x19, #0xa0]
100528644:     	ldp	q0, q1, [x9, #0x60]
100528648:     	stp	q0, q1, [x19, #0xc0]
10052864c:     	ldp	q0, q1, [sp, #0x120]
100528650:     	stp	q0, q1, [x19, #0x60]
100528654:     	ldp	q0, q1, [x9, #0x20]
100528658:     	b	 <L40>
<L29>:
10052865c:     	add	x13, sp, #0x120
100528660:     	ldp	q0, q1, [x13, #0xe0]
100528664:     	stur	q0, [x19, #0x18]
100528668:     	stur	q1, [x19, #0x28]
10052866c:     	ldur	x9, [x29, #-0x60]
100528670:     	mov	w10, #0x2               ; =2
100528674:     	mov	w8, #0x41               ; =65
100528678:     	str	x9, [x19, #0x38]
10052867c:     	str	x10, [x19]
100528680:     	mov	w10, #0x40              ; =64
100528684:     	mov	w11, #0x10              ; =16
100528688:     	mov	w9, #0x7                ; =7
10052868c:     	mov	w12, #0x8               ; =8
100528690:     	ldr	x21, [sp, #0x50]
100528694:     	b	 <L34>
<L30>:
100528698:     	ldr	x9, [sp, #0x48]
10052869c:     	adrp	x8, 0x1007e7000 <_anon.bd1ea81803b8ca00c3db2ae4266198e2.358+0x51>
1005286a0:     	ldr	q0, [x8, #0x580]
1005286a4:     	str	q0, [x19]
1005286a8:     	stp	x26, x23, [x19, #0x10]
1005286ac:     	mov	w8, #0x2                ; =2
1005286b0:     	strb	w8, [x19, #0x20]
1005286b4:     	ldur	q0, [sp, #0xf8]
1005286b8:     	add	x8, sp, #0x9
1005286bc:     	ldur	q1, [x8, #0xff]
1005286c0:     	stp	q0, q1, [x19, #0x120]
1005286c4:     	ldr	x8, [sp, #0x118]
1005286c8:     	ldur	q0, [sp, #0xb8]
1005286cc:     	ldur	q1, [sp, #0xc8]
1005286d0:     	stp	q0, q1, [x19, #0xe0]
1005286d4:     	ldur	q0, [sp, #0xd8]
1005286d8:     	ldur	q1, [sp, #0xe8]
1005286dc:     	stp	q0, q1, [x19, #0x100]
1005286e0:     	add	x10, sp, #0x120
1005286e4:     	ldp	q0, q1, [x10, #0x40]
1005286e8:     	stp	q0, q1, [x19, #0xa0]
1005286ec:     	ldp	q0, q1, [x10, #0x60]
1005286f0:     	stp	q0, q1, [x19, #0xc0]
1005286f4:     	ldp	q0, q1, [sp, #0x120]
1005286f8:     	stp	q0, q1, [x19, #0x60]
1005286fc:     	ldp	q0, q1, [x10, #0x20]
100528700:     	stp	q0, q1, [x19, #0x80]
100528704:     	stp	x8, x9, [x19, #0x140]
100528708:     	b	 <L42>
<L31>:
10052870c:     	ldr	w16, [sp, #0x2c]
100528710:     	and	w8, w16, #0xff
100528714:     	cmp	w8, #0x2
100528718:     	cset	w8, ne
10052871c:     	orr	w8, w8, w15
100528720:     	add	x15, sp, #0x120
100528724:     	ldr	x12, [sp, #0x18]
100528728:     	tbz	w8, #0x0,  <L35>
10052872c:     	mov	w8, #0x0                ; =0
<L32>:
100528730:     	mov	w10, #0x0               ; =0
100528734:     	tst	w16, #0xff
100528738:     	b.ne	 <L36>
10052873c:     	tbz	w12, #0xb,  <L36>
100528740:     	mov	w10, #0x0               ; =0
100528744:     	tbnz	w8, #0x0,  <L37>
100528748:     	tbz	w2, #0x0,  <L38>
10052874c:     	b	 <L37>
<L33>:
100528750:     	mov	x9, x26
100528754:     	ldur	x26, [x29, #-0x70]
100528758:     	mov	w8, #0x21               ; =33
10052875c:     	adrp	x10, 0x10082b000 <_anon.03b29b8dd92ce13e390a628bebbb0ed7.3159+0x6e4>
100528760:     	ldr	q0, [x10, #0x400]
100528764:     	str	q0, [x19]
100528768:     	mov	w10, #0x20              ; =32
10052876c:     	mov	w11, #0x18              ; =24
100528770:     	mov	w12, #0x10              ; =16
100528774:     	add	x13, sp, #0x120
<L34>:
100528778:     	str	x9, [x19, x12]
10052877c:     	str	x26, [x19, x11]
100528780:     	strb	w21, [x19, x10]
100528784:     	strb	wzr, [x19, x8]
100528788:     	ldur	q0, [sp, #0xf8]
10052878c:     	add	x8, sp, #0x9
100528790:     	ldur	q1, [x8, #0xff]
100528794:     	stp	q0, q1, [x19, #0x120]
100528798:     	ldr	x8, [sp, #0x118]
10052879c:     	ldur	q0, [sp, #0xb8]
1005287a0:     	ldur	q1, [sp, #0xc8]
1005287a4:     	stp	q0, q1, [x19, #0xe0]
1005287a8:     	ldur	q0, [sp, #0xd8]
1005287ac:     	ldur	q1, [sp, #0xe8]
1005287b0:     	stp	q0, q1, [x19, #0x100]
1005287b4:     	ldp	q0, q1, [sp, #0x120]
1005287b8:     	ldp	q2, q3, [x13, #0x20]
1005287bc:     	stp	q2, q3, [x19, #0x80]
1005287c0:     	stp	q0, q1, [x19, #0x60]
1005287c4:     	ldp	q0, q1, [x13, #0x40]
1005287c8:     	ldp	q2, q3, [x13, #0x60]
1005287cc:     	stp	q2, q3, [x19, #0xc0]
1005287d0:     	stp	q0, q1, [x19, #0xa0]
1005287d4:     	b	 <L41>
<L35>:
1005287d8:     	mov	w8, #0x0                ; =0
1005287dc:     	ldr	x10, [sp, #0x8]
1005287e0:     	ldr	w10, [x10]
1005287e4:     	ubfx	w10, w10, #16, #1
<L36>:
1005287e8:     	orr	w11, w8, w10
1005287ec:     	cbz	w11,  <L38>
1005287f0:     	mov	w2, #0x0                ; =0
<L37>:
1005287f4:     	adrp	x11, 0x1007e7000 <_anon.bd1ea81803b8ca00c3db2ae4266198e2.358+0x51>
1005287f8:     	ldr	q0, [x11, #0x290]
1005287fc:     	ubfx	x11, x12, #11, #1
100528800:     	ands	w12, w16, #0xff
100528804:     	str	q0, [x19]
100528808:     	cset	w13, eq
10052880c:     	cmp	w12, #0x2
100528810:     	str	x3, [x19, #0x10]
100528814:     	mov	w12, #0x3               ; =3
100528818:     	csinc	w12, w12, wzr, eq
10052881c:     	mov	w14, #0x4               ; =4
100528820:     	cmp	w9, #0x0
100528824:     	csel	w9, w14, wzr, ne
100528828:     	tst	w13, w11
10052882c:     	mov	w11, #0x10              ; =16
100528830:     	csel	w11, w11, wzr, ne
100528834:     	orr	w11, w12, w11
100528838:     	orr	w9, w11, w9
10052883c:     	mov	w11, #0x1               ; =1
100528840:     	stp	w11, w9, [x19, #0x18]
100528844:     	mov	w9, #0xe                ; =14
100528848:     	strb	w9, [x19, #0x20]
10052884c:     	ldr	x9, [sp, #0x10]
100528850:     	str	x9, [x19, #0x28]
100528854:     	strb	w0, [x19, #0x30]
100528858:     	strb	w17, [x19, #0x31]
10052885c:     	strb	w16, [x19, #0x32]
100528860:     	mov	w9, #0x2                ; =2
100528864:     	strb	w9, [x19, #0x38]
100528868:     	strb	w8, [x19, #0x39]
10052886c:     	strb	w10, [x19, #0x3a]
100528870:     	strb	w2, [x19, #0x3b]
100528874:     	ldur	q0, [sp, #0xf8]
100528878:     	add	x8, sp, #0x9
10052887c:     	ldur	q1, [x8, #0xff]
100528880:     	stp	q0, q1, [x19, #0x120]
100528884:     	ldr	x8, [sp, #0x118]
100528888:     	ldur	q0, [sp, #0xb8]
10052888c:     	ldur	q1, [sp, #0xc8]
100528890:     	stp	q0, q1, [x19, #0xe0]
100528894:     	ldur	q0, [sp, #0xd8]
100528898:     	ldur	q1, [sp, #0xe8]
10052889c:     	stp	q0, q1, [x19, #0x100]
1005288a0:     	b	 <L39>
<L38>:
1005288a4:     	orr	x8, x23, #0x20
1005288a8:     	cmp	w13, #0x0
1005288ac:     	mov	w9, #0xfff              ; =4095
1005288b0:     	ldp	q0, q1, [x15, #0x80]
1005288b4:     	mov	w10, #0x1fffff          ; =2097151
1005288b8:     	csel	x9, x10, x9, ne
1005288bc:     	and	x10, x9, #0x1ff000
1005288c0:     	eor	x10, x10, #0xffffff000
1005288c4:     	stp	q0, q1, [x19]
1005288c8:     	and	x10, x10, x23
1005288cc:     	and	x9, x9, x3
1005288d0:     	orr	x9, x10, x9
1005288d4:     	mov	w10, #0x2               ; =2
1005288d8:     	ldp	q0, q1, [x15, #0xa0]
1005288dc:     	cinc	w10, w10, eq
1005288e0:     	stp	q0, q1, [x19, #0x20]
1005288e4:     	stp	x9, x26, [x19, #0x40]
1005288e8:     	str	x8, [x19, #0x50]
1005288ec:     	strb	w10, [x19, #0x58]
1005288f0:     	ldur	q0, [sp, #0xb8]
1005288f4:     	ldur	q1, [sp, #0xc8]
1005288f8:     	stp	q0, q1, [x19, #0xe0]
1005288fc:     	ldur	q0, [sp, #0xd8]
100528900:     	ldur	q1, [sp, #0xe8]
100528904:     	stp	q0, q1, [x19, #0x100]
100528908:     	ldur	q0, [sp, #0xf8]
10052890c:     	add	x8, sp, #0x9
100528910:     	ldur	q1, [x8, #0xff]
100528914:     	stp	q0, q1, [x19, #0x120]
100528918:     	ldr	x8, [sp, #0x118]
<L39>:
10052891c:     	ldp	q0, q1, [x15, #0x40]
100528920:     	stp	q0, q1, [x19, #0xa0]
100528924:     	ldp	q0, q1, [x15, #0x60]
100528928:     	stp	q0, q1, [x19, #0xc0]
10052892c:     	ldp	q0, q1, [sp, #0x120]
100528930:     	stp	q0, q1, [x19, #0x60]
100528934:     	ldp	q0, q1, [x15, #0x20]
<L40>:
100528938:     	stp	q0, q1, [x19, #0x80]
<L41>:
10052893c:     	str	x8, [x19, #0x140]
100528940:     	ldr	x8, [sp, #0x48]
100528944:     	str	x8, [x19, #0x148]
<L42>:
100528948:     	add	sp, sp, #0x230
10052894c:     	ldp	x29, x30, [sp, #0x50]
100528950:     	ldp	x20, x19, [sp, #0x40]
100528954:     	ldp	x22, x21, [sp, #0x30]
100528958:     	ldp	x24, x23, [sp, #0x20]
10052895c:     	ldp	x26, x25, [sp, #0x10]
100528960:     	ldp	x28, x27, [sp], #0x60
100528964:     	ret
<L43>:
100528968:     	adrp	x2, 0x100a1d000 <_anon.d8f0d5429d0dfb72cd66b77c259e4f75.106+0x60>
10052896c:     	add	x2, x2, #0x570
100528970:     	mov	w1, #0x4                ; =4
100528974:     	bl	 <core::panicking::panic_bounds_check>
<L44>:
100528978:     	adrp	x2, 0x100a1d000 <_anon.d8f0d5429d0dfb72cd66b77c259e4f75.106+0x60>
10052897c:     	add	x2, x2, #0x588
100528980:     	mov	w1, #0x4                ; =4
100528984:     	bl	 <core::panicking::panic_bounds_check>
<L45>:
100528988:     	adrp	x2, 0x100a1d000 <_anon.d8f0d5429d0dfb72cd66b77c259e4f75.106+0x60>
10052898c:     	add	x2, x2, #0x5a0
100528990:     	mov	w1, #0x4                ; =4
100528994:     	bl	 <core::panicking::panic_bounds_check>
		...
