
/private/tmp/s507-stage5-bench/target-candidate/release/deps/od_machine-533ce3e3cf110c1e:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001003f8258 <od_machine::page_walk::stage5_page_walk_candidate_benchmark::run_first_ad_batch>:
1003f8258:     	stp	x28, x27, [sp, #-0x60]!
1003f825c:     	stp	x26, x25, [sp, #0x10]
1003f8260:     	stp	x24, x23, [sp, #0x20]
1003f8264:     	stp	x22, x21, [sp, #0x30]
1003f8268:     	stp	x20, x19, [sp, #0x40]
1003f826c:     	stp	x29, x30, [sp, #0x50]
1003f8270:     	add	x29, sp, #0x50
1003f8274:     	sub	sp, sp, #0x2e0
1003f8278:     	mov	x19, x1
1003f827c:     	mov	x20, x0
1003f8280:     	ldr	x8, [x0, #0x28]
1003f8284:     	cbz	x8,  <L1>
1003f8288:     	ldr	x21, [x20, #0x20]
1003f828c:     	add	x22, x21, x8, lsl #4
<L0>:
1003f8290:     	ldp	x1, x8, [x21], #0x10
1003f8294:     	str	x8, [sp, #0x180]
1003f8298:     	add	x8, sp, #0x30
1003f829c:     	add	x2, sp, #0x180
1003f82a0:     	mov	x0, x20
1003f82a4:     	mov	w3, #0x8                ; =8
1003f82a8:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::write_bytes::<<od_machine::ap_legacy_exec::BoardRam as od_isa::real_mode_exec::RealModeMemory>::write_u8::{closure#0}>>
1003f82ac:     	ldrb	w8, [sp, #0x30]
1003f82b0:     	cmp	w8, #0xff
1003f82b4:     	b.ne	 <L5>
1003f82b8:     	cmp	x21, x22
1003f82bc:     	b.ne	 <L0>
<L1>:
1003f82c0:     	bl	 <<std::time::Instant>::now>
1003f82c4:     	str	x0, [sp, #0x20]
1003f82c8:     	str	w1, [sp, #0x28]
1003f82cc:     	ldr	x8, [x20, #0x40]
1003f82d0:     	cbz	x8,  <L4>
1003f82d4:     	ldr	x21, [x20, #0x38]
1003f82d8:     	lsl	x22, x8, #4
1003f82dc:     	mov	w23, #0x1               ; =1
1003f82e0:     	adrp	x24, 0x1009fc000 <_anon.c25e69b08e751ac8d5dda9545cde2439.1765+0x178>
1003f82e4:     	add	x24, x24, #0x7b0
1003f82e8:     	sub	x25, x29, #0x51
1003f82ec:     	add	x26, sp, #0x180
1003f82f0:     	adrp	x27, 0x1009fc000 <_anon.c25e69b08e751ac8d5dda9545cde2439.1765+0x178>
1003f82f4:     	add	x27, x27, #0x838
1003f82f8:     	b	 <L3>
<L2>:
1003f82fc:     	subs	x22, x22, #0x10
1003f8300:     	b.eq	 <L4>
<L3>:
1003f8304:     	ldr	x3, [x21], #0x10
1003f8308:     	strb	w23, [sp, #0x18]
1003f830c:     	stp	x25, x24, [sp, #0x8]
1003f8310:     	add	x8, sp, #0x30
1003f8314:     	add	x1, x20, #0x48
1003f8318:     	sub	x7, x29, #0x51
1003f831c:     	str	x27, [sp]
1003f8320:     	mov	x0, x20
1003f8324:     	mov	w2, #0x1234             ; =4660
1003f8328:     	mov	w4, #0x0                ; =0
1003f832c:     	mov	w5, #0x0                ; =0
1003f8330:     	mov	x6, x19
1003f8334:     	bl	 <od_machine::page_walk::walk_long64_4k_with_writer>
1003f8338:     	add	x0, sp, #0x180
1003f833c:     	add	x1, sp, #0x30
1003f8340:     	mov	w2, #0x150              ; =336
1003f8344:     	bl	 <dyld_stub_binder+0x1007d4a1c>
1003f8348:     	ldr	x8, [sp, #0x180]
1003f834c:     	cmp	x8, #0x2
1003f8350:     	b.ne	 <L2>
1003f8354:     	ldr	x8, [sp, #0x188]
1003f8358:     	cmp	x8, #0xb
1003f835c:     	b.lo	 <L2>
1003f8360:     	ldr	x1, [sp, #0x190]
1003f8364:     	cbz	x1,  <L2>
1003f8368:     	ldr	x0, [sp, #0x198]
1003f836c:     	mov	w2, #0x1                ; =1
1003f8370:     	bl	 <__rustc::__rust_dealloc>
1003f8374:     	b	 <L2>
<L4>:
1003f8378:     	add	x0, sp, #0x20
1003f837c:     	bl	 <<std::time::Instant>::elapsed>
1003f8380:     	mov	w8, #0xca00             ; =51712
1003f8384:     	movk	w8, #0x3b9a, lsl #16
1003f8388:     	mul	x8, x0, x8
1003f838c:     	add	x0, x8, w1, uxtw
1003f8390:     	add	sp, sp, #0x2e0
1003f8394:     	ldp	x29, x30, [sp, #0x50]
1003f8398:     	ldp	x20, x19, [sp, #0x40]
1003f839c:     	ldp	x22, x21, [sp, #0x30]
1003f83a0:     	ldp	x24, x23, [sp, #0x20]
1003f83a4:     	ldp	x26, x25, [sp, #0x10]
1003f83a8:     	ldp	x28, x27, [sp], #0x60
1003f83ac:     	ret
<L5>:
1003f83b0:     	ldp	q0, q1, [sp, #0x30]
1003f83b4:     	stp	q0, q1, [sp, #0x180]
1003f83b8:     	ldr	x8, [sp, #0x50]
1003f83bc:     	str	x8, [sp, #0x1a0]
1003f83c0:     	adrp	x0, 0x100818000 <_anon.c25e69b08e751ac8d5dda9545cde2439.556+0x20>
1003f83c4:     	add	x0, x0, #0x12f
1003f83c8:     	adrp	x3, 0x1009f7000 <_anon.2d7624cb36b6b54afd9d12c6d9d284da.1414+0x6218>
1003f83cc:     	add	x3, x3, #0x808
1003f83d0:     	adrp	x4, 0x1009fc000 <_anon.c25e69b08e751ac8d5dda9545cde2439.1765+0x178>
1003f83d4:     	add	x4, x4, #0x860
1003f83d8:     	add	x2, sp, #0x180
1003f83dc:     	mov	w1, #0x2b               ; =43
1003f83e0:     	bl	 <core::result::unwrap_failed>
