
/private/tmp/s507-stage5-bench/target-baseline/release/deps/od_machine-533ce3e3cf110c1e:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001003c82f0 <od_machine::page_walk::stage5_page_walk_candidate_benchmark::run_first_ad_batch>:
1003c82f0:     	stp	x28, x27, [sp, #-0x60]!
1003c82f4:     	stp	x26, x25, [sp, #0x10]
1003c82f8:     	stp	x24, x23, [sp, #0x20]
1003c82fc:     	stp	x22, x21, [sp, #0x30]
1003c8300:     	stp	x20, x19, [sp, #0x40]
1003c8304:     	stp	x29, x30, [sp, #0x50]
1003c8308:     	add	x29, sp, #0x50
1003c830c:     	sub	sp, sp, #0x2e0
1003c8310:     	mov	x19, x1
1003c8314:     	mov	x20, x0
1003c8318:     	ldr	x8, [x0, #0x28]
1003c831c:     	cbz	x8,  <L1>
1003c8320:     	ldr	x21, [x20, #0x20]
1003c8324:     	add	x22, x21, x8, lsl #4
<L0>:
1003c8328:     	ldp	x1, x8, [x21], #0x10
1003c832c:     	str	x8, [sp, #0x180]
1003c8330:     	add	x8, sp, #0x30
1003c8334:     	add	x2, sp, #0x180
1003c8338:     	mov	x0, x20
1003c833c:     	mov	w3, #0x8                ; =8
1003c8340:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::write_bytes::<<od_machine::ap_legacy_exec::BoardRam as od_isa::real_mode_exec::RealModeMemory>::write_u8::{closure#0}>>
1003c8344:     	ldrb	w8, [sp, #0x30]
1003c8348:     	cmp	w8, #0xff
1003c834c:     	b.ne	 <L5>
1003c8350:     	cmp	x21, x22
1003c8354:     	b.ne	 <L0>
<L1>:
1003c8358:     	bl	 <<std::time::Instant>::now>
1003c835c:     	str	x0, [sp, #0x20]
1003c8360:     	str	w1, [sp, #0x28]
1003c8364:     	ldr	x8, [x20, #0x40]
1003c8368:     	cbz	x8,  <L4>
1003c836c:     	ldr	x21, [x20, #0x38]
1003c8370:     	lsl	x22, x8, #4
1003c8374:     	mov	w23, #0x1               ; =1
1003c8378:     	adrp	x24, 0x1009e9000 <_anon.5e6b932036fdec284a79ecd881dcd45b.2746+0xa38>
1003c837c:     	add	x24, x24, #0x3d0
1003c8380:     	sub	x25, x29, #0x51
1003c8384:     	add	x26, sp, #0x180
1003c8388:     	adrp	x27, 0x1009e9000 <_anon.5e6b932036fdec284a79ecd881dcd45b.2746+0xa38>
1003c838c:     	add	x27, x27, #0x458
1003c8390:     	b	 <L3>
<L2>:
1003c8394:     	subs	x22, x22, #0x10
1003c8398:     	b.eq	 <L4>
<L3>:
1003c839c:     	ldr	x3, [x21], #0x10
1003c83a0:     	strb	w23, [sp, #0x18]
1003c83a4:     	stp	x25, x24, [sp, #0x8]
1003c83a8:     	add	x8, sp, #0x30
1003c83ac:     	add	x1, x20, #0x48
1003c83b0:     	sub	x7, x29, #0x51
1003c83b4:     	str	x27, [sp]
1003c83b8:     	mov	x0, x20
1003c83bc:     	mov	w2, #0x1234             ; =4660
1003c83c0:     	mov	w4, #0x0                ; =0
1003c83c4:     	mov	w5, #0x0                ; =0
1003c83c8:     	mov	x6, x19
1003c83cc:     	bl	 <od_machine::page_walk::walk_long64_4k_with_writer>
1003c83d0:     	add	x0, sp, #0x180
1003c83d4:     	add	x1, sp, #0x30
1003c83d8:     	mov	w2, #0x150              ; =336
1003c83dc:     	bl	 <dyld_stub_binder+0x1007cf19c>
1003c83e0:     	ldr	x8, [sp, #0x180]
1003c83e4:     	cmp	x8, #0x2
1003c83e8:     	b.ne	 <L2>
1003c83ec:     	ldr	x8, [sp, #0x188]
1003c83f0:     	cmp	x8, #0xb
1003c83f4:     	b.lo	 <L2>
1003c83f8:     	ldr	x1, [sp, #0x190]
1003c83fc:     	cbz	x1,  <L2>
1003c8400:     	ldr	x0, [sp, #0x198]
1003c8404:     	mov	w2, #0x1                ; =1
1003c8408:     	bl	 <__rustc::__rust_dealloc>
1003c840c:     	b	 <L2>
<L4>:
1003c8410:     	add	x0, sp, #0x20
1003c8414:     	bl	 <<std::time::Instant>::elapsed>
1003c8418:     	mov	w8, #0xca00             ; =51712
1003c841c:     	movk	w8, #0x3b9a, lsl #16
1003c8420:     	mul	x8, x0, x8
1003c8424:     	add	x0, x8, w1, uxtw
1003c8428:     	add	sp, sp, #0x2e0
1003c842c:     	ldp	x29, x30, [sp, #0x50]
1003c8430:     	ldp	x20, x19, [sp, #0x40]
1003c8434:     	ldp	x22, x21, [sp, #0x30]
1003c8438:     	ldp	x24, x23, [sp, #0x20]
1003c843c:     	ldp	x26, x25, [sp, #0x10]
1003c8440:     	ldp	x28, x27, [sp], #0x60
1003c8444:     	ret
<L5>:
1003c8448:     	ldp	q0, q1, [sp, #0x30]
1003c844c:     	stp	q0, q1, [sp, #0x180]
1003c8450:     	ldr	x8, [sp, #0x50]
1003c8454:     	str	x8, [sp, #0x1a0]
1003c8458:     	adrp	x0, 0x10080a000 <_anon.a86c0f9c22846514d6613526b04d73a2.3300+0x1538>
1003c845c:     	add	x0, x0, #0x70d
1003c8460:     	adrp	x3, 0x1009db000 <_anon.a86c0f9c22846514d6613526b04d73a2.3402+0xf88>
1003c8464:     	add	x3, x3, #0x378
1003c8468:     	adrp	x4, 0x1009e9000 <_anon.5e6b932036fdec284a79ecd881dcd45b.2746+0xa38>
1003c846c:     	add	x4, x4, #0x480
1003c8470:     	add	x2, sp, #0x180
1003c8474:     	mov	w1, #0x2b               ; =43
1003c8478:     	bl	 <core::result::unwrap_failed>
