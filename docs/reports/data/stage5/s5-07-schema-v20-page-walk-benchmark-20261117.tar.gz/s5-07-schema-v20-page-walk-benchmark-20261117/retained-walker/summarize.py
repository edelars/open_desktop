from collections import defaultdict
from pathlib import Path
from statistics import median
from struct import iter_unpack

root = Path(__file__).resolve().parent
data = defaultdict(list)
for side in ('baseline', 'candidate'):
    for sample in range(1, 6):
        log = (root / f'{side}-{sample}.log').read_text()
        assert '1 passed; 0 failed' in log
        for row in log.splitlines():
            if row.startswith('BENCH_FIRST_AD,'):
                _, build, run, leaf, access, *rest = row.split(',')
                fields = dict(field.split('=', 1) for field in rest)
                paths, cycles, calls, timed_ns = (int(fields[k]) for k in ('paths', 'cycles', 'calls', 'timed_ns'))
                times = [ns for (ns,) in iter_unpack('<Q', Path(fields['raw_batch_path']).read_bytes())]
                assert paths == 512 and calls == paths * cycles
                assert len(times) == cycles and sum(times) == timed_ns
                assert (build, int(run)) == (side, sample)
                data[leaf, access, 'first-A', side].append((timed_ns / calls, timed_ns))
            if row.startswith('BENCH_WARM,'):
                _, build, run, leaf, access, calls, timed_ns, _, physical = row.split(',')
                assert (build, int(run)) == (side, sample)
                data[leaf, access.lower(), 'warm-A', side].append((int(timed_ns) / int(calls), int(timed_ns)))

for leaf in ('4k', '2m'):
    for access in ('read', 'write'):
        for state in ('first-A', 'warm-A'):
            baseline = data[leaf, access, state, 'baseline']
            candidate = data[leaf, access, state, 'candidate']
            assert len(baseline) == len(candidate) == 5
            base, cand = (list(ns for ns, elapsed in points) for points in (baseline, candidate))
            shortest_ms = min(elapsed for points in [baseline, candidate] for ns, elapsed in points) / 1e6
            paired = [(new / old - 1) * 100 for old, new in zip(base, cand)]
            print(f'{leaf} {access} {state}: {median(base):.3f} → {median(cand):.3f} ns/walk ({(median(cand) / median(base) - 1) * 100:+.2f}%)')
            print(f'  B [{min(base):.3f}, {max(base):.3f}], C [{min(cand):.3f}, {max(cand):.3f}], shortest {shortest_ms:.1f} ms, paired {[round(p,2) for p in paired]}')
