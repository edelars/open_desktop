from pathlib import Path
import difflib
import re
import subprocess

workspace = Path('/private/tmp/s507-stage5-bench')
report_dir = workspace / 'retained-walker'
walker = 'od_machine::page_walk::walk_long64_4k_with_writer'
harness = 'od_machine::page_walk::stage5_page_walk_candidate_benchmark::run_first_ad_batch'
blocks = {}
for side in ['baseline', 'candidate']:
    binary = workspace / f'target-{side}/release/deps/od_machine-533ce3e3cf110c1e'
    symbols = subprocess.check_output(['xcrun', 'llvm-nm', '-C', '-n', str(binary)], text=True)
    entries = [(int(m[1], 16), m[2]) for line in symbols.splitlines()
               if (m := re.match(r'^([0-9a-f]+) [tT] (.+)$', line))]
    for symbol, label in [(walker, 'walker'), (harness, 'first-ad-harness')]:
        start, = [address for address, name in entries if name == symbol]
        end = min(address for address, _ in entries if address > start)
        section = subprocess.check_output([
            'xcrun', 'llvm-objdump', '--disassemble', '--demangle', '--no-show-raw-insn',
            '--symbolize-operands', f'--start-address={start:#x}', f'--stop-address={end:#x}', str(binary)
        ], text=True)
        (report_dir / f'{side}-{label}.asm').write_text(section)
        blocks[side, label] = [
            m[1].split(';')[0].strip() for line in section.splitlines()
            if (m := re.search(r'^\s*[0-9a-f]+:\s+(\S.*)$', line))
        ]
for label in ['walker', 'first-ad-harness']:
    baseline = blocks['baseline', label]
    candidate = blocks['candidate', label]
    diff = list(difflib.unified_diff(baseline, candidate, fromfile='baseline', tofile='candidate', lineterm=''))
    (report_dir / f'{label}-codegen.diff').write_text('\n'.join(diff) + ('\n' if diff else ''))
    print(f'{label} baseline={len(baseline)} candidate={len(candidate)} identical={not diff} diff_lines={len(diff)}')
