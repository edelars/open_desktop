#!/usr/bin/env python3
from pathlib import Path
import statistics
p=Path(__file__).parent
values={}
for f in p.glob('*.log'):
    for line in f.read_text().splitlines():
        if line.startswith('BENCH_FIRST_AD,'):
            _, build, sample, leaf, access, *rest=line.split(',')
            fields=dict(x.split('=',1) for x in rest if '=' in x)
            values[(int(sample), build.split('-')[0], leaf, access.lower(), 'first-A')]=float(fields['ns_per_call'])
        elif line.startswith('BENCH_WARM,'):
            _, build, sample, leaf, access, calls, elapsed, ns, *_=line.split(',')
            values[(int(sample), build.split('-')[0], leaf, access.lower(), 'warm-A')]=float(ns)
print('case; B->C paired deltas (%); median; C->B paired deltas (%); median')
for leaf in ('4k','2m'):
  for access in ('read','write'):
    for state in ('first-A','warm-A'):
      d={i:100*(values[(i,'candidate',leaf,access,state)]/values[(i,'baseline',leaf,access,state)]-1) for i in range(1,7)}
      bc=[d[i] for i in (1,3,5)]; cb=[d[i] for i in (2,4,6)]
      print(f'{leaf} {access} {state}; {bc} ; {statistics.median(bc):+.2f}; {cb} ; {statistics.median(cb):+.2f}')
