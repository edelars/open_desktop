
/private/tmp/s507-stage5-bench/target-candidate/release/deps/od_machine-533ce3e3cf110c1e:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004ef200 <od_machine::page_walk::walk_long64_4k_with_writer>:
1004ef200:     	stp	x28, x27, [sp, #-0x60]!
1004ef204:     	stp	x26, x25, [sp, #0x10]
1004ef208:     	stp	x24, x23, [sp, #0x20]
1004ef20c:     	stp	x22, x21, [sp, #0x30]
1004ef210:     	stp	x20, x19, [sp, #0x40]
1004ef214:     	stp	x29, x30, [sp, #0x50]
1004ef218:     	add	x29, sp, #0x50
1004ef21c:     	sub	sp, sp, #0x240
1004ef220:     	str	x7, [sp, #0xa8]
1004ef224:     	mov	x19, x8
1004ef228:     	mov	w8, #0xff               ; =255
1004ef22c:     	strb	w8, [sp, #0xda]
1004ef230:     	strb	w8, [sp, #0xf2]
1004ef234:     	strb	w8, [sp, #0x10a]
1004ef238:     	strb	w8, [sp, #0x122]
1004ef23c:     	str	xzr, [sp, #0x128]
1004ef240:     	mov	w8, #0x2                ; =2
1004ef244:     	strb	w8, [sp, #0x149]
1004ef248:     	lsr	x9, x3, #48
1004ef24c:     	sbfx	x10, x3, #47, #1
1004ef250:     	strb	w8, [sp, #0x169]
1004ef254:     	strb	w8, [sp, #0x189]
1004ef258:     	cmp	x9, w10, uxth
1004ef25c:     	add	x9, sp, #0x130
1004ef260:     	strb	w8, [sp, #0x1a9]
1004ef264:     	b.ne	 <L23>
1004ef268:     	str	x2, [sp, #0x10]
1004ef26c:     	stp	w4, w5, [sp, #0x24]
1004ef270:     	str	w6, [sp, #0x2c]
1004ef274:     	str	wzr, [sp, #0xb4]
1004ef278:     	str	xzr, [sp, #0x48]
1004ef27c:     	mov	w2, #0x0                ; =0
1004ef280:     	mov	x27, #0x0               ; =0
1004ef284:     	ldrb	w8, [x29, #0x28]
1004ef288:     	str	w8, [sp, #0x78]
1004ef28c:     	ldp	x9, x8, [x29, #0x18]
1004ef290:     	str	x9, [sp, #0x60]
1004ef294:     	ldr	x9, [x29, #0x10]
1004ef298:     	str	x9, [sp, #0x58]
1004ef29c:     	ldr	x9, [x1, #0x8]
1004ef2a0:     	stur	xzr, [x29, #-0xe0]
1004ef2a4:     	stur	xzr, [x29, #-0xd0]
1004ef2a8:     	stur	xzr, [x29, #-0xc0]
1004ef2ac:     	stur	xzr, [x29, #-0xb0]
1004ef2b0:     	and	x15, x9, #0xffffff000
1004ef2b4:     	mov	w9, #0x4                ; =4
1004ef2b8:     	stur	x9, [x29, #-0x98]
1004ef2bc:     	sub	x9, x29, #0xa0
1004ef2c0:     	add	x11, x9, #0x10
1004ef2c4:     	mov	w9, #0x100              ; =256
1004ef2c8:     	movk	w9, #0x302, lsl #16
1004ef2cc:     	stur	w9, [x29, #-0x90]
1004ef2d0:     	str	x1, [sp, #0x8]
1004ef2d4:     	ldr	x9, [x1, #0x18]
1004ef2d8:     	str	x9, [sp, #0x18]
1004ef2dc:     	tst	x9, #0x800
1004ef2e0:     	mov	x9, #0xffff000000000    ; =4503530907893760
1004ef2e4:     	stur	xzr, [x29, #-0x88]
1004ef2e8:     	mov	x10, #0xfff000000000    ; =281406257233920
1004ef2ec:     	movk	x10, #0x800f, lsl #48
1004ef2f0:     	csel	x9, x10, x9, eq
1004ef2f4:     	str	x9, [sp, #0xc0]
1004ef2f8:     	orr	x9, x9, #0x80
1004ef2fc:     	stp	x9, x11, [sp, #0x68]
1004ef300:     	mov	w23, #0x58              ; =88
1004ef304:     	ldr	x8, [x8, #0x20]
1004ef308:     	str	x8, [sp, #0x50]
1004ef30c:     	mov	w1, #0x1                ; =1
1004ef310:     	mov	w4, #0x1                ; =1
1004ef314:     	str	x3, [sp, #0x38]
<L0>:
1004ef318:     	ldr	x8, [sp, #0x70]
1004ef31c:     	ldrb	w24, [x8, x27]
1004ef320:     	orr	x8, x24, x24, lsl #3
1004ef324:     	mov	w9, #0x27               ; =39
1004ef328:     	sub	x8, x9, x8
1004ef32c:     	sub	x9, x29, #0xe0
1004ef330:     	add	x9, x9, x27, lsl #4
1004ef334:     	mov	w10, #0x1               ; =1
1004ef338:     	stp	x10, x15, [x9]
1004ef33c:     	lsr	x20, x3, x8
1004ef340:     	ubfiz	x8, x20, #3, #9
1004ef344:     	orr	x26, x8, x15
1004ef348:     	cmp	w24, #0x2
1004ef34c:     	ldr	w8, [sp, #0x78]
1004ef350:     	csel	w21, wzr, w8, ne
1004ef354:     	ldr	x8, [sp, #0xc0]
1004ef358:     	ldr	x9, [sp, #0x68]
1004ef35c:     	csel	x8, x9, x8, lo
1004ef360:     	str	x8, [sp, #0xb8]
1004ef364:     	ldp	x8, x9, [x0, #0x8]
1004ef368:     	adds	x16, x26, #0x8
1004ef36c:     	cset	w17, hs
1004ef370:     	cbz	x9,  <L1>
1004ef374:     	cmp	x9, #0x1
1004ef378:     	b.ne	 <L2>
1004ef37c:     	mov	x10, #0x0               ; =0
1004ef380:     	b	 <L4>
<L1>:
1004ef384:     	mov	x10, x9
1004ef388:     	b	 <L5>
<L2>:
1004ef38c:     	mov	x10, #0x0               ; =0
1004ef390:     	mov	x11, x9
<L3>:
1004ef394:     	lsr	x12, x11, #1
1004ef398:     	add	x13, x12, x10
1004ef39c:     	madd	x14, x13, x23, x8
1004ef3a0:     	ldr	x14, [x14, #0x40]
1004ef3a4:     	cmp	x14, x26
1004ef3a8:     	csel	x10, x10, x13, hi
1004ef3ac:     	sub	x11, x11, x12
1004ef3b0:     	cmp	x11, #0x1
1004ef3b4:     	b.hi	 <L3>
<L4>:
1004ef3b8:     	madd	x11, x10, x23, x8
1004ef3bc:     	ldr	x11, [x11, #0x40]
1004ef3c0:     	cmp	x11, x26
1004ef3c4:     	b.eq	 <L5>
1004ef3c8:     	cinc	x10, x10, lo
1004ef3cc:     	subs	x10, x10, #0x1
1004ef3d0:     	csel	x10, xzr, x10, lo
<L5>:
1004ef3d4:     	cmp	x10, x9
1004ef3d8:     	b.hs	 <L24>
1004ef3dc:     	madd	x8, x10, x23, x8
1004ef3e0:     	ldr	x9, [x8, #0x40]
1004ef3e4:     	cmp	x26, x9
1004ef3e8:     	b.lo	 <L24>
1004ef3ec:     	ldr	x10, [x8, #0x48]
1004ef3f0:     	adds	x10, x10, x9
1004ef3f4:     	cset	w9, hs
1004ef3f8:     	cmp	x10, x16
1004ef3fc:     	sbcs	xzr, x9, x17
1004ef400:     	b.lo	 <L25>
1004ef404:     	ldrb	w8, [x8, #0x50]
1004ef408:     	cmp	w8, #0x4
1004ef40c:     	b.eq	 <L27>
1004ef410:     	stp	x17, x16, [sp, #0x80]
1004ef414:     	stp	w4, w1, [sp, #0x90]
1004ef418:     	str	x15, [sp, #0x98]
1004ef41c:     	str	w8, [sp, #0xb4]
1004ef420:     	str	w2, [sp, #0xa4]
1004ef424:     	sub	x8, x29, #0x80
1004ef428:     	mov	x28, x0
1004ef42c:     	mov	x1, x26
1004ef430:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004ef434:     	ldurb	w8, [x29, #-0x80]
1004ef438:     	cmp	w8, #0xff
1004ef43c:     	b.ne	 <L29>
1004ef440:     	ldr	x0, [sp, #0x128]
1004ef444:     	cmp	x0, #0x3
1004ef448:     	b.hi	 <L46>
1004ef44c:     	and	w25, w20, #0x1ff
1004ef450:     	ldur	x20, [x29, #-0x78]
1004ef454:     	mov	w8, #0x18               ; =24
1004ef458:     	add	x9, sp, #0xc8
1004ef45c:     	madd	x8, x0, x8, x9
1004ef460:     	stp	x26, x20, [x8]
1004ef464:     	strh	w25, [x8, #0x10]
1004ef468:     	strb	w24, [x8, #0x12]
1004ef46c:     	ldr	x8, [sp, #0x128]
1004ef470:     	add	x8, x8, #0x1
1004ef474:     	str	x8, [sp, #0x128]
1004ef478:     	tbz	w20, #0x0,  <L30>
1004ef47c:     	ldr	x8, [sp, #0xb8]
1004ef480:     	orr	x9, x8, #0x1fe000
1004ef484:     	str	w21, [sp, #0x7c]
1004ef488:     	tbz	w21, #0x0,  <L6>
1004ef48c:     	and	x8, x20, #0x80
1004ef490:     	ubfx	x22, x20, #7, #1
1004ef494:     	cmp	x8, #0x0
1004ef498:     	eor	w8, w22, #0x1
1004ef49c:     	csel	w8, wzr, w8, eq
1004ef4a0:     	tbz	w8, #0x0,  <L7>
1004ef4a4:     	b	 <L32>
<L6>:
1004ef4a8:     	cmp	w24, #0x2
1004ef4ac:     	b.ne	 <L8>
1004ef4b0:     	mov	w22, #0x0               ; =0
1004ef4b4:     	and	x8, x20, #0x80
1004ef4b8:     	cmp	x8, #0x0
1004ef4bc:     	eor	w8, w22, #0x1
1004ef4c0:     	csel	w8, wzr, w8, eq
1004ef4c4:     	tbnz	w8, #0x0,  <L32>
<L7>:
1004ef4c8:     	cmp	w22, #0x0
1004ef4cc:     	ldr	x8, [sp, #0xc0]
1004ef4d0:     	csel	x8, x9, x8, ne
1004ef4d4:     	ands	x8, x8, x20
1004ef4d8:     	b.eq	 <L9>
1004ef4dc:     	b	 <L31>
<L8>:
1004ef4e0:     	mov	w22, #0x0               ; =0
1004ef4e4:     	ldr	x8, [sp, #0xb8]
1004ef4e8:     	ands	x8, x8, x20
1004ef4ec:     	b.ne	 <L31>
<L9>:
1004ef4f0:     	tbnz	w20, #0x5,  <L19>
1004ef4f4:     	str	x9, [sp, #0x30]
1004ef4f8:     	str	x24, [sp, #0x40]
1004ef4fc:     	orr	x24, x20, #0x20
1004ef500:     	sub	x8, x29, #0x80
1004ef504:     	orr	x4, x20, #0x20
1004ef508:     	ldp	x6, x0, [sp, #0x58]
1004ef50c:     	mov	x1, x28
1004ef510:     	mov	x2, x26
1004ef514:     	mov	x3, x20
1004ef518:     	ldr	x5, [sp, #0xa8]
1004ef51c:     	ldr	x9, [sp, #0x50]
1004ef520:     	blr	x9
1004ef524:     	ldurb	w8, [x29, #-0x80]
1004ef528:     	cmp	w8, #0xff
1004ef52c:     	b.ne	 <L33>
1004ef530:     	ldur	x8, [x29, #-0x78]
1004ef534:     	cbz	x8,  <L20>
1004ef538:     	mov	w21, #0x1               ; =1
1004ef53c:     	ldr	x24, [sp, #0x40]
<L10>:
1004ef540:     	mov	x0, x28
1004ef544:     	ldp	x8, x9, [x28, #0x8]
1004ef548:     	cbz	x9,  <L13>
1004ef54c:     	cmp	x9, #0x1
1004ef550:     	ldr	w22, [sp, #0x7c]
1004ef554:     	mov	x10, #0x0               ; =0
1004ef558:     	b.eq	 <L12>
1004ef55c:     	mov	x11, x9
<L11>:
1004ef560:     	lsr	x12, x11, #1
1004ef564:     	add	x13, x12, x10
1004ef568:     	madd	x14, x13, x23, x8
1004ef56c:     	ldr	x14, [x14, #0x40]
1004ef570:     	cmp	x14, x26
1004ef574:     	csel	x10, x10, x13, hi
1004ef578:     	sub	x11, x11, x12
1004ef57c:     	cmp	x11, #0x1
1004ef580:     	b.hi	 <L11>
<L12>:
1004ef584:     	madd	x11, x10, x23, x8
1004ef588:     	ldr	x11, [x11, #0x40]
1004ef58c:     	cmp	x11, x26
1004ef590:     	b.eq	 <L14>
1004ef594:     	cinc	x10, x10, lo
1004ef598:     	subs	x10, x10, #0x1
1004ef59c:     	csel	x10, xzr, x10, lo
1004ef5a0:     	b	 <L14>
<L13>:
1004ef5a4:     	mov	x10, x9
1004ef5a8:     	ldr	w22, [sp, #0x7c]
<L14>:
1004ef5ac:     	cmp	x10, x9
1004ef5b0:     	b.hs	 <L24>
1004ef5b4:     	madd	x8, x10, x23, x8
1004ef5b8:     	ldr	x9, [x8, #0x40]
1004ef5bc:     	cmp	x26, x9
1004ef5c0:     	b.lo	 <L24>
1004ef5c4:     	ldr	x10, [x8, #0x48]
1004ef5c8:     	adds	x10, x10, x9
1004ef5cc:     	cset	w9, hs
1004ef5d0:     	ldr	x11, [sp, #0x88]
1004ef5d4:     	cmp	x10, x11
1004ef5d8:     	ldr	x11, [sp, #0x80]
1004ef5dc:     	sbcs	xzr, x9, x11
1004ef5e0:     	b.lo	 <L25>
1004ef5e4:     	ldrb	w8, [x8, #0x50]
1004ef5e8:     	cmp	w8, #0x4
1004ef5ec:     	b.eq	 <L27>
1004ef5f0:     	str	w8, [sp, #0xb4]
1004ef5f4:     	sub	x8, x29, #0x80
1004ef5f8:     	mov	x1, x26
1004ef5fc:     	bl	 <<od_machine::physical_memory::PhysicalMemory>::read_u64>
1004ef600:     	ldurb	w8, [x29, #-0x80]
1004ef604:     	cmp	w8, #0xff
1004ef608:     	b.ne	 <L29>
1004ef60c:     	ldr	x8, [sp, #0x128]
1004ef610:     	sub	x0, x8, #0x1
1004ef614:     	cmp	x0, #0x4
1004ef618:     	b.hs	 <L47>
1004ef61c:     	ldur	x20, [x29, #-0x78]
1004ef620:     	mov	w8, #0x18               ; =24
1004ef624:     	add	x9, sp, #0xc8
1004ef628:     	madd	x8, x0, x8, x9
1004ef62c:     	stp	x26, x20, [x8]
1004ef630:     	strh	w25, [x8, #0x10]
1004ef634:     	strb	w24, [x8, #0x12]
1004ef638:     	tbz	w20, #0x0,  <L30>
1004ef63c:     	tbz	w22, #0x0,  <L15>
1004ef640:     	and	x8, x20, #0x80
1004ef644:     	ubfx	x22, x20, #7, #1
1004ef648:     	ldr	x9, [sp, #0x30]
1004ef64c:     	cmp	x8, #0x0
1004ef650:     	eor	w8, w22, #0x1
1004ef654:     	csel	w8, wzr, w8, eq
1004ef658:     	tbz	w8, #0x0,  <L16>
1004ef65c:     	b	 <L32>
<L15>:
1004ef660:     	cmp	w24, #0x2
1004ef664:     	ldr	x9, [sp, #0x30]
1004ef668:     	mov	w22, #0x0               ; =0
1004ef66c:     	b.ne	 <L17>
1004ef670:     	and	x8, x20, #0x80
1004ef674:     	cmp	x8, #0x0
1004ef678:     	eor	w8, w22, #0x1
1004ef67c:     	csel	w8, wzr, w8, eq
1004ef680:     	tbnz	w8, #0x0,  <L32>
<L16>:
1004ef684:     	cmp	w22, #0x0
1004ef688:     	ldr	x8, [sp, #0xc0]
1004ef68c:     	csel	x8, x9, x8, ne
1004ef690:     	ands	x8, x8, x20
1004ef694:     	b.eq	 <L18>
1004ef698:     	b	 <L31>
<L17>:
1004ef69c:     	ldr	x8, [sp, #0xb8]
1004ef6a0:     	ands	x8, x8, x20
1004ef6a4:     	b.ne	 <L31>
<L18>:
1004ef6a8:     	tbnz	w20, #0x5,  <L19>
1004ef6ac:     	orr	x24, x20, #0x20
1004ef6b0:     	sub	x8, x29, #0x80
1004ef6b4:     	orr	x4, x20, #0x20
1004ef6b8:     	ldp	x6, x0, [sp, #0x58]
1004ef6bc:     	mov	x1, x28
1004ef6c0:     	mov	x2, x26
1004ef6c4:     	mov	x3, x20
1004ef6c8:     	ldr	x5, [sp, #0xa8]
1004ef6cc:     	ldr	x9, [sp, #0x50]
1004ef6d0:     	blr	x9
1004ef6d4:     	ldurb	w8, [x29, #-0x80]
1004ef6d8:     	cmp	w8, #0xff
1004ef6dc:     	b.ne	 <L33>
1004ef6e0:     	ldur	x8, [x29, #-0x78]
1004ef6e4:     	cbz	x8,  <L20>
1004ef6e8:     	cmp	w21, #0x10
1004ef6ec:     	add	w21, w21, #0x1
1004ef6f0:     	ldr	x24, [sp, #0x40]
1004ef6f4:     	b.ne	 <L10>
1004ef6f8:     	b	 <L36>
<L19>:
1004ef6fc:     	ldr	x3, [sp, #0x38]
1004ef700:     	ldr	w2, [sp, #0xa4]
1004ef704:     	b	 <L21>
<L20>:
1004ef708:     	ldr	x0, [sp, #0x48]
1004ef70c:     	cmp	x0, #0x3
1004ef710:     	ldr	x3, [sp, #0x38]
1004ef714:     	ldr	w2, [sp, #0xa4]
1004ef718:     	b.hi	 <L48>
1004ef71c:     	add	x8, sp, #0x130
1004ef720:     	add	x8, x8, x0, lsl #5
1004ef724:     	stp	x26, x20, [x8]
1004ef728:     	str	x24, [x8, #0x10]
1004ef72c:     	ldr	x24, [sp, #0x40]
1004ef730:     	strb	w24, [x8, #0x18]
1004ef734:     	strb	wzr, [x8, #0x19]
1004ef738:     	add	x0, x0, #0x1
1004ef73c:     	str	x0, [sp, #0x48]
<L21>:
1004ef740:     	mov	x0, x28
1004ef744:     	ubfx	x8, x20, #2, #1
1004ef748:     	ldp	w4, w1, [sp, #0x90]
1004ef74c:     	and	w4, w4, w8
1004ef750:     	ubfx	x8, x20, #1, #1
1004ef754:     	and	w1, w1, w8
1004ef758:     	lsr	x8, x20, #63
1004ef75c:     	orr	w2, w2, w8
1004ef760:     	ldr	x15, [sp, #0x98]
1004ef764:     	tbnz	w22, #0x0,  <L22>
1004ef768:     	add	x27, x27, #0x1
1004ef76c:     	and	x8, x20, #0xffffff000
1004ef770:     	cmp	w24, #0x3
1004ef774:     	csel	x15, x15, x8, eq
1004ef778:     	cmp	x27, #0x4
1004ef77c:     	b.ne	 <L0>
<L22>:
1004ef780:     	ldp	w17, w16, [sp, #0x24]
1004ef784:     	and	w8, w17, #0xff
1004ef788:     	cmp	w8, #0x2
1004ef78c:     	and	w8, w16, #0xff
1004ef790:     	ccmp	w8, #0x3, #0x0, ne
1004ef794:     	cset	w9, eq
1004ef798:     	b.ne	 <L34>
1004ef79c:     	eor	w8, w4, #0x1
1004ef7a0:     	ldr	w15, [sp, #0x2c]
1004ef7a4:     	and	w10, w15, #0xff
1004ef7a8:     	cmp	w10, #0x2
1004ef7ac:     	cset	w10, ne
1004ef7b0:     	orr	w10, w10, w1
1004ef7b4:     	ldr	x12, [sp, #0x18]
1004ef7b8:     	tbnz	w10, #0x0,  <L35>
1004ef7bc:     	mov	w2, #0x0                ; =0
1004ef7c0:     	mov	w10, #0x1               ; =1
1004ef7c4:     	b	 <L40>
<L23>:
1004ef7c8:     	adrp	x8, 0x10082c000 <_anon.46955161eb1c9d064970950154d48426.3215+0x580>
1004ef7cc:     	ldr	q0, [x8, #0xa70]
1004ef7d0:     	str	q0, [x19]
1004ef7d4:     	str	x3, [x19, #0x10]
1004ef7d8:     	add	x8, sp, #0x9
1004ef7dc:     	ldur	q0, [x8, #0xff]
1004ef7e0:     	add	x8, sp, #0x19
1004ef7e4:     	ldur	q1, [x8, #0xff]
1004ef7e8:     	stp	q0, q1, [x19, #0x120]
1004ef7ec:     	ldr	x8, [sp, #0x128]
1004ef7f0:     	ldur	q0, [sp, #0xc8]
1004ef7f4:     	ldur	q1, [sp, #0xd8]
1004ef7f8:     	stp	q0, q1, [x19, #0xe0]
1004ef7fc:     	ldur	q0, [sp, #0xe8]
1004ef800:     	ldur	q1, [sp, #0xf8]
1004ef804:     	stp	q0, q1, [x19, #0x100]
1004ef808:     	ldp	q0, q1, [sp, #0x130]
1004ef80c:     	ldp	q2, q3, [x9, #0x20]
1004ef810:     	stp	q2, q3, [x19, #0x80]
1004ef814:     	stp	q0, q1, [x19, #0x60]
1004ef818:     	ldp	q0, q1, [x9, #0x40]
1004ef81c:     	ldp	q2, q3, [x9, #0x60]
1004ef820:     	stp	q2, q3, [x19, #0xc0]
1004ef824:     	stp	q0, q1, [x19, #0xa0]
1004ef828:     	stp	x8, xzr, [x19, #0x140]
1004ef82c:     	b	 <L44>
<L24>:
1004ef830:     	mov	w8, #0xa                ; =10
1004ef834:     	b	 <L26>
<L25>:
1004ef838:     	cmp	x26, x10
1004ef83c:     	ngcs	xzr, x9
1004ef840:     	cset	w8, lo
1004ef844:     	cmp	w8, #0x0
1004ef848:     	mov	w8, #0xa                ; =10
1004ef84c:     	cinc	w8, w8, ne
<L26>:
1004ef850:     	mov	w9, #0x8                ; =8
1004ef854:     	stp	x26, x9, [x29, #-0x78]
1004ef858:     	ldr	w9, [sp, #0xb4]
1004ef85c:     	b	 <L28>
<L27>:
1004ef860:     	mov	w9, #0x4                ; =4
1004ef864:     	mov	w8, #0xc                ; =12
<L28>:
1004ef868:     	sturb	w8, [x29, #-0x80]
1004ef86c:     	sturb	w9, [x29, #-0x7f]
<L29>:
1004ef870:     	add	x9, sp, #0x130
1004ef874:     	ldp	q0, q1, [x9, #0xe0]
1004ef878:     	stp	q0, q1, [x19, #0x10]
1004ef87c:     	adrp	x8, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef880:     	ldr	q1, [x8, #0xfc0]
1004ef884:     	ldur	x8, [x29, #-0x60]
1004ef888:     	str	q1, [x19]
1004ef88c:     	stp	x8, x26, [x19, #0x30]
1004ef890:     	strb	w24, [x19, #0x40]
1004ef894:     	add	x8, sp, #0x9
1004ef898:     	ldur	q0, [x8, #0xff]
1004ef89c:     	add	x8, sp, #0x19
1004ef8a0:     	ldur	q1, [x8, #0xff]
1004ef8a4:     	stp	q0, q1, [x19, #0x120]
1004ef8a8:     	ldr	x8, [sp, #0x128]
1004ef8ac:     	ldur	q0, [sp, #0xc8]
1004ef8b0:     	ldur	q1, [sp, #0xd8]
1004ef8b4:     	stp	q0, q1, [x19, #0xe0]
1004ef8b8:     	ldur	q0, [sp, #0xe8]
1004ef8bc:     	ldur	q1, [sp, #0xf8]
1004ef8c0:     	stp	q0, q1, [x19, #0x100]
1004ef8c4:     	ldp	q1, q0, [x9, #0x60]
1004ef8c8:     	stp	q1, q0, [x19, #0xc0]
1004ef8cc:     	ldp	q1, q0, [x9, #0x40]
1004ef8d0:     	stp	q1, q0, [x19, #0xa0]
1004ef8d4:     	ldp	q1, q0, [x9, #0x20]
1004ef8d8:     	stp	q1, q0, [x19, #0x80]
1004ef8dc:     	ldp	q1, q0, [sp, #0x130]
1004ef8e0:     	stp	q1, q0, [x19, #0x60]
1004ef8e4:     	b	 <L43>
<L30>:
1004ef8e8:     	adrp	x8, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef8ec:     	ldr	q0, [x8, #0xe10]
1004ef8f0:     	ldr	x8, [sp, #0x18]
1004ef8f4:     	ubfx	x8, x8, #11, #1
1004ef8f8:     	ldp	w15, w14, [sp, #0x24]
1004ef8fc:     	and	w9, w15, #0xff
1004ef900:     	str	q0, [x19]
1004ef904:     	ldr	w13, [sp, #0x2c]
1004ef908:     	ands	w10, w13, #0xff
1004ef90c:     	cset	w11, eq
1004ef910:     	ldr	x12, [sp, #0x38]
1004ef914:     	str	x12, [x19, #0x10]
1004ef918:     	cmp	w10, #0x2
1004ef91c:     	csel	w10, w10, wzr, eq
1004ef920:     	and	w12, w14, #0xff
1004ef924:     	cmp	w12, #0x3
1004ef928:     	ccmp	w9, #0x2, #0x4, eq
1004ef92c:     	mov	w9, #0x4                ; =4
1004ef930:     	csel	w9, w9, wzr, ne
1004ef934:     	orr	w9, w10, w9
1004ef938:     	tst	w11, w8
1004ef93c:     	mov	w8, #0x10               ; =16
1004ef940:     	csel	w8, w8, wzr, ne
1004ef944:     	orr	w8, w9, w8
1004ef948:     	mov	w9, #0x1                ; =1
1004ef94c:     	stp	w9, w8, [x19, #0x18]
1004ef950:     	mov	w8, #0xe                ; =14
1004ef954:     	strb	w8, [x19, #0x20]
1004ef958:     	ldr	x8, [sp, #0x10]
1004ef95c:     	str	x8, [x19, #0x28]
1004ef960:     	strb	w15, [x19, #0x30]
1004ef964:     	strb	w14, [x19, #0x31]
1004ef968:     	strb	w13, [x19, #0x32]
1004ef96c:     	strb	wzr, [x19, #0x38]
1004ef970:     	strb	w24, [x19, #0x39]
1004ef974:     	b	 <L41>
<L31>:
1004ef978:     	adrp	x9, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004ef97c:     	ldr	q0, [x9, #0xe10]
1004ef980:     	ldr	x9, [sp, #0x18]
1004ef984:     	ubfx	x9, x9, #11, #1
1004ef988:     	ldp	w16, w15, [sp, #0x24]
1004ef98c:     	and	w10, w16, #0xff
1004ef990:     	str	q0, [x19]
1004ef994:     	ldr	w14, [sp, #0x2c]
1004ef998:     	ands	w11, w14, #0xff
1004ef99c:     	cset	w12, eq
1004ef9a0:     	ldr	x13, [sp, #0x38]
1004ef9a4:     	str	x13, [x19, #0x10]
1004ef9a8:     	cmp	w11, #0x2
1004ef9ac:     	mov	w11, #0x3               ; =3
1004ef9b0:     	csinc	w11, w11, wzr, eq
1004ef9b4:     	and	w13, w15, #0xff
1004ef9b8:     	tst	w12, w9
1004ef9bc:     	mov	w9, #0x10               ; =16
1004ef9c0:     	csel	w9, w9, wzr, ne
1004ef9c4:     	cmp	w13, #0x3
1004ef9c8:     	ccmp	w10, #0x2, #0x4, eq
1004ef9cc:     	mov	w10, #0x8               ; =8
1004ef9d0:     	mov	w12, #0xc               ; =12
1004ef9d4:     	csel	w10, w12, w10, ne
1004ef9d8:     	orr	w10, w10, w11
1004ef9dc:     	orr	w9, w10, w9
1004ef9e0:     	mov	w10, #0x1               ; =1
1004ef9e4:     	stp	w10, w9, [x19, #0x18]
1004ef9e8:     	mov	w9, #0xe                ; =14
1004ef9ec:     	strb	w9, [x19, #0x20]
1004ef9f0:     	ldr	x9, [sp, #0x10]
1004ef9f4:     	str	x9, [x19, #0x28]
1004ef9f8:     	strb	w16, [x19, #0x30]
1004ef9fc:     	strb	w15, [x19, #0x31]
1004efa00:     	strb	w14, [x19, #0x32]
1004efa04:     	strb	w10, [x19, #0x38]
1004efa08:     	strb	w24, [x19, #0x39]
1004efa0c:     	str	x8, [x19, #0x40]
1004efa10:     	b	 <L41>
<L32>:
1004efa14:     	adrp	x8, 0x1007e4000 <_anon.bd1ea81803b8ca00c3db2ae4266198e2.358+0x4d1>
1004efa18:     	ldr	q0, [x8, #0x100]
1004efa1c:     	str	q0, [x19]
1004efa20:     	stp	x26, x20, [x19, #0x10]
1004efa24:     	strb	w24, [x19, #0x20]
1004efa28:     	add	x8, sp, #0x9
1004efa2c:     	ldur	q0, [x8, #0xff]
1004efa30:     	add	x8, sp, #0x19
1004efa34:     	ldur	q1, [x8, #0xff]
1004efa38:     	stp	q0, q1, [x19, #0x120]
1004efa3c:     	ldr	x8, [sp, #0x128]
1004efa40:     	ldur	q0, [sp, #0xc8]
1004efa44:     	ldur	q1, [sp, #0xd8]
1004efa48:     	stp	q0, q1, [x19, #0xe0]
1004efa4c:     	ldur	q0, [sp, #0xe8]
1004efa50:     	ldur	q1, [sp, #0xf8]
1004efa54:     	stp	q0, q1, [x19, #0x100]
1004efa58:     	add	x9, sp, #0x130
1004efa5c:     	ldp	q1, q0, [x9, #0x20]
1004efa60:     	stp	q1, q0, [x19, #0x80]
1004efa64:     	ldp	q1, q0, [sp, #0x130]
1004efa68:     	stp	q1, q0, [x19, #0x60]
1004efa6c:     	ldp	q1, q0, [x9, #0x60]
1004efa70:     	stp	q1, q0, [x19, #0xc0]
1004efa74:     	ldp	q1, q0, [x9, #0x40]
1004efa78:     	stp	q1, q0, [x19, #0xa0]
1004efa7c:     	b	 <L43>
<L33>:
1004efa80:     	add	x13, sp, #0x130
1004efa84:     	ldp	q0, q1, [x13, #0xe0]
1004efa88:     	stur	q0, [x19, #0x18]
1004efa8c:     	stur	q1, [x19, #0x28]
1004efa90:     	ldur	x9, [x29, #-0x60]
1004efa94:     	mov	w10, #0x2               ; =2
1004efa98:     	mov	w8, #0x41               ; =65
1004efa9c:     	str	x9, [x19, #0x38]
1004efaa0:     	str	x10, [x19]
1004efaa4:     	mov	w10, #0x40              ; =64
1004efaa8:     	mov	w11, #0x10              ; =16
1004efaac:     	mov	w9, #0x7                ; =7
1004efab0:     	mov	w12, #0x8               ; =8
1004efab4:     	ldr	x24, [sp, #0x40]
1004efab8:     	b	 <L37>
<L34>:
1004efabc:     	ldr	w15, [sp, #0x2c]
1004efac0:     	and	w8, w15, #0xff
1004efac4:     	cmp	w8, #0x2
1004efac8:     	cset	w8, ne
1004efacc:     	orr	w8, w8, w1
1004efad0:     	ldr	x12, [sp, #0x18]
1004efad4:     	tbz	w8, #0x0,  <L38>
1004efad8:     	mov	w8, #0x0                ; =0
<L35>:
1004efadc:     	mov	w10, #0x0               ; =0
1004efae0:     	tst	w15, #0xff
1004efae4:     	b.ne	 <L39>
1004efae8:     	tbz	w12, #0xb,  <L39>
1004efaec:     	mov	w10, #0x0               ; =0
1004efaf0:     	tbnz	w8, #0x0,  <L40>
1004efaf4:     	tbz	w2, #0x0,  <L45>
1004efaf8:     	b	 <L40>
<L36>:
1004efafc:     	mov	x9, x26
1004efb00:     	ldur	x26, [x29, #-0x70]
1004efb04:     	mov	w8, #0x21               ; =33
1004efb08:     	adrp	x10, 0x100839000 <_anon.ff0337c78e95b70e8401eb32eaf46e94.1617+0x2fb>
1004efb0c:     	ldr	q0, [x10, #0xba0]
1004efb10:     	str	q0, [x19]
1004efb14:     	mov	w10, #0x20              ; =32
1004efb18:     	mov	w11, #0x18              ; =24
1004efb1c:     	mov	w12, #0x10              ; =16
1004efb20:     	add	x13, sp, #0x130
<L37>:
1004efb24:     	str	x9, [x19, x12]
1004efb28:     	str	x26, [x19, x11]
1004efb2c:     	strb	w24, [x19, x10]
1004efb30:     	strb	wzr, [x19, x8]
1004efb34:     	add	x8, sp, #0x9
1004efb38:     	ldur	q0, [x8, #0xff]
1004efb3c:     	add	x8, sp, #0x19
1004efb40:     	ldur	q1, [x8, #0xff]
1004efb44:     	stp	q0, q1, [x19, #0x120]
1004efb48:     	ldr	x8, [sp, #0x128]
1004efb4c:     	ldur	q0, [sp, #0xc8]
1004efb50:     	ldur	q1, [sp, #0xd8]
1004efb54:     	stp	q0, q1, [x19, #0xe0]
1004efb58:     	ldur	q0, [sp, #0xe8]
1004efb5c:     	ldur	q1, [sp, #0xf8]
1004efb60:     	stp	q0, q1, [x19, #0x100]
1004efb64:     	ldp	q0, q1, [sp, #0x130]
1004efb68:     	ldp	q2, q3, [x13, #0x20]
1004efb6c:     	stp	q2, q3, [x19, #0x80]
1004efb70:     	stp	q0, q1, [x19, #0x60]
1004efb74:     	ldp	q0, q1, [x13, #0x40]
1004efb78:     	ldp	q2, q3, [x13, #0x60]
1004efb7c:     	stp	q2, q3, [x19, #0xc0]
1004efb80:     	stp	q0, q1, [x19, #0xa0]
1004efb84:     	b	 <L43>
<L38>:
1004efb88:     	mov	w8, #0x0                ; =0
1004efb8c:     	ldr	x10, [sp, #0x8]
1004efb90:     	ldr	w10, [x10]
1004efb94:     	ubfx	w10, w10, #16, #1
<L39>:
1004efb98:     	orr	w11, w8, w10
1004efb9c:     	cbz	w11,  <L45>
1004efba0:     	mov	w2, #0x0                ; =0
<L40>:
1004efba4:     	adrp	x11, 0x1007e3000 <dyld_stub_binder+0x1007e3000>
1004efba8:     	ldr	q0, [x11, #0xe10]
1004efbac:     	ubfx	x11, x12, #11, #1
1004efbb0:     	ands	w12, w15, #0xff
1004efbb4:     	str	q0, [x19]
1004efbb8:     	cset	w13, eq
1004efbbc:     	cmp	w12, #0x2
1004efbc0:     	str	x3, [x19, #0x10]
1004efbc4:     	mov	w12, #0x3               ; =3
1004efbc8:     	csinc	w12, w12, wzr, eq
1004efbcc:     	mov	w14, #0x4               ; =4
1004efbd0:     	cmp	w9, #0x0
1004efbd4:     	csel	w9, w14, wzr, ne
1004efbd8:     	tst	w13, w11
1004efbdc:     	mov	w11, #0x10              ; =16
1004efbe0:     	csel	w11, w11, wzr, ne
1004efbe4:     	orr	w11, w12, w11
1004efbe8:     	orr	w9, w11, w9
1004efbec:     	mov	w11, #0x1               ; =1
1004efbf0:     	stp	w11, w9, [x19, #0x18]
1004efbf4:     	mov	w9, #0xe                ; =14
1004efbf8:     	strb	w9, [x19, #0x20]
1004efbfc:     	ldr	x9, [sp, #0x10]
1004efc00:     	str	x9, [x19, #0x28]
1004efc04:     	strb	w17, [x19, #0x30]
1004efc08:     	strb	w16, [x19, #0x31]
1004efc0c:     	strb	w15, [x19, #0x32]
1004efc10:     	mov	w9, #0x2                ; =2
1004efc14:     	strb	w9, [x19, #0x38]
1004efc18:     	strb	w8, [x19, #0x39]
1004efc1c:     	strb	w10, [x19, #0x3a]
1004efc20:     	strb	w2, [x19, #0x3b]
<L41>:
1004efc24:     	add	x8, sp, #0x9
1004efc28:     	ldur	q0, [x8, #0xff]
1004efc2c:     	add	x8, sp, #0x19
1004efc30:     	ldur	q1, [x8, #0xff]
1004efc34:     	stp	q0, q1, [x19, #0x120]
1004efc38:     	ldr	x8, [sp, #0x128]
1004efc3c:     	ldur	q0, [sp, #0xc8]
1004efc40:     	ldur	q1, [sp, #0xd8]
1004efc44:     	stp	q0, q1, [x19, #0xe0]
1004efc48:     	ldur	q0, [sp, #0xe8]
1004efc4c:     	ldur	q1, [sp, #0xf8]
1004efc50:     	stp	q0, q1, [x19, #0x100]
1004efc54:     	add	x9, sp, #0x130
1004efc58:     	ldp	q0, q1, [x9, #0x40]
1004efc5c:     	stp	q0, q1, [x19, #0xa0]
1004efc60:     	ldp	q0, q1, [x9, #0x60]
1004efc64:     	stp	q0, q1, [x19, #0xc0]
1004efc68:     	ldp	q0, q1, [sp, #0x130]
1004efc6c:     	stp	q0, q1, [x19, #0x60]
1004efc70:     	ldp	q0, q1, [x9, #0x20]
<L42>:
1004efc74:     	stp	q0, q1, [x19, #0x80]
<L43>:
1004efc78:     	str	x8, [x19, #0x140]
1004efc7c:     	ldr	x8, [sp, #0x48]
1004efc80:     	str	x8, [x19, #0x148]
<L44>:
1004efc84:     	add	sp, sp, #0x240
1004efc88:     	ldp	x29, x30, [sp, #0x50]
1004efc8c:     	ldp	x20, x19, [sp, #0x40]
1004efc90:     	ldp	x22, x21, [sp, #0x30]
1004efc94:     	ldp	x24, x23, [sp, #0x20]
1004efc98:     	ldp	x26, x25, [sp, #0x10]
1004efc9c:     	ldp	x28, x27, [sp], #0x60
1004efca0:     	ret
<L45>:
1004efca4:     	orr	x8, x20, #0x20
1004efca8:     	cmp	w22, #0x0
1004efcac:     	mov	w9, #0xfff              ; =4095
1004efcb0:     	add	x11, sp, #0x130
1004efcb4:     	ldp	q0, q1, [x11, #0x80]
1004efcb8:     	mov	w10, #0x1fffff          ; =2097151
1004efcbc:     	csel	x9, x10, x9, ne
1004efcc0:     	and	x10, x9, #0x1ff000
1004efcc4:     	eor	x10, x10, #0xffffff000
1004efcc8:     	stp	q0, q1, [x19]
1004efccc:     	and	x10, x10, x20
1004efcd0:     	and	x9, x9, x3
1004efcd4:     	orr	x9, x10, x9
1004efcd8:     	mov	w10, #0x2               ; =2
1004efcdc:     	ldp	q0, q1, [x11, #0xa0]
1004efce0:     	cinc	w10, w10, eq
1004efce4:     	stp	q0, q1, [x19, #0x20]
1004efce8:     	stp	x9, x26, [x19, #0x40]
1004efcec:     	str	x8, [x19, #0x50]
1004efcf0:     	strb	w10, [x19, #0x58]
1004efcf4:     	ldur	q0, [sp, #0xc8]
1004efcf8:     	ldur	q1, [sp, #0xd8]
1004efcfc:     	stp	q0, q1, [x19, #0xe0]
1004efd00:     	ldur	q0, [sp, #0xe8]
1004efd04:     	ldur	q1, [sp, #0xf8]
1004efd08:     	stp	q0, q1, [x19, #0x100]
1004efd0c:     	add	x8, sp, #0x9
1004efd10:     	ldur	q0, [x8, #0xff]
1004efd14:     	add	x8, sp, #0x19
1004efd18:     	ldur	q1, [x8, #0xff]
1004efd1c:     	stp	q0, q1, [x19, #0x120]
1004efd20:     	ldr	x8, [sp, #0x128]
1004efd24:     	ldp	q0, q1, [x11, #0x40]
1004efd28:     	stp	q0, q1, [x19, #0xa0]
1004efd2c:     	ldp	q0, q1, [x11, #0x60]
1004efd30:     	stp	q0, q1, [x19, #0xc0]
1004efd34:     	ldp	q0, q1, [sp, #0x130]
1004efd38:     	stp	q0, q1, [x19, #0x60]
1004efd3c:     	ldp	q0, q1, [x11, #0x20]
1004efd40:     	b	 <L42>
<L46>:
1004efd44:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efd48:     	add	x2, x2, #0xc60
1004efd4c:     	mov	w1, #0x4                ; =4
1004efd50:     	bl	 <core::panicking::panic_bounds_check>
<L47>:
1004efd54:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efd58:     	add	x2, x2, #0xc78
1004efd5c:     	mov	w1, #0x4                ; =4
1004efd60:     	bl	 <core::panicking::panic_bounds_check>
<L48>:
1004efd64:     	adrp	x2, 0x100a14000 <_anon.7d5c30878e39b8c1205ea450b28176e7.9+0x508>
1004efd68:     	add	x2, x2, #0xc90
1004efd6c:     	mov	w1, #0x4                ; =4
1004efd70:     	bl	 <core::panicking::panic_bounds_check>
		...
