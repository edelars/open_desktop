#[cfg(test)]
mod stage5_page_walk_candidate_benchmark {
    use super::*;
    use crate::{ExecutionMode, MachineMemoryMap, MemoryRegionSpec, RamLimits};
    use od_isa::memory::{
        AccessContext, AccessKind, AccessOrigin, InstructionMode, PrivilegeLevel,
    };
    use std::{
        env,
        fs::{self, File},
        hint::black_box,
        io::Write,
        time::Instant,
    };

    const LINEAR: u64 = 0x0000_0080_8060_4abc;
    const RAM_SIZE: u64 = 0x800000;
    const ROOT: u64 = 0x1000;
    const PDPT: u64 = 0x2000;
    const PD: u64 = 0x3000;
    const PT: u64 = 0x4000;
    const TABLE_FLAGS: u64 = 0x7;
    const ACCESSED: u64 = 1 << 5;
    const DIRTY: u64 = 1 << 6;
    const LARGE: u64 = 1 << 7;

    fn save_raw(name: &str, values: &[u64]) -> String {
        let directory = env::var("S5_BENCH_RAW_DIR").expect("S5_BENCH_RAW_DIR");
        fs::create_dir_all(&directory).unwrap();
        let path = format!("{directory}/{name}.u64le");
        let mut file = File::create(&path).unwrap();
        for value in values {
            file.write_all(&value.to_le_bytes()).unwrap();
        }
        path
    }

    fn summary(values: &[u64]) -> (u64, u64, u64, u64, u128) {
        let mut sorted = values.to_vec();
        sorted.sort_unstable();
        (
            sorted[0],
            sorted[sorted.len() / 2],
            sorted[sorted.len() * 9 / 10],
            *sorted.last().unwrap(),
            values.iter().map(|&value| u128::from(value)).sum(),
        )
    }

    struct Fixture {
        memory: PhysicalMemory,
        paging: Long64ProbeConfig,
        table_entries: Vec<(GuestPhysicalAddress, u64, bool)>,
        leaf_entry: GuestPhysicalAddress,
        expected_physical: u64,
    }

    struct PacketEntry {
        linear: u64,
        expected_physical: u64,
    }

    struct FirstAdPacket {
        memory: PhysicalMemory,
        paging: Long64ProbeConfig,
        tables: Vec<(GuestPhysicalAddress, u64)>,
        entries: Vec<PacketEntry>,
        updates_per_walk: usize,
    }

    fn first_ad_packet(large: bool) -> FirstAdPacket {
        const PATHS: usize = 512;
        const OFFSET: u64 = 0x1234_5000;
        let range = GuestPhysicalRange::new(GuestPhysicalAddress::new(0), RAM_SIZE).unwrap();
        let map = MachineMemoryMap::new(
            36,
            vec![MemoryRegionSpec::new(range, MemoryRegionKind::Ram)],
        )
        .unwrap();
        let mut memory = PhysicalMemory::new(&map, RamLimits::new(RAM_SIZE)).unwrap();
        memory.set_execution_mode(ExecutionMode::Interleaved);
        let paging = Long64ProbeConfig::new(
            0x8000_0033,
            ROOT,
            CR4_PAE,
            EFER_LME | EFER_LMA | EFER_NXE,
        )
        .unwrap();
        let offset_indexes = [
            (OFFSET >> 30) & 0x1ff,
            (OFFSET >> 21) & 0x1ff,
            (OFFSET >> 12) & 0x1ff,
        ];
        let mut tables = Vec::with_capacity(PATHS * if large { 3 } else { 4 });
        let mut entries = Vec::with_capacity(PATHS);
        for path in 0..PATHS {
            let root_index = path as u64;
            let pdpt = 0x2000 + root_index * 0x3000;
            let pd = pdpt + 0x1000;
            let pt = pdpt + 0x2000;
            let linear = (root_index << 39)
                | OFFSET
                | if root_index >= 256 {
                    0xffff_0000_0000_0000
                } else {
                    0
                };
            let leaf_base = if large {
                0x1000_0000 + root_index * 0x20_0000
            } else {
                0x500000 + root_index * 0x1000
            };
            let (pd_value, expected_physical, leaf_value, leaf_entry) = if large {
                let value = leaf_base | TABLE_FLAGS | LARGE;
                (
                    value,
                    leaf_base + (linear & 0x1f_ffff),
                    value,
                    GuestPhysicalAddress::new(pd + offset_indexes[1] * 8),
                )
            } else {
                let leaf = leaf_base | TABLE_FLAGS;
                (
                    pt | TABLE_FLAGS,
                    leaf_base + (linear & 0xfff),
                    leaf,
                    GuestPhysicalAddress::new(pt + offset_indexes[2] * 8),
                )
            };
            let mut path_tables = vec![
                (
                    GuestPhysicalAddress::new(ROOT + root_index * 8),
                    pdpt | TABLE_FLAGS,
                ),
                (
                    GuestPhysicalAddress::new(pdpt + offset_indexes[0] * 8),
                    pd | TABLE_FLAGS,
                ),
                (
                    GuestPhysicalAddress::new(pd + offset_indexes[1] * 8),
                    pd_value,
                ),
            ];
            if !large {
                path_tables.push((
                    GuestPhysicalAddress::new(pt + offset_indexes[2] * 8),
                    leaf_value,
                ));
            }
            for (address, value) in &path_tables {
                memory.store_u64(*address, *value, |_| {}).unwrap();
            }
            tables.extend(path_tables);
            entries.push(PacketEntry {
                linear,
                expected_physical,
            });
            black_box(leaf_entry);
        }
        FirstAdPacket {
            memory,
            paging,
            tables,
            entries,
            updates_per_walk: if large { 3 } else { 4 },
        }
    }

    fn reset_first_ad_packet(packet: &mut FirstAdPacket) {
        for (address, value) in &packet.tables {
            packet.memory.store_u64(*address, *value, |_| {}).unwrap();
        }
    }

    fn run_first_ad_batch(packet: &mut FirstAdPacket, access: AccessKind) -> u64 {
        reset_first_ad_packet(packet);
        let context = AccessContext {
            mode: InstructionMode::Long64,
            privilege: PrivilegeLevel::Ring0,
            origin: AccessOrigin::Explicit,
        };
        let mut committed_write = |_range: GuestPhysicalRange| {};
        let start = Instant::now();
        for entry in &packet.entries {
            let result = walk_long64_4k_with_writer(
                &mut packet.memory,
                &packet.paging,
                0x1234,
                GuestLinearAddress::new(entry.linear),
                context,
                access,
                &mut committed_write,
                &mut compare_replace_table_entry,
                true,
            );
            black_box(result);
        }
        start.elapsed().as_nanos() as u64
    }

    fn verify_first_ad_packet(packet: &mut FirstAdPacket, access: AccessKind) {
        reset_first_ad_packet(packet);
        let context = AccessContext {
            mode: InstructionMode::Long64,
            privilege: PrivilegeLevel::Ring0,
            origin: AccessOrigin::Explicit,
        };
        let mut committed_write = |_range: GuestPhysicalRange| {};
        for entry in &packet.entries {
            let result = walk_long64_4k_with_writer(
                &mut packet.memory,
                &packet.paging,
                0x1234,
                GuestLinearAddress::new(entry.linear),
                context,
                access,
                &mut committed_write,
                &mut compare_replace_table_entry,
                true,
            );
            assert_eq!(
                result.translation.as_ref().unwrap().physical.get(),
                entry.expected_physical
            );
            assert_eq!(result.ad_update_count, packet.updates_per_walk);
            black_box(result);
        }
        for (address, _) in &packet.tables {
            let value = packet.memory.load_u64(*address).unwrap();
            assert_ne!(value & ACCESSED, 0);
            assert_eq!(value & DIRTY, 0, "direct walker does not set D");
        }
    }

    fn fixture(large: bool) -> Fixture {
        let range = GuestPhysicalRange::new(GuestPhysicalAddress::new(0), RAM_SIZE).unwrap();
        let map = MachineMemoryMap::new(
            36,
            vec![MemoryRegionSpec::new(range, MemoryRegionKind::Ram)],
        )
        .unwrap();
        let mut memory = PhysicalMemory::new(&map, RamLimits::new(RAM_SIZE)).unwrap();
        memory.set_execution_mode(ExecutionMode::Interleaved);
        let paging = Long64ProbeConfig::new(
            0x8000_0033,
            ROOT,
            CR4_PAE,
            EFER_LME | EFER_LMA | EFER_NXE,
        )
        .unwrap();
        let indexes = [
            (LINEAR >> 39) & 0x1ff,
            (LINEAR >> 30) & 0x1ff,
            (LINEAR >> 21) & 0x1ff,
            (LINEAR >> 12) & 0x1ff,
        ];
        let leaf_base = if large { 0x600000 } else { 0x500000 };
        let mut entries = vec![
            (
                GuestPhysicalAddress::new(ROOT + indexes[0] * 8),
                PDPT | TABLE_FLAGS,
                false,
            ),
            (
                GuestPhysicalAddress::new(PDPT + indexes[1] * 8),
                PD | TABLE_FLAGS,
                false,
            ),
        ];
        let pd_value = if large {
            leaf_base | TABLE_FLAGS | LARGE
        } else {
            PT | TABLE_FLAGS
        };
        entries.push((
            GuestPhysicalAddress::new(PD + indexes[2] * 8),
            pd_value,
            large,
        ));
        if !large {
            entries.push((
                GuestPhysicalAddress::new(PT + indexes[3] * 8),
                leaf_base | TABLE_FLAGS,
                true,
            ));
        }
        let leaf_entry = entries.last().unwrap().0;
        let page_size = if large { 0x200000 } else { 0x1000 };
        let expected_physical = leaf_base + (LINEAR & (page_size - 1));
        memory
            .store_u8(GuestPhysicalAddress::new(expected_physical), 0x5a, |_| {})
            .unwrap();
        for (address, value, _) in &entries {
            memory.store_u64(*address, *value, |_| {}).unwrap();
        }
        Fixture {
            memory,
            paging,
            table_entries: entries,
            leaf_entry,
            expected_physical,
        }
    }

    fn reset_ad_state(fixture: &mut Fixture, warm: bool) {
        for (address, base, is_leaf) in &fixture.table_entries {
            let ad = if warm {
                ACCESSED | if *is_leaf { DIRTY } else { 0 }
            } else {
                0
            };
            fixture.memory.store_u64(*address, *base | ad, |_| {}).unwrap();
        }
    }

    fn run_one(fixture: &mut Fixture, access: AccessKind, warm: bool) -> u64 {
        reset_ad_state(fixture, warm);
        let context = AccessContext {
            mode: InstructionMode::Long64,
            privilege: PrivilegeLevel::Ring0,
            origin: AccessOrigin::Explicit,
        };
        let mut committed_write = |_range: GuestPhysicalRange| {};
        let start = Instant::now();
        let result = walk_long64_4k_with_writer(
            &mut fixture.memory,
            &fixture.paging,
            0x1234,
            GuestLinearAddress::new(LINEAR),
            context,
            access,
            &mut committed_write,
            &mut compare_replace_table_entry,
            true,
        );
        let elapsed_ns = start.elapsed().as_nanos() as u64;

        let physical = result.translation.unwrap().physical.get();
        assert_eq!(physical, fixture.expected_physical);
        let expected_updates = if warm {
            0
        } else {
            fixture.table_entries.len()
        };
        assert_eq!(result.ad_update_count, expected_updates);
        let leaf = fixture.memory.load_u64(fixture.leaf_entry).unwrap();
        assert_eq!(leaf & ACCESSED != 0, true);
        assert_eq!(leaf & DIRTY != 0, warm, "direct walker does not set D");
        black_box((physical, result.ad_update_count, result.trace.len(), leaf));
        elapsed_ns
    }

    fn run_warm_batch(fixture: &mut Fixture, access: AccessKind, calls: usize) -> u64 {
        reset_ad_state(fixture, true);
        let context = AccessContext {
            mode: InstructionMode::Long64,
            privilege: PrivilegeLevel::Ring0,
            origin: AccessOrigin::Explicit,
        };
        let mut committed_write = |_range: GuestPhysicalRange| {};
        let start = Instant::now();
        let mut last_physical = 0;
        let mut last_updates = 0;
        for _ in 0..calls {
            let result = walk_long64_4k_with_writer(
                &mut fixture.memory,
                &fixture.paging,
                0x1234,
                GuestLinearAddress::new(LINEAR),
                context,
                access,
                &mut committed_write,
                &mut compare_replace_table_entry,
                true,
            );
            last_physical = result.translation.unwrap().physical.get();
            last_updates = result.ad_update_count;
            black_box((last_physical, last_updates, result.trace.len()));
        }
        let elapsed_ns = start.elapsed().as_nanos() as u64;
        let last_leaf = fixture.memory.load_u64(fixture.leaf_entry).unwrap();
        assert_eq!(last_physical, fixture.expected_physical);
        assert_eq!(last_updates, 0);
        assert_eq!(last_leaf & ACCESSED != 0, true);
        assert_eq!(last_leaf & DIRTY != 0, true);
        elapsed_ns
    }

    #[test]
    fn run_matrix() {
        let build = env::var("S5_BENCH_BUILD").expect("S5_BENCH_BUILD");
        let sample = env::var("S5_BENCH_SAMPLE")
            .expect("S5_BENCH_SAMPLE")
            .parse::<usize>()
            .unwrap();
        let timer_iterations = env::var("S5_BENCH_ITERS")
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .unwrap_or(100_000);
        let mut timer_raw = Vec::with_capacity(timer_iterations);
        for _ in 0..timer_iterations {
            let start = Instant::now();
            black_box(0u8);
            timer_raw.push(start.elapsed().as_nanos() as u64);
        }
        let timer_path = save_raw(&format!("{build}-{sample}-timer"), &timer_raw);
        let (timer_min, timer_median, timer_p90, timer_max, timer_sum) = summary(&timer_raw);
        println!(
            "BENCH_TIMER,{build},{sample},{timer_iterations},{timer_min},{timer_median},{timer_p90},{timer_max},{timer_sum},{timer_path}"
        );
        for large in [false, true] {
            for access in [AccessKind::Read, AccessKind::Write] {
                let mut packet = first_ad_packet(large);
                let pilot_ns = run_first_ad_batch(&mut packet, access).max(1);
                let mut cycles = (250_000_000u64 / pilot_ns).clamp(1, 50_000) as usize;
                let mut raw_batches = Vec::with_capacity(cycles);
                let mut total_ns = 0u64;
                for _ in 0..cycles {
                    let elapsed_ns = run_first_ad_batch(&mut packet, access);
                    total_ns = total_ns.saturating_add(elapsed_ns);
                    raw_batches.push(elapsed_ns);
                }
                if total_ns < 200_000_000 {
                    cycles = ((cycles as u128 * 250_000_000u128)
                        / u128::from(total_ns.max(1)))
                    .min(50_000) as usize;
                    raw_batches.clear();
                    total_ns = 0;
                    for _ in 0..cycles {
                        let elapsed_ns = run_first_ad_batch(&mut packet, access);
                        total_ns = total_ns.saturating_add(elapsed_ns);
                        raw_batches.push(elapsed_ns);
                    }
                }
                verify_first_ad_packet(&mut packet, access);
                let leaf = if large { "2m" } else { "4k" };
                let access_name = format!("{access:?}").to_lowercase();
                let path = save_raw(
                    &format!("{build}-{sample}-{leaf}-{access_name}-first-ad-batches"),
                    &raw_batches,
                );
                println!(
                    "BENCH_FIRST_AD,{build},{sample},{leaf},{access_name},paths={},cycles={cycles},calls={},timed_ns={total_ns},ns_per_call={:.3},raw_batch_path={path}",
                    packet.entries.len(),
                    packet.entries.len() * cycles,
                    total_ns as f64 / (packet.entries.len() * cycles) as f64,
                );
                let mut fixture = fixture(large);
                for _ in 0..64 {
                    black_box(run_one(&mut fixture, access, true));
                }
                let calibration_calls = 10_000;
                let calibration_ns = run_warm_batch(&mut fixture, access, calibration_calls);
                let target_ns = 250_000_000u64;
                let mut calls = ((target_ns as u128 * calibration_calls as u128)
                    / u128::from(calibration_ns.max(1)))
                    .clamp(10_000, 50_000_000) as usize;
                let mut elapsed_ns = run_warm_batch(&mut fixture, access, calls);
                if elapsed_ns < 200_000_000 {
                    calls = ((calls as u128 * 250_000_000u128)
                        / u128::from(elapsed_ns.max(1)))
                        .min(50_000_000) as usize;
                    elapsed_ns = run_warm_batch(&mut fixture, access, calls);
                }
                println!(
                    "BENCH_WARM,{build},{sample},{},{:?},{calls},{elapsed_ns},{:.3},{:#x}",
                    if large { "2m" } else { "4k" },
                    access,
                    elapsed_ns as f64 / calls as f64,
                    fixture.expected_physical,
                );
            }
        }
    }
}
