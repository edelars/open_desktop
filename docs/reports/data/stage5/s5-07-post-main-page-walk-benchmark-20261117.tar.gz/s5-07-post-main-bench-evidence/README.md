# S5-07 post-main page-walker benchmark evidence

Date: 2026-11-17
Baseline source: `36a568d` (pre-main, S5-07 schema-v20 code)
Candidate source: `b73d534` (post-main RAM/MMU integration)
Rust: `rustc 1.99.0 (b940084d7 2026-09-28)`
Cargo: `cargo 1.99.0 (5f94df478 2026-08-27)`
Host: macOS 26.7.1, Darwin arm64; the same host is recorded as Apple M3 Max MacBook Pro, 14 cores, 36 GB in the parent benchmark environment log.

Release libtest commands, run in an isolated archived source copy at the same scratch source path with distinct target directories:

```sh
CARGO_TARGET_DIR=/private/tmp/s5-07-post-main-bench-target-baseline-clean cargo test -p od-machine --lib --release --offline --no-run
CARGO_TARGET_DIR=/private/tmp/s5-07-post-main-bench-target-candidate cargo test -p od-machine --lib --release --offline --no-run
```

Benchmark entrypoint: `page_walk::stage5_page_walk_candidate_benchmark::run_matrix`; six paired samples, alternating order baseline→candidate / candidate→baseline, 100,000 timer samples per invocation, 512 independent page paths, 4 KiB/2 MiB, read/write, first-A and warm-A. Each measured scenario ran at least 200 ms. Each first-A batch performed 512 walks; warm-A used the same fixture with A/D set and no A updates. Since setup/reset APIs differ between revisions and can prepare host caches differently, First-A is this prepared-fixture scenario, not a cold-cache measurement. Direct translation, trace, expected update counts, D preservation, expected physical address, and result use were asserted by the harness.

`harness-original.rs` SHA-256: `51a3e7e01c3d71e206475fb0ccd034ae4f2690de3aa8c2010491a84440648fbc`
`harness-candidate-adapted.rs` SHA-256: `7e6ccb357602961313d1cf21c9df648fd2072a5cf78e1dd6cf24446ac7127bc9`
Baseline binary SHA-256: `ecca4fe1f980fec915e64e2414e17de32c732980fc4d5aad8205c9d6121845db`
Candidate binary SHA-256: `2d64be574de0a7b03643b694a579e9b40c29d2938d7d49da372fd0785f44be59`

Candidate-only harness adaptations are outside the timed loops: call RAM setup/reset/verification APIs `write_u64/read_u64/write_u8` were replaced with `store_u64/load_u64/store_u8`, and both candidate `PhysicalMemory` fixtures explicitly set `ExecutionMode::Interleaved`. No timed loop, walker arguments, path layout, or assertion was changed. `summary.csv` computes per-run `timed_ns / walk_count`, then paired percent `100 * (candidate / baseline - 1)`; order groups are medians across samples 1,3,5 and 2,4,6. Raw `.u64le` samples and invocation logs are included, with SHA-256s in `raw.sha256`.

This measures the scenario-specific effect of the integrated RAM/MMU backend for this direct-walker harness. It does not attribute the delta to a single upstream commit or predict Linux workload throughput.
