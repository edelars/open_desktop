#[cfg(target_os = "macos")]
pub fn prioritize_measurement_thread() {
    unsafe extern "C" {
        fn geteuid() -> u32;
        fn getpriority(which: i32, who: u32) -> i32;
        fn qos_class_self() -> u32;
        fn pthread_set_qos_class_self_np(qos_class: u32, relative_priority: i32) -> i32;
    }

    // sys/qos.h assigns QOS_CLASS_USER_INTERACTIVE the value 0x21.
    const USER_INTERACTIVE: u32 = 0x21;
    const PRIO_PROCESS: i32 = 0;
    // SAFETY: These APIs query or change the calling thread only.
    let before = unsafe { qos_class_self() };
    let result = unsafe { pthread_set_qos_class_self_np(USER_INTERACTIVE, 0) };
    let after = unsafe { qos_class_self() };
    assert_eq!(result, 0, "benchmark thread QoS setup failed");
    assert_eq!(
        after, USER_INTERACTIVE,
        "benchmark thread QoS was not applied"
    );
    // SAFETY: Both queries refer to this process and require no pointers.
    let uid = unsafe { geteuid() };
    let nice = unsafe { getpriority(PRIO_PROCESS, 0) };
    assert_ne!(uid, 0, "benchmark must run without root privileges");
    assert_eq!(nice, -5, "benchmark process nice value was not applied");
    eprintln!(
        "benchmark_uid={uid} benchmark_nice={nice} benchmark_qos_before=0x{before:x} benchmark_qos_after=0x{after:x}"
    );
}
