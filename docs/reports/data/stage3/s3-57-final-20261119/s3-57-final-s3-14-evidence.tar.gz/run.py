"""Run the original eight-process S3-14 schedule on the signed final build."""

from argparse import ArgumentParser
from datetime import UTC, datetime
from hashlib import sha256
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

from audit import (
    BUILD_FILES, CASE_LIST, HARNESS, HISTORICAL_SHA, MAIN, REVISION, SCRIPTS, TIMELINE, TRACE,
    arguments, audit, build_metadata, digest, historical_warm, sha_manifest, verify_inputs,
    verify_priority, write_json,
)
from stage_qos import instrument


def verify_build(build):
    source = build / "source"
    metadata = build_metadata(build)
    binary = build / "od-bench"
    assert digest(binary) == metadata["binary_sha256"]
    subprocess.run(["/usr/bin/codesign", "--verify", "--strict", str(binary)], check=True)

    repository = HARNESS.parents[2]
    tree = subprocess.check_output(
        ["git", "-C", str(repository), "rev-parse", f"{REVISION}^{{tree}}"], text=True,
    ).strip()
    assert tree == metadata["tree"]
    archive = sha_manifest(build / "archive-source.sha256")
    for name, expected in archive.items():
        original = subprocess.check_output(["git", "-C", str(repository), "show", f"{REVISION}:{name}"])
        assert sha256(original).hexdigest() == expected, name
        if name == MAIN:
            assert (source / name).read_bytes() == instrument(original)
    for name, expected in sha_manifest(build / "compiled-source.sha256").items():
        assert digest(source / name) == expected, name
    return metadata


def capture_inputs(source, target):
    capture_host, fixtures = verify_inputs(source)
    historical_warm(source, capture_host)
    historical = [TRACE.parent / f"warm-branch-helper-{index}.json"
                  for index in range(1, len(HISTORICAL_SHA) + 1)]
    for name in (CASE_LIST, TRACE, *fixtures, *historical):
        destination = target / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, destination)
    assert verify_inputs(target) == (capture_host, fixtures)
    return fixtures


def main():
    assert __debug__
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("run", help="Fresh run name below this harness, e.g. run-01")
    args = parser.parse_args()
    assert re.fullmatch(r"run-[a-zA-Z0-9][a-zA-Z0-9_-]*", args.run)
    uid = os.getuid()
    assert uid > 0 and uid == os.geteuid(), "launch as an ordinary user"
    assert os.uname().sysname == "Darwin" and os.uname().machine == "arm64"
    build = HARNESS / "build"
    source = build / "source"
    metadata = verify_build(build)

    directory = HARNESS / args.run
    directory.mkdir()
    (directory / "build").mkdir()
    for name in BUILD_FILES:
        shutil.copyfile(build / name, directory / "build" / name)
    fixture_hashes = capture_inputs(source, directory / "inputs")
    provenance = {
        "run": str(directory), "harness": str(HARNESS), "cwd": str(source), "uid": uid,
        "host": {
            "macos": subprocess.check_output(["/usr/bin/sw_vers"], text=True).strip(),
            "hardware": subprocess.check_output(
                ["/usr/sbin/sysctl", "machdep.cpu.brand_string", "hw.model", "hw.ncpu"], text=True,
            ).strip(),
        },
        "build": metadata, "fixture_sha256": fixture_hashes,
        "harness_sha256": {name: digest(HARNESS / name) for name in SCRIPTS},
    }
    write_json(directory / "provenance.json", provenance)
    schedule = []
    write_json(directory / "schedule.json", schedule)
    for number, mode in TIMELINE:
        name = f"{mode}-{number}"
        report = directory / f"{name}.json"
        log = directory / f"{name}.log"
        argv = arguments(HARNESS, report.name, uid, mode, number, directory)
        print(f"starting {name}", flush=True)
        started_at = datetime.now(UTC).isoformat()
        start = time.monotonic_ns()
        load_before = os.getloadavg()
        with log.open("x") as stream:
            child = subprocess.run(argv, cwd=source, stdout=stream, stderr=subprocess.STDOUT, timeout=1_900)
        row = {
            "mode": mode, "round": number, "argv": argv, "report": report.name, "log": log.name,
            "returncode": child.returncode, "started_at": started_at,
            "completed_at": datetime.now(UTC).isoformat(), "duration_ns": time.monotonic_ns() - start,
            "load_before": load_before, "load_after": os.getloadavg(), "log_sha256": digest(log),
        }
        if report.exists():
            row["report_sha256"] = digest(report)
        schedule.append(row)
        write_json(directory / "schedule.json", schedule)
        if child.returncode:
            print(log.read_text(), end="", flush=True)
        child.check_returncode()
        verify_priority(log, uid)
        assert report.is_file(), report
        print(f"finished {name}", flush=True)
    assert verify_inputs(source)[1] == fixture_hashes
    assert digest(build / "od-bench") == metadata["binary_sha256"]
    result = audit(directory)
    write_json(directory / "audit.json", result)
    print(f'audited {result["timed_sides"]} intervals; minimum {result["minimum_timed_side_ns"]} ns')


if __name__ == "__main__":
    main()
