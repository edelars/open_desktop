#include <mach/mach.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

static kern_return_t cpu_load(host_cpu_load_info_data_t *load) {
    mach_msg_type_number_t count = HOST_CPU_LOAD_INFO_COUNT;
    return host_statistics(mach_host_self(), HOST_CPU_LOAD_INFO, (host_info_t)load, &count);
}

int main(void) {
    host_cpu_load_info_data_t before = {0}, after = {0};
    kern_return_t result = cpu_load(&before);
    if (result != KERN_SUCCESS) {
        fprintf(stderr, "host_statistics failed: %d\n", result);
        return 1;
    }
    sleep(2);
    result = cpu_load(&after);
    if (result != KERN_SUCCESS) {
        fprintf(stderr, "host_statistics failed: %d\n", result);
        return 1;
    }
    uint64_t total = 0;
    for (int i = 0; i < CPU_STATE_MAX; ++i) {
        total += (uint32_t)(after.cpu_ticks[i] - before.cpu_ticks[i]);
    }
    uint32_t idle = after.cpu_ticks[CPU_STATE_IDLE] - before.cpu_ticks[CPU_STATE_IDLE];
    if (total == 0) {
        fputs("no CPU sample\n", stderr);
        return 1;
    }
    printf("cpu_idle=%.1f%% idle_ticks=%u total_ticks=%llu over 2 seconds\n", 100.0 * idle / total, idle, (unsigned long long)total);
}
