from pathlib import Path
from statistics import median
import hashlib
import json
import sys

root = Path(sys.argv[1]).resolve(strict=True)
schedule = json.loads((root / "schedule.json").read_text())
assert [(item["round"], item["mode"]) for item in schedule] == [
    (1, "cold-fifo"), (1, "cold-generic"), (1, "warm-generic"), (1, "warm-fifo"),
    (2, "warm-fifo"), (2, "warm-generic"), (2, "cold-generic"), (2, "cold-fifo"),
]
expected_case_ids = [
    "s3_14_jz_to_end_skips_tail", "s3_14_jnz_to_end_skips_tail",
    "s3_14_jz_not_taken_backward_target", "s3_14_jnz_not_taken_backward_target",
    "s3_14_live_through_helpers",
]
count_keys = ("cache_hits", "cache_misses", "successful_compiles", "successful_publications", "evictions")
case_list_sha = "dd590c6c8f8ae1a09f2192e47c1d019f7449c814212c87e06194bf7425dd0881"
trace_sha = "272eb80c3283e71962f1bc2a2e6d847723164d48f56dd3970134a814df57d2c8"

def stats(values):
    return {"min": min(values), "median": median(values), "max": max(values)}

results = {}
checksums = {}
minimum_ns = None
timed_sides = 0
expected_host = None
for run in schedule:
    label = f'{run["mode"]}-{run["round"]}'
    assert run["returncode"] == 0 and run["report"] == f"{label}.json"
    report_file = root / run["report"]
    checksums[report_file.name] = hashlib.sha256(report_file.read_bytes()).hexdigest()
    report = json.loads(report_file.read_text())
    assert report["process_run"] == run["round"]
    assert report["case_list_sha256"] == case_list_sha and report["trace_sha256"] == trace_sha
    assert report["inputs"] == report["visits"] == 5 and report["measured_pairs"] == 20
    if expected_host is None:
        expected_host = report["measure_host"]
    assert report["measure_host"] == expected_host
    cold = run["mode"].startswith("cold-")
    generic = run["mode"].endswith("-generic")
    assert ("generic_register" in report) == generic
    if generic:
        profile = report["generic_register"]
        assert profile["case_ids"] == expected_case_ids and profile["profile"] == "NativeRegisterV1"
        assert profile["flags_mode"] == "eager" and profile["fallback_helper_calls"] == 0
    if not cold:
        assert report["selected_case_ids"] == expected_case_ids
        assert report["selected_cases"] == 5
        assert report["warmup_cache_misses"] == report["warmup_successful_compiles"] == 5
        assert report["warmup_successful_publications"] == 5 and report["warmup_evictions"] == 0
    phase = "cold" if cold else "warm"
    jit_result, interpreter_result = report["variants"]
    assert jit_result["variant"] == f"fifo16_{phase}_block_dispatcher"
    assert interpreter_result["variant"] == "interpreter"
    jit_rows = jit_result["samples"]
    interpreter_rows = interpreter_result["samples"]
    assert len(jit_rows) == len(interpreter_rows) == report["measured_pairs"]
    sweeps = report["common_sweeps_per_sample"]
    assert sweeps > 0
    jit_per_sweep = []
    interp_per_sweep = []
    paired = []
    footprints = set()
    for index, (jit, interpreter) in enumerate(zip(jit_rows, interpreter_rows)):
        for row in (jit, interpreter):
            assert row["pair"] == index and row["sweeps"] == sweeps
            assert row["calls"] == 5 * sweeps and row["retired_guest_instructions"] == 14 * sweeps
            elapsed = row["elapsed_ns"]
            assert elapsed == row["initialization_ns"] + row["execution_ns"]
            assert elapsed >= 200_000_000
            minimum_ns = min(minimum_ns, elapsed) if minimum_ns is not None else elapsed
            timed_sides += 1
        assert jit["order"] == index % 2 and interpreter["order"] == 1 - index % 2
        expected_counts = (0, 5 * sweeps, 5 * sweeps, 5 * sweeps, 0) if cold else (5 * sweeps, 0, 0, 0, 0)
        assert tuple(jit[key] for key in count_keys) == expected_counts
        assert all(interpreter[key] == 0 for key in count_keys)
        assert jit["native_block_executions"] == 5 * sweeps and interpreter["native_block_executions"] == 0
        assert (jit["initialization_ns"] > 0) == cold and interpreter["initialization_ns"] == 0
        if generic:
            assert jit["retired_native"] == 14 * sweeps and jit["interpreter_steps"] == 0
            assert jit["fallback_helper_calls"] == 0
            assert interpreter["retired_native"] == 0 and interpreter["interpreter_steps"] == 14 * sweeps
        footprints.add((jit["resident_entries_high_water"], jit["resident_code_bytes_high_water"],
                       jit["resident_logical_metadata_bytes_high_water"]))
        jit_per_sweep.append(jit["elapsed_ns"] / sweeps)
        interp_per_sweep.append(interpreter["elapsed_ns"] / sweeps)
        paired.append(jit["elapsed_ns"] / interpreter["elapsed_ns"])
    assert len(footprints) == 1
    (entries, code_bytes, metadata_bytes), = footprints
    assert entries == 5 and code_bytes > 0 and metadata_bytes > 0
    results[label] = {
        "jit_ns_per_sweep": stats(jit_per_sweep),
        "interpreter_ns_per_sweep": stats(interp_per_sweep),
        "paired_jit_over_interpreter": stats(paired),
        "sweeps_per_sample": sweeps,
        "resident_high_water": [entries, code_bytes, metadata_bytes],
    }
comparisons = {}
for phase in ("cold", "warm"):
    values = []
    for number in (1, 2):
        generic = results[f"{phase}-generic-{number}"]
        fifo = results[f"{phase}-fifo-{number}"]
        values.append({
            "round": number,
            "raw_generic_over_fifo": generic["jit_ns_per_sweep"]["median"] / fifo["jit_ns_per_sweep"]["median"],
            "normalized_generic_over_fifo": generic["paired_jit_over_interpreter"]["median"] / fifo["paired_jit_over_interpreter"]["median"],
        })
    comparisons[phase] = values
print(json.dumps({"minimum_timed_side_ns": minimum_ns, "timed_sides": timed_sides,
                  "report_sha256": checksums, "results": results, "comparisons": comparisons}, indent=2))
