"""Audit both S3-57 rounds and the retained S3-36b warm references."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import plistlib
import re
import subprocess
import sys


HARNESS = Path(__file__).resolve().parent
REVISION = "11cbe6b197ca6414c021a0a7ddd53347dc35406b"
CASE_LIST = Path("tests/fixtures/x86/stage3/s3_14_branch_helper_case_list.txt")
TRACE = Path("docs/reports/data/stage3/s3-36b/trace.json")
CASE_LIST_SHA = "dd590c6c8f8ae1a09f2192e47c1d019f7449c814212c87e06194bf7425dd0881"
TRACE_SHA = "272eb80c3283e71962f1bc2a2e6d847723164d48f56dd3970134a814df57d2c8"
HISTORICAL_SHA = (
    "d3ded37b225dc818a618ba91ba024e7b77051947645d90731541251dd77c0b6b",
    "236a98c09e2ceee7963b91da3fb15efd56626afc1cf2d9edc83fc72b101d9e6c",
    "1925cb2e6ab68b3e946312a8a31cc6b7fdf37718a085c8e42421fbb3d0a55cb1",
)
MODES = {
    "cold-fifo": ["cold-first-run"],
    "cold-generic": ["cold-first-run", "--generic-register"],
    "warm-fifo": ["warm-branch-helper"],
    "warm-generic": ["warm-first-run", "--generic-register"],
}
ORDER = ("cold-fifo", "cold-generic", "warm-generic", "warm-fifo")
TIMELINE = [(number, mode) for number, modes in enumerate((ORDER, ORDER[::-1]), 1)
            for mode in modes]
BUILD_FILES = (
    "revision", "tree", "archive-source.sha256", "compiled-source.sha256",
    "toolchain.txt", "binary.sha256", "build.log", "build.jsonl", "codesign.log",
    "entitlements.plist",
)
SCRIPTS = ("build.sh", "stage_qos.py", "benchmark_qos.rs", "run.py", "audit.py", "audit_reports.py")
PRIORITY = re.compile(
    r"benchmark_uid=(\d+) benchmark_nice=-5 benchmark_qos_before=0x[0-9a-f]+ benchmark_qos_after=0x21"
)
QOS_MODULE = "tools/bench/src/s3_56_benchmark_qos.rs"
QOS_SHA = "add479bfa9524522d682178aaf130a883358e5d9b3840158fd9ecbfb765112c5"
MAIN = "tools/bench/src/main.rs"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def sha_manifest(path):
    return {name: value for value, name in
            (line.split(maxsplit=1) for line in path.read_text().splitlines())}


def build_metadata(build):
    assert (build / "revision").read_text().strip() == REVISION
    signature = (build / "codesign.log").read_text()
    assert "Format=Mach-O thin (arm64)" in signature and "Signature=adhoc" in signature
    assert any("flags=" in line and ",runtime)" in line for line in signature.splitlines())
    assert plistlib.loads((build / "entitlements.plist").read_bytes()) == {
        "com.apple.security.cs.allow-jit": True
    }
    archiv = sha_manifest(build / "archive-source.sha256")
    compiled = sha_manifest(build / "compiled-source.sha256")
    assert compiled.keys() == (archiv.keys() | {QOS_MODULE})
    assert compiled[QOS_MODULE] == QOS_SHA
    assert [name for name in archiv if archiv[name] != compiled[name]] == [MAIN]
    assert archiv[str(CASE_LIST)] == CASE_LIST_SHA and archiv[str(TRACE)] == TRACE_SHA
    binary_hash = sha_manifest(build / "binary.sha256")
    assert binary_hash.keys() == {"od-bench"}
    return {"revision": REVISION, "binary_sha256": binary_hash["od-bench"],
            "tree": (build / "tree").read_text().strip(),
            "metadata_sha256": {name: digest(build / name) for name in BUILD_FILES}}


def verify_inputs(root):
    assert digest(root / CASE_LIST) == CASE_LIST_SHA and digest(root / TRACE) == TRACE_SHA
    trace = load(root / TRACE)
    paths = [Path(line) for line in (root / CASE_LIST).read_text().splitlines()]
    assert trace["schema"] == 2 and len(paths) == len(trace["inputs"]) == len(trace["visits"]) == 5
    fixtures = {}
    for path, expected in zip(paths, trace["inputs"], strict=True):
        assert path.parent == CASE_LIST.parent and path.name == f'{expected["case_id"]}.case.json'
        data = root / path
        actual = digest(data)
        assert actual == expected["fixture_sha256"] and data.stat().st_size == expected["fixture_json_bytes"]
        fixtures[str(path)] = actual
    return trace["capture_host"], fixtures


def verify_priority(log, uid):
    observed = [int(match[1]) for line in log.read_text().splitlines()
                if (match := PRIORITY.fullmatch(line))]
    assert observed == [uid] and uid > 0, log


def arguments(harness, output, uid, mode, number, root):
    return [
        "/usr/bin/sudo", "-n", "/usr/bin/nice", "-n", "-5",
        "/usr/bin/sudo", "-n", "-u", f"#{uid}", "--",
        "/usr/bin/env", f"GIT_CEILING_DIRECTORIES={harness / 'build'}",
        str(harness / "build" / "od-bench"), *MODES[mode],
        "--case-list", str(CASE_LIST), "--trace", str(TRACE),
        "--process-run", str(number), "--output", str(root / output),
    ]


def historical_warm(root, capture_host):
    references = []
    for number, expected_hash in enumerate(HISTORICAL_SHA, 1):
        path = root / TRACE.parent / f"warm-branch-helper-{number}.json"
        assert digest(path) == expected_hash
        report = load(path)
        assert report["capture_host"] == capture_host and report["process_run"] == number
        assert report["case_list_sha256"] == CASE_LIST_SHA and report["trace_sha256"] == TRACE_SHA
        assert report["inputs"] == report["visits"] == report["selected_cases"] == 5
        assert report["measured_pairs"] == 20
        jit, interpreter = report["variants"]
        assert jit["variant"] == "fifo16_warm_block_dispatcher" and interpreter["variant"] == "interpreter"
        references.append({
            "round": number, "report_sha256": expected_hash,
            "fifo_median_ns_per_sweep": jit["median_ns_per_sweep"],
            "interpreter_median_ns_per_sweep": interpreter["median_ns_per_sweep"],
        })
    return references


def audit(root):
    provenance = load(root / "provenance.json")
    assert provenance["build"] == build_metadata(root / "build")
    assert provenance["harness_sha256"] == {name: digest(HARNESS / name) for name in SCRIPTS}
    capture_host, fixtures = verify_inputs(root / "inputs")
    assert provenance["fixture_sha256"] == fixtures
    uid = provenance["uid"]
    harness = Path(provenance["harness"])
    original_run = Path(provenance["run"])
    schedule = load(root / "schedule.json")
    assert [(row["round"], row["mode"]) for row in schedule] == TIMELINE
    for row in schedule:
        mode, number = row["mode"], row["round"]
        name = f"{mode}-{number}"
        assert row["report"] == f"{name}.json" and row["log"] == f"{name}.log"
        log_path, report_path = root / row["log"], root / row["report"]
        assert row["argv"] == arguments(harness, row["report"], uid, mode, number, original_run)
        assert row["log_sha256"] == digest(log_path) and row["report_sha256"] == digest(report_path)
        assert row["duration_ns"] > 0 and row["started_at"] <= row["completed_at"]
        verify_priority(log_path, uid)
        report = load(report_path)
        assert report["capture_host"] == capture_host
        host = report["measure_host"]
        assert host["os"] == "macos" and host["architecture"] == "aarch64"
        assert host["build"]["profile"] == "release" and host["build"]["target"] == "aarch64-apple-darwin"
        assert host["execution"]["working_directory"] == provenance["cwd"]
        assert "case_list_mode" not in report and "historical_case_list_sha256" not in report
    result = json.loads(subprocess.check_output(
        [sys.executable, str(HARNESS / "audit_reports.py"), str(root)], text=True
    ))
    assert result["timed_sides"] == 320 and result["minimum_timed_side_ns"] >= 200_000_000
    references = historical_warm(root / "inputs", capture_host)
    result["historical_s3_36b_warm_fifo"] = references
    result["repeat_comparisons"] = {}
    for mode in MODES:
        first, second = (result["results"][f"{mode}-{number}"] for number in (1, 2))
        result["repeat_comparisons"][mode] = {
            metric: {
                "second_over_first_median": second[metric]["median"] / first[metric]["median"],
                "observed_ranges_overlap": max(first[metric]["min"], second[metric]["min"])
                <= min(first[metric]["max"], second[metric]["max"]),
            }
            for metric in ("jit_ns_per_sweep", "interpreter_ns_per_sweep", "paired_jit_over_interpreter")
        }
    result["historical_s3_36b_ratios"] = {}
    for label, current in result["results"].items():
        if label.startswith("warm-"):
            jit_median = current["jit_ns_per_sweep"]["median"]
            interpreter_median = current["interpreter_ns_per_sweep"]["median"]
            jit_ratios = [jit_median / old["fifo_median_ns_per_sweep"] for old in references]
            interpreter_ratios = [
                interpreter_median / old["interpreter_median_ns_per_sweep"] for old in references
            ]
            result["historical_s3_36b_ratios"][label] = {
                "jit_over_historical_fifo_median_range": [min(jit_ratios), max(jit_ratios)],
                "interpreter_over_historical_interpreter_median_range": [
                    min(interpreter_ratios), max(interpreter_ratios)
                ],
            }
    result["provenance"] = provenance
    return result


if __name__ == "__main__":
    assert __debug__
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    print(json.dumps(audit(args.run.resolve(strict=True)), indent=2))
