from hashlib import sha256
from pathlib import Path
import sys

QOS_SHA = "add479bfa9524522d682178aaf130a883358e5d9b3840158fd9ecbfb765112c5"
HOOKS = tuple(
    b'        "' + mode + b'" => {\n'
    for mode in (b"cold-first-run", b"warm-branch-helper", b"warm-first-run")
)
CALL = (
    b'            #[cfg(all(target_os = "macos", target_arch = "aarch64"))]\n'
    b'            s3_56_benchmark_qos::prioritize_measurement_thread();\n'
)
MODULE = (
    b'\n#[cfg(all(target_os = "macos", target_arch = "aarch64"))]\n'
    b'mod s3_56_benchmark_qos;\n'
)


def instrument(main):
    assert all(main.count(hook) == 1 for hook in HOOKS)
    assert b"s3_56_benchmark_qos" not in main
    for hook in HOOKS:
        main = main.replace(hook, hook + CALL)
    return main + MODULE


if __name__ == "__main__":
    assert __debug__
    main, module, helper = map(Path, sys.argv[1:])
    qos = helper.read_bytes()
    assert sha256(qos).hexdigest() == QOS_SHA
    compiled = instrument(main.read_bytes())
    with module.open("xb") as output:
        output.write(qos)
    main.write_bytes(compiled)
