#!/bin/zsh
set -euo pipefail

harness=$(cd "$(dirname "$0")" && pwd)
repo=$(git -C "$harness" rev-parse --show-toplevel)
trial="$harness/build"
source_dir="$trial/source"
target_dir="$trial/target"
revision=11cbe6b197ca6414c021a0a7ddd53347dc35406b
target=aarch64-apple-darwin
binary="$trial/od-bench"
entitlements=apps/vmhost/Configuration/vmhost-smoke.entitlements
main=tools/bench/src/main.rs
dispatch=tools/bench/src/dispatch_cache.rs
qos=tools/bench/src/s3_56_benchmark_qos.rs
case_list=tests/fixtures/x86/stage3/s3_14_branch_helper_case_list.txt
trace=docs/reports/data/stage3/s3-36b/trace.json

[[ "$(/usr/bin/uname -sm)" == 'Darwin arm64' ]]
[[ "$(git -C "$repo" rev-parse --verify "${revision}^{commit}")" == "$revision" ]]
mkdir "$trial"
mkdir "$source_dir"
exec > >(tee "$trial/build.log") 2>&1
set -x
printf '%s\n' "$revision" > "$trial/revision"
git -C "$repo" rev-parse "${revision}^{tree}" > "$trial/tree"
git -C "$repo" archive "$revision" Cargo.toml Cargo.lock crates tools "$entitlements" \
    tests/fixtures/x86/stage3 docs/reports/data/stage3/s3-36b |
    tar -C "$source_dir" -xf -

cd "$source_dir"
export GIT_CEILING_DIRECTORIES="$trial"
if git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
    print -u2 "source export must be outside Git"
    exit 1
fi
source_paths=(
    Cargo.toml Cargo.lock "$entitlements" "$case_list" "$trace"
    tools/bench/{Cargo.toml,build.rs,src/{lib,record}.rs} "$main" "$dispatch"
    crates/od-isa/src/{execute,long_decode,state}.rs
    crates/od-jit/src/{dispatch,memory_cache,translation}.rs
    crates/od-host/src/lib.rs
)
shasum -a 256 "${source_paths[@]}" > "$trial/archive-source.sha256"

python3 "$harness/stage_qos.py" "$main" "$qos" "$harness/benchmark_qos.rs"
shasum -a 256 "${source_paths[@]}" "$qos" > "$trial/compiled-source.sha256"
{
    rustc --version --verbose
    cargo --version --verbose
    /usr/bin/xcodebuild -version
} > "$trial/toolchain.txt"
cargo build --jobs 4 --release --offline --locked -p od-bench --bin od-bench \
    --target "$target" --target-dir "$target_dir" --message-format=json > "$trial/build.jsonl"
shasum -a 256 --check --status "$trial/compiled-source.sha256"
cp "$target_dir/$target/release/od-bench" "$binary"
[[ "$(/usr/bin/lipo -archs "$binary")" == arm64 ]]
/usr/bin/codesign --force --sign - --options runtime --entitlements "$entitlements" "$binary"
/usr/bin/codesign --verify --strict "$binary"
/usr/bin/codesign -dv --verbose=4 "$binary" 2> "$trial/codesign.log"
/usr/bin/codesign -d --entitlements :- "$binary" > "$trial/entitlements.plist" 2>> "$trial/codesign.log"
rg -q 'flags=.*runtime' "$trial/codesign.log"
[[ "$(/usr/libexec/PlistBuddy -c 'Print :com.apple.security.cs.allow-jit' "$trial/entitlements.plist")" == true ]]
(cd "$trial" && shasum -a 256 od-bench > binary.sha256)
