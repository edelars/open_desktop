# S3-57 final S3-14 regression measurement

Build the unchanged benchmark implementation from
`11cbe6b197ca6414c021a0a7ddd53347dc35406b`. The isolated source copy
adds the verified QoS startup hook to the three entry commands. The
binary uses ARM64 release, ad hoc Hardened Runtime and `allow-jit`.
The build saves both source manifests, the build invocation and JSON
diagnostics, toolchain, signature and binary SHA-256.

```sh
harness=work/tmp/s3-57-final-s3-14
zsh "$harness/build.sh"
```

Select a host timing window using the existing Stage 3 monitoring setup.
Use a fresh run name. Run from the ordinary benchmark user with the
same noninteractive sudo/nice wrapper used for S3-56c.

```sh
harness=work/tmp/s3-57-final-s3-14
qos=work/tmp/stage3-benchmark-qos
name=run-01
for check in 1 2 3 4 5 6; do
    "$qos/cpu-idle"
done > "$harness/$name-preflight.log"

python3 "$qos/watch-load.py" "$harness/$name.finished" > "$harness/$name-load.log" &
load_monitor=$!
python3 "$harness/run.py" "$name" > "$harness/$name-score.log" 2>&1
score_status=$?
touch "$harness/$name.finished"
wait "$load_monitor"
test "$score_status" -eq 0
```

The runner verifies the immutable build, exact case list and trace, all
five fixture byte lengths and hashes, and three historic S3-36b warm
reports. It runs cold FIFO, cold generic, warm generic, and warm FIFO
once each, then repeats them in the opposite order. Every child must
confirm the ordinary UID, `nice=-5` and QoS `0x21`. Each command pairs
the JIT with the interpreter on the same fixtures. The audit checks
20 pairs per process, 320 scored intervals in total, the 200 ms
minimum, retirement and cache counters, both repeats, and the historical
warm reference on the same inputs. The benchmark checks state parity
before and during the sweeps.

On success replay the audit and archive the reproducibility artifacts.

```sh
python3 "$harness/audit.py" "$harness/$name" | cmp - "$harness/$name/audit.json"
tar -czf "$harness/$name-evidence.tar.gz" -C "$harness" \
    README.md build.sh stage_qos.py benchmark_qos.rs run.py audit.py audit_reports.py \
    "$name" "$name-score.log" "$name-preflight.log" "$name-load.log"
shasum -a 256 "$harness/$name-evidence.tar.gz"
```

The archive contains exact fixture bytes and reports, timing data,
schedule, score and load logs, build and signature provenance, and all
scripts needed for offline audit. After extraction run
`python3 audit.py run-01` from the extracted directory.
