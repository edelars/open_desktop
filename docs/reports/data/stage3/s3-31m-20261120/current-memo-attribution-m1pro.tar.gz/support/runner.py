#!/usr/bin/env python3
"""S3-30 M1 transport skeleton; never marks metrics accepted without its audit."""
from datetime import UTC, datetime, timedelta
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import signal
import shutil
import subprocess
import sys
import tempfile
import time

KIT = Path(__file__).resolve().parent
ROOT = KIT.parents[3]
REFERENCE = KIT / "reference/short-windows-v1/runner-check"
sys.path.insert(0, str(REFERENCE))
from host_load import (
    CoverageError,
    MAX_SAMPLE_GAP_SECONDS,
    aware_timestamp,
    host_load_result,
    preflight_result,
    sample_idle,
)

PROVENANCE_PATH = KIT / "provenance.json"
PROFILES = ("preflight-only", "compile", "warm-direct-entry", "warm-fifo16-dispatch")
REPORT_PROFILES = {
    "preflight-only": "preflight_only", "compile": "compile",
    "warm-direct-entry": "warm_direct_entry", "warm-fifo16-dispatch": "warm_fifo16_dispatch",
}
RUNNER_VERSION = "allocator-runner-fifo-v1"
CASE_IDS = (
    "s3_14_jz_to_end_skips_tail",
    "s3_14_jnz_to_end_skips_tail",
    "s3_14_jz_not_taken_backward_target",
    "s3_14_jnz_not_taken_backward_target",
    "s3_14_live_through_helpers",
)
EXEC = re.compile(r"stock_exec_pid_uid_nice=(\d+) (\d+) (-?\d+)")
PS = ["/bin/ps", "-ww", "-p"]
TIMEOUT = 900
RUN_MIN_IDLE = 80.0


class HostLoadRejected(Exception):
    """Timed host load or coverage failed after the benchmark itself completed."""

if not __debug__:
    raise SystemExit("run this harness with Python assertions enabled")


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(path):
    return sha_bytes(Path(path).read_bytes())


def json_file(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def read_json(path):
    value = json.loads(Path(path).read_bytes())
    assert type(value) is dict, f"expected a JSON object: {path}"
    return value


def command(*argv):
    return subprocess.check_output(argv, text=True).strip()


def utc():
    return datetime.now(UTC).isoformat()


def manifest():
    return read_json(PROVENANCE_PATH)


def verify_reference_runner():
    parent = REFERENCE.parent
    runner_manifest = parent / "runner.sha256"
    transfer_manifest = parent / "transfer.sha256"
    assert digest(runner_manifest) == "78c8798b2975442dfa4d4a75c41377f0340edc5ce55ccde62abf4b90a1858f48"
    assert digest(transfer_manifest) == "58cccfb78ff749730e7290d123b2dafe23aa46e1081b9341ff6c8d29f288bef9"
    for line in runner_manifest.read_text().splitlines():
        expected, relative = line.split("  ", 1)
        assert relative.startswith("runner-check/")
        path = REFERENCE / relative.removeprefix("runner-check/")
        assert path.is_file() and digest(path) == expected, relative


def verify_workspace_inputs():
    verify_reference_runner()
    pins = manifest()
    input_pins = (
        ("case_list_path", "case_list_sha256"),
        ("trace_path", "trace_sha256"),
        ("accepted_archive_path", "accepted_archive_sha256"),
    )
    for path_key, sha_key in input_pins:
        path = ROOT / pins[path_key]
        assert path.is_file() and not path.is_symlink(), path
        assert digest(path) == pins[sha_key], path
    bundle = ROOT / "work/tmp/s3-30-m1-base.uDY78ah3/stage3-s3-30-base.bundle"
    assert digest(bundle) == pins["base_bundle_sha256"]
    command("git", "bundle", "verify", str(bundle))
    heads = command("git", "bundle", "list-heads", str(bundle)).splitlines()
    assert heads == [f"{pins['base_revision']} refs/heads/codex"]
    assert command("git", "-C", str(ROOT), "rev-parse", f"{pins['base_revision']}^{{tree}}") == pins["base_tree"]
    return {
        "base_revision": pins["base_revision"],
        "base_tree": pins["base_tree"],
        "base_bundle_sha256": pins["base_bundle_sha256"],
        **{sha_key: pins[sha_key] for _, sha_key in input_pins},
    }


def verify_clean_execution_root():
    pins = manifest()
    assert command("git", "-C", str(ROOT), "rev-parse", "HEAD") == pins["base_revision"]
    assert command("git", "-C", str(ROOT), "rev-parse", "HEAD^{tree}") == pins["base_tree"]
    status = subprocess.check_output(
        ["git", "-C", str(ROOT), "status", "--porcelain", "--untracked-files=all"], text=True,
    )
    assert not status.strip(), "benchmark execution root must be a clean baseline worktree"


def verify_m1():
    assert command("/usr/bin/uname", "-sm") == "Darwin arm64"
    assert command("/usr/sbin/sysctl", "-n", "machdep.cpu.brand_string") == "Apple M1 Pro"
    uid = os.getuid()
    assert uid == manifest()["m1_uid"]
    return uid


def verify_source(repo):
    pins = manifest()
    repo = Path(repo).resolve()
    assert command("git", "-C", str(repo), "rev-parse", "HEAD") == pins["base_revision"]
    assert command("git", "-C", str(repo), "rev-parse", "HEAD^{tree}") == pins["base_tree"]
    patches = pins.get("patches", [])
    assert len(patches) == 3, "candidate, FIFO16, and harness patches must all be pinned"
    for patch in patches:
        path = KIT / patch["path"]
        assert path.is_file() and not path.is_symlink()
        assert digest(path) == patch["sha256"], path
    binding_path = KIT / "source-binding.json"
    assert binding_path.is_file() and digest(binding_path) == pins.get("source_binding_sha256")
    binding = read_json(binding_path)
    assert binding["revision"] == pins["base_revision"] and binding["tree"] == pins["base_tree"]
    expected_files = binding["files"]
    assert len(expected_files) == 8
    observed_status = subprocess.check_output(
        ["git", "-C", str(repo), "status", "--porcelain", "--untracked-files=all"], text=True,
    )
    changed_paths = set()
    for line in observed_status.splitlines():
        assert len(line) >= 4
        changed_paths.add(line[3:])
    assert changed_paths == set(expected_files), (changed_paths, set(expected_files))
    for relative, expected_sha in expected_files.items():
        path = repo / relative
        assert path.is_file() and not path.is_symlink() and digest(path) == expected_sha, relative
    for patch in patches:
        expected_paths = patch["changed_paths"]
        assert expected_paths and set(expected_paths) <= set(expected_files)
    assert set(expected_files) == {
        "crates/od-jit/Cargo.toml", "crates/od-jit/src/allocator.rs",
        "crates/od-jit/src/block_compile.rs", "crates/od-jit/src/dispatch.rs",
        "tools/bench/Cargo.toml",
        "tools/bench/src/dispatch_cache.rs", "tools/bench/src/dispatch_cache/s3_30_allocator_compare.rs",
        "tools/bench/src/main.rs",
    }
    binding_sha = pins["source_binding_sha256"]
    return {"revision": pins["base_revision"], "tree": pins["base_tree"],
            "source_binding_sha256": binding_sha}


def binary_evidence(binary, expected):
    pinned = manifest().get("native_binary_sha256")
    assert pinned and expected == pinned, "native binary hash is not frozen in provenance"
    assert expected and re.fullmatch(r"[0-9a-f]{64}", expected)
    assert digest(binary) == expected
    subprocess.run(["/usr/bin/codesign", "--verify", "--strict", str(binary)], check=True)
    assert command("/usr/bin/lipo", "-archs", str(binary)) == "arm64"
    mach = command("/usr/bin/otool", "-l", str(binary))
    assert re.findall(r"^\s*minos\s+(\S+)\s*$", mach, re.M) == ["14.0"]
    signature = subprocess.run(
        ["/usr/bin/codesign", "-dv", "--verbose=4", str(binary)], capture_output=True, check=True,
    )
    assert b"runtime)" in signature.stderr
    entitlement = subprocess.run(
        ["/usr/bin/codesign", "-d", "--entitlements", ":-", str(binary)], capture_output=True, check=True,
    )
    assert plistlib.loads(entitlement.stdout) == {"com.apple.security.cs.allow-jit": True}
    return {
        "mach-o.log": ("lipo_archs=arm64\n" + mach + "\n").encode(),
        "codesign.log": signature.stderr + entitlement.stderr,
        "entitlements.plist": entitlement.stdout,
    }


def verify_binary(binary, expected, directory):
    evidence = binary_evidence(binary, expected)
    for name, contents in evidence.items():
        (directory / name).write_bytes(contents)


def verify_native_preflight(path, binary, binary_hash, source):
    report = read_json(path)
    assert set(report) == {
        "binary_identity", "compile_evidence", "host_metadata", "preflight", "process_run",
        "profile", "run_outcome", "schema", "timing_started", "workload",
    }
    assert type(report["schema"]) is int and report["schema"] == 1
    assert report["profile"] == "preflight_only"
    assert report["run_outcome"] == "preflight_passed"
    assert type(report["timing_started"]) is bool and report["timing_started"] is False
    assert type(report["process_run"]) is int and report["process_run"] == 1
    launch_log = Path(path).with_suffix(".log")
    assert launch_log.is_file() and not launch_log.is_symlink()
    launch_matches = EXEC.findall(launch_log.read_text())
    assert len(launch_matches) == 1
    launch_pid, launch_uid, launch_nice = map(int, launch_matches[0])
    assert launch_pid > 1 and launch_uid == manifest().get("m1_uid") == 501 and launch_nice == -5
    assert type(report["workload"]) is dict
    identity = report["binary_identity"]
    assert set(identity) == {
        "name", "version", "executable_path", "executable_sha256", "target_os",
        "target_arch", "release_build", "candidate_feature",
    }
    assert identity["executable_sha256"] == binary_hash
    assert Path(identity["executable_path"]).resolve() == Path(binary).resolve()
    assert type(identity["release_build"]) is bool and identity["release_build"] is True
    assert (identity["name"], identity["version"], identity["target_os"], identity["target_arch"]) == (
        "od-bench", "0.1.0", "macos", "aarch64",
    )
    assert identity["candidate_feature"] == "s3-30-dead-home-candidate"
    expected_workload_path = KIT / "schema-reference/fifo16-integrated-release-preflight.json"
    assert digest(expected_workload_path) == manifest()["schema_reference_report_sha256"]
    expected_workload = read_json(expected_workload_path)["workload"]
    embedded_timed_fields = {
        "ordinary_eager_flags": True,
        "correctness": "untimed full interpreter, baseline/candidate direct entry, baseline/candidate FIFO dispatcher preflight passed",
    }
    assert report["workload"] in (expected_workload, {**expected_workload, **embedded_timed_fields})
    assert type(report["compile_evidence"]) is str and report["compile_evidence"].strip()
    host = report["host_metadata"]
    assert set(host) == {"architecture", "build", "cpu_model", "execution", "os", "os_version"}
    assert (host["architecture"], host["os"]) == ("aarch64", "macos")
    assert host["cpu_model"] == "Apple M1 Pro"
    assert host["build"]["profile"] == "release"
    assert host["build"]["source_revision"] == manifest()["base_revision"]
    assert host["build"]["source_tree_dirty"] is True
    assert host["build"]["target"] == "aarch64-apple-darwin"
    assert host["execution"]["repository_revision"] == manifest()["base_revision"]
    assert host["execution"]["working_tree_dirty"] is False
    preflight = report["preflight"]
    assert set(preflight) == {
        "case_rows", "full_state_interpreter_and_native_checks_passed", "native_full_entry_exit_contract",
        "ordinary_fifo_sweep", "pressure_continuation_exit_contract", "pressure_probe_scope",
        "s3_30c_baseline_emission_census", "targeted_pressure_stop_budget_continuation", "fifo_preflight",
    }
    assert preflight["full_state_interpreter_and_native_checks_passed"] is True
    exemplar = read_json(expected_workload_path)["preflight"]
    assert preflight["native_full_entry_exit_contract"] == exemplar["native_full_entry_exit_contract"]
    assert preflight["pressure_continuation_exit_contract"] == exemplar["pressure_continuation_exit_contract"]
    assert preflight["pressure_probe_scope"] == exemplar["pressure_probe_scope"]
    sweep = preflight["ordinary_fifo_sweep"]
    assert sweep == {
        "calls": 5, "compiles": 5, "misses": 5, "native_blocks": 5,
        "publications": 5, "retired_guest_instructions": 14,
    }
    census = preflight["s3_30c_baseline_emission_census"]
    assert set(census) == {
        "accepted_measurement_archive_sha256", "blocks", "case_list_sha256",
        "dynamic_transfer_count_limit", "dynamic_transfer_counts", "elapsed_preparation_ns",
        "normal_fifo_sweep", "profile", "schema", "timing", "trace_sha256",
        "trace_visit_count", "trace_weighted_static_allocator_transfer_sites",
    }
    assert type(census["elapsed_preparation_ns"]) is int and census["elapsed_preparation_ns"] >= 0
    assert census["accepted_measurement_archive_sha256"] == expected_workload["accepted_archive_sha256"]
    assert census["case_list_sha256"] == expected_workload["case_list_sha256"]
    assert census["trace_sha256"] == expected_workload["trace_sha256"]
    assert census["trace_visit_count"] == expected_workload["case_visits"]
    rows = preflight["case_rows"]
    assert [row["case_id"] for row in rows] == list(CASE_IDS)
    for index, row in enumerate(rows):
        assert row["entry_rip"] == expected_workload["entry_rips"][index]
        assert row["program_sha256"] == expected_workload["input_bytes_sha256"][index]
        assert row["interpreter_full_state_matches_prepared_oracle"] is True
        assert type(row["instruction_budget"]) is int and row["instruction_budget"] > 0
        assert row["interpreter_retired"] == row["expected_retired"]
        assert row["native"] and len(row["native"]) == 2
        assert row["allocation_observation"] and len(row["allocation_observation"]) == 2
        native_by_variant = {entry["variant"]: entry for entry in row["native"]}
        allocation_by_variant = {entry["variant"]: entry for entry in row["allocation_observation"]}
        assert set(native_by_variant) == {"fixed_homes4", "strict_dead_home"}
        assert set(allocation_by_variant) == set(native_by_variant)
        for variant, native in native_by_variant.items():
            observation = allocation_by_variant[variant]
            native_hash = native["in_process_emitted_code_sha256"]
            allocation_hash = observation["in_process_emitted_code_sha256"]
            assert re.fullmatch(r"[0-9a-f]{64}", native_hash)
            assert re.fullmatch(r"[0-9a-f]{64}", allocation_hash)
            assert native_hash == allocation_hash, "in-process publication/allocation bytes differ"
            assert native["compile_phase"] == "first_compile"
            assert native["exit"] == "DispatchCandidate"
            assert native["full_state_matches_interpreter"] is True
            assert native["retired"] == row["expected_retired"]
            assert native["remaining_budget"] == row["expected_remaining_budget"]
            assert observation["compile_phase"] == "repeat_compile"
            assert observation["emitted_bytes_match_whole_compiler"] is True
            assert observation["first_repeat_emitted_bytes_match"] is True
            assert observation["emitted_code_bytes"] == native["emitted_code_bytes"]
    pressure = preflight["targeted_pressure_stop_budget_continuation"]
    assert pressure == exemplar["targeted_pressure_stop_budget_continuation"]
    assert preflight["fifo_preflight"] == exemplar["fifo_preflight"]
    from timed_replay import _validate_fifo_preflight
    _validate_fifo_preflight(preflight, report)
    return {
        "schema": 1,
        "run_outcome": "preflight_passed",
        "report_sha256": digest(path),
        "binary_sha256": binary_hash,
        "source_binding_sha256": source["source_binding_sha256"],
        "input_pins": verify_workspace_inputs(),
        "case_ids": list(CASE_IDS),
        "binary_identity": identity,
        "preflight_process": {
            "pid": launch_pid,
            "uid": launch_uid,
            "nice": launch_nice,
            "launcher_log_sha256": digest(launch_log),
        },
    }


def argv_for(binary, uid, profile, process_run, output_path):
    pins = manifest()
    return [
        "/usr/bin/sudo", "-n", "/usr/bin/nice", "-n", "-5",
        "/usr/bin/sudo", "-n", "-u", f"#{uid}", "--", "/bin/sh",
        str(REFERENCE / "exec-nice.sh"), str(uid), str(binary), "allocator-compare-s3-30",
        "--case-list", str(ROOT / pins["case_list_path"]),
        "--trace", str(ROOT / pins["trace_path"]),
        "--accepted-archive", str(ROOT / pins["accepted_archive_path"]),
        "--profile", profile, "--process-run", str(process_run), "--output", str(output_path),
    ]


def archive_reference(path, out, profile, process_run):
    """Store portable preflight path within the packaged kit or series tree."""
    path = Path(path).resolve()
    out = Path(out).resolve()
    try:
        relative = path.relative_to(KIT)
        return f"kit:{relative.as_posix()}"
    except ValueError:
        pass
    assert out.name.startswith("try-") and out.parent.name == f"round-{process_run}" \
        and out.parent.parent.name == profile, "timed output must be PROFILE/round-N/try-N under its series root"
    series_root = out.parents[2]
    relative = path.relative_to(series_root)
    assert relative.parts and relative.parts[0] == "preflight"
    return f"series:{relative.as_posix()}"


def archive_output_reference(out, profile, process_run):
    out = Path(out).resolve()
    if profile == "preflight-only":
        assert out.name.startswith("try-") and out.parent.name == "preflight"
        series_root = out.parents[1]
    else:
        assert out.name.startswith("try-") and out.parent.name == f"round-{process_run}" \
            and out.parent.parent.name == profile
        series_root = out.parents[2]
    relative = out.relative_to(series_root)
    return f"series:{relative.as_posix()}"


def verify_archived_output_path(out, receipt):
    out = Path(out).resolve()
    ref = receipt["output_archive_ref"]
    assert ref.startswith("series:")
    relative = Path(ref.split(":", 1)[1])
    assert not relative.is_absolute() and ".." not in relative.parts
    if receipt["profile"] == "preflight-only":
        assert relative.parts[0] == "preflight"
        series_root = out.parents[1]
    else:
        assert relative.parts == (receipt["profile"], f"round-{receipt['round']}", out.name)
        series_root = out.parents[2]
    assert (series_root / relative).resolve() == out
    original = Path(receipt["output"])
    assert original.is_absolute() and tuple(original.parts[-len(relative.parts):]) == relative.parts


def resolve_archive_reference(reference, out, receipt_absolute_path):
    assert type(reference) is str and ":" in reference
    namespace, relative = reference.split(":", 1)
    target_rel = Path(relative)
    assert not target_rel.is_absolute() and ".." not in target_rel.parts
    if namespace == "kit":
        target = (KIT / target_rel).resolve()
    elif namespace == "series":
        out = Path(out).resolve()
        assert out.name.startswith("try-") and out.parent.name.startswith("round-")
        series_root = out.parents[2]
        target = (series_root / target_rel).resolve()
        assert target.is_relative_to(series_root)
        original = Path(receipt_absolute_path)
        assert original.is_absolute() and tuple(original.parts[-len(target_rel.parts):]) == target_rel.parts
    else:
        raise AssertionError("unknown archive reference namespace")
    assert target.is_dir(), f"archived referenced directory missing: {target}"
    return target


def ps_row(pid):
    args = [*PS, str(pid), "-o", "pid=", "-o", "uid=", "-o", "nice=", "-o", "command="]
    result = subprocess.run(args, text=True, capture_output=True)
    return result.stdout.strip() if result.returncode == 0 else ""


def process_identity(row, binary):
    fields = row.split(maxsplit=3)
    if len(fields) != 4 or not fields[3].startswith(f"{binary} allocator-compare-s3-30 "):
        return None
    try:
        return tuple(map(int, fields[:3]))
    except ValueError:
        return None


def require_process_identity(row, binary, uid):
    observed = process_identity(row, binary)
    assert observed is not None and observed[1:] == (uid, -5), (observed, uid)
    return observed


def stop_child(child, pid, binary, uid):
    receipt = {"signals": [], "errors": [], "reaped": False}

    def send_to_stock(sig):
        if child.poll() is None and pid and process_identity(ps_row(pid), binary) == (pid, uid, -5):
            try:
                if child.poll() is None:
                    os.kill(pid, sig)
                receipt["signals"].append(["stock", sig.name])
            except ProcessLookupError:
                pass
            except PermissionError as error:
                receipt["errors"].append(["stock", sig.name, error.errno])

    for phase in ((signal.SIGTERM,),):
        for sig in phase:
            send_to_stock(sig)
        try:
            child.wait(timeout=5)
            receipt["reaped"] = True
            return receipt
        except subprocess.TimeoutExpired:
            pass
    try:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            receipt["signals"].append(["group", signal.SIGTERM.name])
        child.wait(timeout=5)
        receipt["reaped"] = True
        return receipt
    except ProcessLookupError:
        pass
    except subprocess.TimeoutExpired:
        pass
    if child.poll() is None:
        os.killpg(child.pid, signal.SIGKILL)
        receipt["signals"].append(["group", signal.SIGKILL.name])
    child.wait(timeout=5)
    receipt["reaped"] = True
    return receipt


def run_native(directory, repo, binary, binary_hash, uid, profile, process_run):
    report = directory / f"{profile}.json"
    log = directory / f"{profile}.log"
    argv = argv_for(binary, uid, profile, process_run, report)
    start_mono = time.monotonic()
    entry = {"profile": profile, "started_at": utc(), "argv": argv}
    pid = None
    with log.open("xb") as stream:
        child = subprocess.Popen(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            while time.monotonic() - start_mono < 12:
                matches = EXEC.findall(log.read_text())
                if matches:
                    assert len(matches) == 1
                    pid, effective_uid, nice_value = map(int, matches[0])
                    assert (effective_uid, nice_value) == (uid, -5)
                    observed_ps = ps_row(pid)
                    actual = process_identity(observed_ps, binary)
                    if actual is not None:
                        assert actual == (pid, uid, -5)
                        entry.update(pid=pid, scheduling_pid_verified=True, uid=uid, effective_nice=nice_value)
                        (directory / f"{profile}.ps").write_text(observed_ps + "\n")
                        break
                assert child.poll() is None, log.read_text()
                # The native preflight can complete in well under 50 ms. Keep
                # the first PID observation window narrow enough that the
                # signed runner's same-process UID/nice receipt is not lost.
                time.sleep(0.001)
            else:
                raise RuntimeError("no stock allocator benchmark PID identity receipt")
            entry["returncode"] = child.wait(timeout=TIMEOUT)
        except subprocess.TimeoutExpired:
            entry["timed_out"] = True
            raise
        finally:
            try:
                if child.poll() is None:
                    entry["cleanup"] = stop_child(child, pid, binary, uid)
            finally:
                entry.setdefault("returncode", child.poll())
                entry["completed_at"] = utc()
    assert digest(binary) == binary_hash
    entry["raw_sha256"] = digest(report)
    entry["raw_size_bytes"] = report.stat().st_size
    entry["captured_json_object"] = True
    raw = read_json(report)
    expected_outcome = "preflight_passed" if profile == "preflight-only" else "complete"
    entry["run_outcome"] = raw.get("run_outcome")
    entry["benchmark_outcome_passed"] = entry["returncode"] == 0 and entry["run_outcome"] == expected_outcome
    entry["metric_audit"] = "pending_final_m1_metric_audit"
    return entry, raw


def prepare_cpu_idle(directory):
    monitor = directory / "host-load"
    monitor.mkdir(exist_ok=True)
    assert not monitor.is_symlink()
    probe = monitor / "cpu-idle"
    source = REFERENCE / "host-load/cpu_idle.c"
    copied_source = monitor / "cpu_idle.c"
    copied_source.write_bytes(source.read_bytes())
    if not probe.exists():
        subprocess.run([
            "/usr/bin/clang", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror",
            str(copied_source), "-o", str(probe)
        ], check=True)
    return monitor, probe


def run_host_preflight(directory):
    _, probe = prepare_cpu_idle(directory)
    preflight_log = directory / "preflight.log"
    with preflight_log.open("xb") as stream:
        for _ in range(24):
            subprocess.run([str(probe)], stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=8)
    preflight = preflight_result(preflight_log.read_text())
    assert preflight["probes"] == 24, preflight
    return preflight


def analyze_timed_load(text, timeline):
    try:
        result = host_load_result(text, timeline)
    except CoverageError as error:
        raise HostLoadRejected(f"host-load coverage rejected: {error}") from error
    samples = [(aware_timestamp(stamp), sample_idle(idle))
               for stamp, idle in (line.split(maxsplit=1) for line in text.splitlines())]
    minima = []
    for entry in timeline:
        start, end = (aware_timestamp(entry[key]) for key in ("started_at", "completed_at"))
        overlap = [idle for stamp, idle in samples
                   if stamp + timedelta(seconds=1) > start and stamp - timedelta(seconds=2) < end]
        if not overlap or min(overlap) < RUN_MIN_IDLE:
            raise HostLoadRejected(
                f"timed overlap idle floor rejected: {min(overlap) if overlap else 'no samples'}"
            )
        minima.append(min(overlap))
    return result, minima


def validate_captured_duration(raw, timeline_entry):
    start = aware_timestamp(timeline_entry["started_at"])
    end = aware_timestamp(timeline_entry["completed_at"])
    delta = end - start
    captured_ns = ((delta.days * 86_400 + delta.seconds) * 1_000_000_000
                   + delta.microseconds * 1_000)
    serialized_ns = sum(item["calibration_wall_ns"] for item in raw["calibration"])
    for rejected in raw["rejected_measurement_attempts"]:
        serialized_ns += sum(pair["pair_wall_ns"] for pair in rejected["pairs"])
    serialized_ns += sum(pair["pair_wall_ns"] for pair in raw["pairs"])
    assert captured_ns + 1_000_000 >= serialized_ns, (
        f"captured process interval {captured_ns}ns is shorter than serialized timing work {serialized_ns}ns"
    )
    return {"captured_elapsed_ns": captured_ns, "serialized_timing_wall_ns": serialized_ns,
            "rounding_tolerance_ns": 1_000_000}


def monitor_timed_profile(directory, callback, timeline):
    monitor, _ = prepare_cpu_idle(directory)
    watcher_script = monitor / "watch-load.py"
    watcher_script.write_bytes((REFERENCE / "host-load/watch-load.py").read_bytes())

    finish = directory / "finished"
    log = directory / "host-load.log"
    err = directory / "host-load.stderr"
    with log.open("xb") as stdout, err.open("xb") as stderr:
        watcher = subprocess.Popen([sys.executable, str(watcher_script), str(finish)],
                                   stdout=stdout, stderr=stderr)
        try:
            callback()
        finally:
            finish.touch()
            assert watcher.wait(timeout=15) == 0
    assert not err.read_bytes()
    result, minima = analyze_timed_load(log.read_text(), timeline)
    for entry, minimum in zip(timeline, minima):
        entry["during_min_idle_pct"] = minimum
    return result


def run(repo, binary, binary_hash, out, profile, process_run, preflight_dir=None):
    repo, binary, out = (Path(path).resolve() for path in (repo, binary, out))
    assert profile in PROFILES and process_run in (1, 2, 3)
    assert (profile != "preflight-only") or process_run == 1
    source = verify_source(repo)
    input_pins = verify_workspace_inputs()
    verify_clean_execution_root()
    uid = verify_m1()
    if profile in ("compile", "warm-direct-entry", "warm-fifo16-dispatch"):
        assert preflight_dir is not None, "timed profiles require the signed preflight-only run"
        binding_path = Path(preflight_dir).resolve() / "preflight-binding.json"
        binding = read_json(binding_path)
        preflight_json = Path(preflight_dir).resolve() / "preflight-only.json"
        assert binding["run_outcome"] == "preflight_passed"
        assert binding["binary_sha256"] == binary_hash
        assert binding["source_binding_sha256"] == source["source_binding_sha256"]
        assert binding["input_pins"] == input_pins
        assert binding["report_sha256"] == digest(preflight_json)
        signed_preflight = verify_native_preflight(preflight_json, binary, binary_hash, source)
        assert binding == signed_preflight
        validate_fresh_preflight_against_m1(
            preflight_dir, binary, binary_hash, source["source_binding_sha256"], binding,
        )
        preflight_archive_ref = archive_reference(preflight_dir, out, profile, process_run)
    else:
        preflight_archive_ref = None
    out.parent.mkdir(parents=True, exist_ok=True)
    out.mkdir()
    assert not out.is_symlink()
    verify_binary(binary, binary_hash, out)
    host_lines = [command("/usr/sbin/sysctl", "-n", "machdep.cpu.brand_string"),
                  command("/usr/bin/uname", "-a"), command("/usr/bin/sw_vers"),
                  command("/usr/bin/pmset", "-g", "batt")]
    (out / "host.log").write_text("\n".join(host_lines) + "\n")
    host_preflight = run_host_preflight(out)
    timeline = []
    invocation_error = None
    attempted_at = utc()

    def invoke():
        entry, _ = run_native(out, repo, binary, binary_hash, uid, profile, process_run)
        timeline.append(entry)

    during = None
    host_load_rejection = None
    if host_preflight["accepted"]:
        try:
            if profile == "preflight-only":
                invoke()
            else:
                during = monitor_timed_profile(out, invoke, timeline)
        except Exception as error:
            if isinstance(error, HostLoadRejected):
                host_load_rejection = str(error)
            else:
                invocation_error = f"{type(error).__name__}: {error}"
    binding = None
    if profile == "preflight-only" and host_preflight["accepted"] and timeline and invocation_error is None:
        try:
            binding = verify_native_preflight(out / "preflight-only.json", binary, binary_hash, source)
            json_file(out / "preflight-binding.json", binding)
        except Exception as error:
            invocation_error = f"{type(error).__name__}: {error}"
    benchmark_rejected = any(not entry.get("benchmark_outcome_passed", False) for entry in timeline)
    receipt = {
        "controller_version": RUNNER_VERSION,
        "status": (
            "host_preflight_rejected" if not host_preflight["accepted"] else
            "benchmark_rejected" if benchmark_rejected else
            "host_load_rejected" if host_load_rejection else
            "transport_only_metrics_pending" if timeline and invocation_error is None else "transport_failed"
        ),
        "round": process_run,
        "profile": profile,
        "revision": source["revision"],
        "tree": source["tree"],
        "source_binding_sha256": source["source_binding_sha256"],
        "binary": str(binary),
        "binary_sha256": binary_hash,
        "harness": str(KIT),
        "output": str(out),
        "output_archive_ref": archive_output_reference(out, profile, process_run),
        "input_paths": {
            "case_list": str(ROOT / manifest()["case_list_path"]),
            "trace": str(ROOT / manifest()["trace_path"]),
            "accepted_archive": str(ROOT / manifest()["accepted_archive_path"]),
        },
        "uid": uid,
        "host_load_preflight": host_preflight,
        "during": during,
        "host_load_rejection": host_load_rejection,
        "preflight_dir": str(Path(preflight_dir).resolve()) if preflight_dir else None,
        "preflight_archive_ref": preflight_archive_ref,
        "preflight_binding": binding,
        "invocation_error": invocation_error,
        "input_pins": input_pins,
        "timeline": timeline,
        "file_sha256": {},
        "attempted_at": attempted_at,
        "finished_at": utc(),
    }
    for path in out.rglob("*"):
        if path.name not in ("receipt.json", "finished") and path.is_file():
            receipt["file_sha256"][path.relative_to(out).as_posix()] = digest(path)
    json_file(out / "receipt.json", receipt)
    return receipt


def replay(out):
    """Offline replay of one retained attempt; no M1 or binary is required."""
    out = Path(out).resolve()
    receipt = read_json(out / "receipt.json")
    assert receipt["controller_version"] == RUNNER_VERSION
    assert receipt["profile"] in PROFILES and receipt["round"] in (1, 2, 3)
    statuses = {
        "host_preflight_rejected", "host_load_rejected", "transport_only_metrics_pending", "benchmark_rejected",
    }
    assert receipt["status"] in statuses, "transport failures are retained but cannot count as attempts"
    assert receipt["binary"] and receipt["binary_sha256"] == manifest()["native_binary_sha256"]
    assert receipt["source_binding_sha256"] == manifest()["source_binding_sha256"]
    verify_archived_output_path(out, receipt)
    assert receipt["input_pins"] == verify_workspace_inputs()
    assert type(receipt["file_sha256"]) is dict and receipt["file_sha256"]

    observed_files = {}
    for path in out.rglob("*"):
        if path.name not in ("receipt.json", "finished") and path.is_file():
            relative = path.relative_to(out).as_posix()
            assert not path.is_symlink(), relative
            observed_files[relative] = digest(path)
    assert observed_files == receipt["file_sha256"], "receipt file inventory or hash mismatch"
    required = {
        "host.log", "mach-o.log", "codesign.log", "entitlements.plist", "preflight.log",
        "host-load/cpu_idle.c", "host-load/cpu-idle",
    }
    if receipt["profile"] == "preflight-only" and receipt["timeline"]:
        required |= {"preflight-only.json", "preflight-only.log", "preflight-only.ps"}
        if receipt["status"] == "transport_only_metrics_pending":
            required.add("preflight-binding.json")
    if receipt["profile"] != "preflight-only" and receipt["status"] != "host_preflight_rejected":
        required |= {"host-load.log", "host-load.stderr"}
        assert (out / "finished").is_file(), "watcher completion marker missing"
        if receipt["timeline"]:
            required |= {f"{receipt['profile']}.json", f"{receipt['profile']}.log", f"{receipt['profile']}.ps"}
    missing = {name for name in required if not (out / name).is_file()}
    assert not missing, f"missing retained evidence: {sorted(missing)}"
    for name, expected in receipt["file_sha256"].items():
        path = out / name
        assert path.is_file() and not path.is_symlink() and digest(path) == expected, name

    host_preflight = preflight_result((out / "preflight.log").read_text())
    assert host_preflight == receipt["host_load_preflight"] and host_preflight["probes"] == 24
    host_text = (out / "host.log").read_text()
    assert "Apple M1 Pro" in host_text and "arm64" in host_text
    mach_o = (out / "mach-o.log").read_text()
    assert mach_o.startswith("lipo_archs=arm64\n") and "minos 14.0" in mach_o
    assert "runtime)" in (out / "codesign.log").read_text()
    assert plistlib.loads((out / "entitlements.plist").read_bytes()) == {
        "com.apple.security.cs.allow-jit": True,
    }
    assert type(receipt["uid"]) is int and receipt["uid"] == manifest()["m1_uid"]

    if receipt["status"] == "host_preflight_rejected":
        assert host_preflight["accepted"] is False
        assert not receipt["timeline"] and receipt.get("host_load_rejection") is None
        if receipt["profile"] != "preflight-only":
            assert receipt["preflight_dir"] and receipt["preflight_archive_ref"]
            preflight_dir = resolve_archive_reference(
                receipt["preflight_archive_ref"], out, receipt["preflight_dir"],
            )
            validate_fresh_preflight_against_m1(
                preflight_dir, receipt["binary"], receipt["binary_sha256"], receipt["source_binding_sha256"],
            )
        return {"status": "host_preflight_rejected", "retryable": True,
                "profile": receipt["profile"], "round": receipt["round"]}
    assert host_preflight["accepted"] is True

    def verify_timeline_entry(entry, report_path):
        assert entry["scheduling_pid_verified"] is True
        assert type(entry["pid"]) is int and entry["pid"] > 1
        assert (entry["uid"], entry["effective_nice"]) == (receipt["uid"], -5)
        assert entry["metric_audit"] == "pending_final_m1_metric_audit"
        assert digest(report_path) == entry["raw_sha256"]
        assert entry["raw_size_bytes"] == report_path.stat().st_size and entry["captured_json_object"] is True
        assert process_identity((out / f"{receipt['profile']}.ps").read_text(), receipt["binary"]) == (
            entry["pid"], receipt["uid"], -5,
        )
        matches = EXEC.findall((out / f"{receipt['profile']}.log").read_text())
        assert len(matches) == 1 and tuple(map(int, matches[0])) == (entry["pid"], receipt["uid"], -5)
        return read_json(report_path)

    if receipt["profile"] == "preflight-only":
        assert receipt["round"] == 1 and receipt["during"] is None
        if receipt["status"] == "benchmark_rejected":
            assert len(receipt["timeline"]) == 1
            entry = receipt["timeline"][0]
            raw = verify_timeline_entry(entry, out / "preflight-only.json")
            assert entry["returncode"] != 0 or raw.get("run_outcome") != "preflight_passed"
            return {"status": "benchmark_rejected", "retryable": False,
                    "profile": receipt["profile"], "round": receipt["round"],
                    "run_outcome": raw.get("run_outcome"), "raw_report_sha256": digest(out / "preflight-only.json")}
        assert receipt["status"] == "transport_only_metrics_pending" and len(receipt["timeline"]) == 1
        entry = receipt["timeline"][0]
        raw = verify_timeline_entry(entry, out / "preflight-only.json")
        assert entry["returncode"] == 0 and raw.get("run_outcome") == "preflight_passed"
        assert entry["benchmark_outcome_passed"] is True
        source = {"source_binding_sha256": receipt["source_binding_sha256"]}
        binding = verify_native_preflight(out / "preflight-only.json", receipt["binary"],
                                          receipt["binary_sha256"], source)
        assert binding == receipt["preflight_binding"] == read_json(out / "preflight-binding.json")
        return {"status": "preflight_passed", "retryable": False,
                "profile": receipt["profile"], "round": receipt["round"],
                "preflight_binding_sha256": digest(out / "preflight-binding.json")}

    assert receipt["preflight_dir"] and receipt["preflight_archive_ref"]
    preflight_dir = resolve_archive_reference(
        receipt["preflight_archive_ref"], out, receipt["preflight_dir"],
    )
    fresh, _fresh_report, _fresh_binding = validate_fresh_preflight_against_m1(
        preflight_dir, receipt["binary"], receipt["binary_sha256"], receipt["source_binding_sha256"],
    )

    if receipt["status"] == "host_load_rejected":
        assert len(receipt["timeline"]) == 1
    if receipt["status"] in ("transport_only_metrics_pending", "host_load_rejected", "benchmark_rejected"):
        assert len(receipt["timeline"]) == 1
        assert not (out / "host-load.stderr").read_bytes()
        timeline = receipt["timeline"]
        try:
            during, minima = analyze_timed_load((out / "host-load.log").read_text(), timeline)
            assert during == receipt["during"]
            assert [entry["during_min_idle_pct"] for entry in timeline] == minima
            load_rejection = None
        except HostLoadRejected as error:
            load_rejection = str(error)
            assert receipt["host_load_rejection"] == load_rejection
            assert receipt["status"] in ("host_load_rejected", "benchmark_rejected")
        else:
            assert receipt.get("host_load_rejection") is None
            assert receipt["status"] != "host_load_rejected"
    else:
        # A timed host-preflight failure has no native process or timed samples.
        assert receipt["status"] == "host_preflight_rejected"
        return {"status": receipt["status"], "retryable": True,
                "profile": receipt["profile"], "round": receipt["round"]}

    entry = receipt["timeline"][0]
    raw = verify_timeline_entry(entry, out / f"{receipt['profile']}.json")
    passed = entry["returncode"] == 0 and raw.get("run_outcome") == "complete"
    assert entry["benchmark_outcome_passed"] == passed
    if not passed:
        assert receipt["status"] == "benchmark_rejected"
        return {"status": "benchmark_rejected", "retryable": False,
                "profile": receipt["profile"], "round": receipt["round"],
                "run_outcome": raw.get("run_outcome"), "returncode": entry["returncode"],
                "raw_report_sha256": digest(out / f"{receipt['profile']}.json")}
    assert receipt["status"] in ("transport_only_metrics_pending", "host_load_rejected")
    validate_timed_preflight_against_m1(
        raw, preflight_dir, receipt["binary"], receipt["binary_sha256"], receipt["source_binding_sha256"],
    )
    from timed_replay import validate_timed_report
    audit = validate_timed_report(raw)
    audit["captured_interval"] = validate_captured_duration(raw, entry)
    assert audit["profile"] == REPORT_PROFILES[receipt["profile"]]
    assert audit["process_run"] == receipt["round"]
    assert raw["binary_identity"]["executable_sha256"] == receipt["binary_sha256"]
    if load_rejection:
        assert receipt["status"] == "host_load_rejected"
        return {"status": "host_load_rejected", "retryable": True, "metrics_valid": True,
                "profile": receipt["profile"], "round": receipt["round"], "metric_audit": audit}
    assert receipt["status"] == "transport_only_metrics_pending"
    assert receipt["invocation_error"] is None
    return {"status": "attempt_passed", "retryable": False, "metrics_valid": True,
            "profile": receipt["profile"], "round": receipt["round"],
            "binary_sha256": receipt["binary_sha256"],
            "raw_report_sha256": digest(out / f"{receipt['profile']}.json"), "metric_audit": audit}


def live_reinspect(out):
    """Optional live M1/binary check; `replay` remains archive-only."""
    out = Path(out).resolve()
    receipt = read_json(out / "receipt.json")
    assert verify_m1() == receipt["uid"]
    evidence = binary_evidence(receipt["binary"], receipt["binary_sha256"])
    for name, contents in evidence.items():
        assert (out / name).read_bytes() == contents, f"retained {name} differs from live binary inspection"
    return {"status": "live_host_and_binary_reinspection_passed", "uid": receipt["uid"],
            "binary_sha256": receipt["binary_sha256"]}


def stable_preflight(value, path=()):
    """Strip only per-process ASLR code hashes and census preparation duration."""
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            recognized_digest_path = (
                len(path) == 4 and path[0] == "case_rows" and path[1].isdigit()
                and path[2] in ("native", "allocation_observation") and path[3].isdigit()
            )
            if key == "in_process_emitted_code_sha256" and recognized_digest_path:
                continue
            if path[-1:] == ("s3_30c_baseline_emission_census",) and key == "elapsed_preparation_ns":
                continue
            result[key] = stable_preflight(child, (*path, key))
        return result
    if isinstance(value, list):
        return [stable_preflight(child, (*path, str(index))) for index, child in enumerate(value)]
    return value


def replay_series(profile, *attempt_outputs):
    assert profile in ("compile", "warm-direct-entry", "warm-fifo16-dispatch")
    assert len(attempt_outputs) == 3
    outcomes = [replay(path) for path in attempt_outputs]
    assert all(item["status"] == "attempt_passed" and item["metrics_valid"] is True for item in outcomes), \
        f"series requires exactly three first-passing audited attempts: {outcomes}"
    reports = []
    receipts = []
    for path in attempt_outputs:
        out = Path(path).resolve()
        receipt = read_json(out / "receipt.json")
        report = read_json(out / f"{profile}.json")
        receipts.append(receipt)
        reports.append(report)
    assert [r["process_run"] for r in reports] == [1, 2, 3]
    assert [r["round"] for r in receipts] == [1, 2, 3]
    first = reports[0]
    stable = {
        "binary_identity": first["binary_identity"],
        "host_metadata": first["host_metadata"],
        "timing_contract": first["timing_contract"],
        "aggregate_definition": first["aggregate_definition"],
        "workload": first["workload"],
        "preflight": stable_preflight(first["preflight"]),
    }
    for index, report in enumerate(reports[1:], start=2):
        current = {
            "binary_identity": report["binary_identity"],
            "host_metadata": report["host_metadata"],
            "timing_contract": report["timing_contract"],
            "aggregate_definition": report["aggregate_definition"],
            "workload": report["workload"],
            "preflight": stable_preflight(report["preflight"]),
        }
        assert current == stable, f"round {index} changed stable workload/source/host/preflight fields"
    assert all(r["binary_sha256"] == receipts[0]["binary_sha256"] for r in receipts)
    assert all(r["source_binding_sha256"] == manifest()["source_binding_sha256"] for r in receipts)
    return {
        "status": "three_attempt_series_passed",
        "metrics_accepted": False,
        "profile": profile,
        "process_runs": [1, 2, 3],
        "binary_sha256": receipts[0]["binary_sha256"],
        "source_binding_sha256": receipts[0]["source_binding_sha256"],
        "report_sha256": [digest(Path(p).resolve() / f"{profile}.json") for p in attempt_outputs],
        "per_process_stats": [item["metric_audit"]["per_process_stats"] for item in outcomes],
        "cross_process_equality": "all stable fields exact; only in-process ASLR code SHA-256 values and baseline census elapsed_preparation_ns excluded",
    }


def validate_fresh_preflight_against_m1(preflight_dir, binary, binary_hash, source_hash, binding=None):
    fresh_dir = Path(preflight_dir)
    frozen_dir = KIT / "m1-preflight"
    frozen_path = frozen_dir / "preflight-only.json"
    frozen = read_json(frozen_path)
    assert digest(frozen_path) == manifest()["m1_preflight_sha256"]
    frozen_binding_path = frozen_dir / "preflight-binding.json"
    assert digest(frozen_binding_path) == manifest()["m1_preflight_binding_sha256"]
    source = {"source_binding_sha256": source_hash}
    frozen_binding = verify_native_preflight(frozen_path, binary, binary_hash, source)
    assert read_json(frozen_binding_path) == frozen_binding

    fresh_path = fresh_dir / "preflight-only.json"
    fresh = read_json(fresh_path)
    fresh_binding = verify_native_preflight(fresh_path, binary, binary_hash, source)
    stored_binding = read_json(fresh_dir / "preflight-binding.json")
    assert stored_binding == fresh_binding
    if binding is not None:
        assert stored_binding == binding
    assert fresh["binary_identity"] == frozen["binary_identity"]
    assert fresh["host_metadata"] == frozen["host_metadata"]
    assert fresh["workload"] == frozen["workload"]
    assert stable_preflight(fresh["preflight"]) == stable_preflight(frozen["preflight"]), \
        "fresh readiness preflight differs from the signed M1 exemplar outside ASLR hashes and census preparation duration"
    return frozen, fresh, fresh_binding


def validate_timed_preflight_against_m1(raw, preflight_dir, binary, binary_hash, source_hash):
    frozen, fresh, _ = validate_fresh_preflight_against_m1(
        preflight_dir, binary, binary_hash, source_hash,
    )
    timed_inputs = {key: value for key, value in fresh["workload"].items()
                    if key != "instruction_budget_and_full_state"}
    correctness = (
        "untimed full interpreter, baseline/candidate direct entry, baseline/candidate FIFO dispatcher preflight passed"
        if raw.get("profile") == "warm_fifo16_dispatch"
        else "untimed full interpreter, baseline/candidate direct entry, and FIFO sweep preflight passed"
    )
    expected_timed_workload = {
        **timed_inputs,
        "ordinary_eager_flags": True,
        "correctness": correctness,
    }
    assert raw["binary_identity"] == fresh["binary_identity"], "timed binary identity differs from readiness preflight"
    assert raw["host_metadata"] == fresh["host_metadata"], "timed host/source metadata differs from readiness preflight"
    assert raw["workload"] == expected_timed_workload, "timed workload differs from the exact accepted M1 input contract"
    assert stable_preflight(raw["preflight"]) == stable_preflight(fresh["preflight"]) == stable_preflight(frozen["preflight"]), \
        "timed preflight differs from fresh and signed M1 witnesses outside ASLR hashes and census preparation duration"

    # Reuse full untimed validation on the actual timed report's embedded rows.
    inline = json.loads(json.dumps(fresh))
    inline.update({
        "binary_identity": raw["binary_identity"],
        "host_metadata": raw["host_metadata"],
        # The inline verifier validates preflight contract and the raw timed
        # workload was checked against the exact timed projection above.
        "workload": fresh["workload"],
        "preflight": raw["preflight"],
    })
    with tempfile.TemporaryDirectory() as temporary:
        report_path = Path(temporary) / "preflight-only.json"
        json_file(report_path, inline)
        shutil.copyfile(Path(preflight_dir) / "preflight-only.log", report_path.with_suffix(".log"))
        verify_native_preflight(report_path, binary, binary_hash,
                                {"source_binding_sha256": source_hash})


def selftest():
    assert process_identity("812 501 -5 /tmp/od-bench allocator-compare-s3-30 --profile compile", "/tmp/od-bench") == (812, 501, -5)
    assert process_identity("812 501 -5 /tmp/od-bench other-command", "/tmp/od-bench") is None
    from test_timed_replay import make_report
    synthetic_timed = make_report("compile", process_run=1)
    serialized_wall_ns = (
        sum(item["calibration_wall_ns"] for item in synthetic_timed["calibration"])
        + sum(pair["pair_wall_ns"] for item in synthetic_timed["rejected_measurement_attempts"] for pair in item["pairs"])
        + sum(pair["pair_wall_ns"] for pair in synthetic_timed["pairs"])
    )
    interval_start = datetime(2026, 11, 20, tzinfo=UTC)
    interval_end = interval_start + timedelta(microseconds=(serialized_wall_ns + 2_000_000) // 1_000)
    valid_interval = validate_captured_duration(
        synthetic_timed, {"started_at": interval_start.isoformat(), "completed_at": interval_end.isoformat()},
    )
    assert valid_interval["captured_elapsed_ns"] >= serialized_wall_ns
    try:
        validate_captured_duration(
            synthetic_timed,
            {"started_at": interval_start.isoformat(), "completed_at": (interval_start + timedelta(seconds=1)).isoformat()},
        )
    except AssertionError:
        short_interval_rejected = True
    else:
        raise AssertionError("synthetic short process interval passed serialized timing work check")
    identity_rejected = []
    for mutated in (
        "812 501 0 /tmp/od-bench allocator-compare-s3-30 --profile compile",
        "812 502 -5 /tmp/od-bench allocator-compare-s3-30 --profile compile",
    ):
        try:
            require_process_identity(mutated, "/tmp/od-bench", 501)
        except AssertionError:
            identity_rejected.append("nice" if " 0 " in mutated else "uid")
        else:
            raise AssertionError("invalid UID or nice mutation was accepted")
    good = "\n".join(["cpu_idle=95.0% idle_ticks=95 total_ticks=100 over 2 seconds"] * 24) + "\n"
    accepted = preflight_result(good)
    assert accepted == {"probes": 24, "min_idle_pct": 95.0, "median_idle_pct": 95.0, "accepted": True}
    poor = good.replace("cpu_idle=95.0% idle_ticks=95", "cpu_idle=79.0% idle_ticks=79", 1)
    assert preflight_result(poor)["accepted"] is False
    pins = verify_workspace_inputs()
    assert pins["base_revision"] == "eb314737664ad1dd40297db4b92e8e1a9de4b6ea"
    synthetic = read_json(KIT / "schema-reference/fifo16-integrated-release-preflight.json")
    synthetic["binary_identity"].update(
        executable_path="/tmp/od-bench", executable_sha256="a" * 64, release_build=True,
    )
    synthetic["host_metadata"]["cpu_model"] = "Apple M1 Pro"
    synthetic["host_metadata"]["execution"]["working_tree_dirty"] = False
    source = {"source_binding_sha256": "b" * 64}
    with tempfile.TemporaryDirectory() as directory:
        report_path = Path(directory) / "preflight-only.json"
        json_file(report_path, synthetic)
        report_path.with_suffix(".log").write_text("stock_exec_pid_uid_nice=812 501 -5\n")
        binding = verify_native_preflight(report_path, "/tmp/od-bench", "a" * 64, source)
        assert binding["report_sha256"] == digest(report_path)
        mutations = []
        for name, change in (
            ("timing_started", lambda obj: obj.update(timing_started=True)),
            ("process_run", lambda obj: obj.update(process_run=2)),
            ("case_order", lambda obj: obj["preflight"]["case_rows"].reverse()),
            ("binary_sha", lambda obj: obj["binary_identity"].update(executable_sha256="c" * 64)),
            ("fifo_body_bytes", lambda obj: obj["preflight"]["fifo_preflight"]["sides"][0]["case_rows"][0].update(resident_code_bytes_delta=1)),
        ):
            mutated = json.loads(json.dumps(synthetic))
            change(mutated)
            json_file(report_path, mutated)
            try:
                verify_native_preflight(report_path, "/tmp/od-bench", "a" * 64, source)
            except (AssertionError, KeyError, TypeError):
                mutations.append(name)
            else:
                raise AssertionError(f"invalid preflight mutation was accepted: {name}")
        assert mutations == ["timing_started", "process_run", "case_order", "binary_sha", "fifo_body_bytes"]
        forged = Path(directory) / "series/preflight/try-1"
        forged.mkdir(parents=True)
        replay_mutation_rejected = False
        json_file(forged / "receipt.json", {
            "controller_version": RUNNER_VERSION, "profile": "preflight-only", "round": 1,
            "status": "transport_only_metrics_pending", "output": str(forged),
            "output_archive_ref": "series:preflight/try-1",
            "binary": "/tmp/od-bench", "binary_sha256": manifest()["native_binary_sha256"],
            "source_binding_sha256": manifest()["source_binding_sha256"],
            "input_pins": pins, "file_sha256": {"preflight-only.json": "a" * 64},
        })
        try:
            replay(forged)
        except (AssertionError, KeyError, FileNotFoundError):
            replay_mutation_rejected = True
        else:
            raise AssertionError("minimal forged replay receipt was accepted")
    accepted_m1 = read_json(KIT / "m1-preflight/preflight-only.json")
    m1_source = {"source_binding_sha256": manifest()["source_binding_sha256"]}
    m1_binary = accepted_m1["binary_identity"]["executable_path"]
    m1_binary_sha = manifest()["native_binary_sha256"]
    assert verify_native_preflight(KIT / "m1-preflight/preflight-only.json", m1_binary,
                                   m1_binary_sha, m1_source)["preflight_process"] == {
        "pid": 1185, "uid": 501, "nice": -5,
        "launcher_log_sha256": digest(KIT / "m1-preflight/preflight-only.log"),
    }
    base_stable = stable_preflight(accepted_m1["preflight"])
    normalized = json.loads(json.dumps(accepted_m1["preflight"]))
    normalized["case_rows"][0]["native"][0]["in_process_emitted_code_sha256"] = "f" * 64
    normalized["case_rows"][0]["allocation_observation"][0]["in_process_emitted_code_sha256"] = "f" * 64
    normalized["s3_30c_baseline_emission_census"]["elapsed_preparation_ns"] += 1
    assert stable_preflight(normalized) == base_stable
    semantic_mutations = []
    for label, mutate in (
        ("exit_tag", lambda obj: obj["case_rows"][0]["native"][0].update(exit="BudgetExhausted")),
        ("same_process_digest", lambda obj: obj["case_rows"][0]["allocation_observation"][0].update(in_process_emitted_code_sha256="e" * 64)),
        ("pressure_continuation", lambda obj: obj["targeted_pressure_stop_budget_continuation"][0].update(continuation_exit="invalid_exit_tag")),
        ("fifo_state", lambda obj: obj["fifo_preflight"]["sides"][1]["case_rows"][0].update(state_equal_other_variant=False)),
        ("fifo_code_bytes", lambda obj: obj["fifo_preflight"]["sides"][0]["case_rows"][4].update(resident_code_bytes_delta=3053)),
    ):
        altered = json.loads(json.dumps(accepted_m1["preflight"]))
        mutate(altered)
        altered_report = json.loads(json.dumps(accepted_m1))
        altered_report["preflight"] = altered
        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory) / "preflight-only.json"
            json_file(report, altered_report)
            shutil.copyfile(KIT / "m1-preflight/preflight-only.log", report.with_suffix(".log"))
            try:
                verify_native_preflight(report, m1_binary, m1_binary_sha, m1_source)
            except (AssertionError, KeyError, TypeError):
                semantic_mutations.append(label)
            else:
                raise AssertionError(f"M1 preflight semantic mutation accepted: {label}")
    assert semantic_mutations == ["exit_tag", "same_process_digest", "pressure_continuation", "fifo_state", "fifo_code_bytes"]
    offline_preflight_replay_passed = False
    offline_preflight_ps_mutation_rejected = False
    with tempfile.TemporaryDirectory() as directory:
        offline_out = Path(directory) / "series/preflight/try-1"
        (offline_out / "host-load").mkdir(parents=True)
        json_file(offline_out / "preflight-only.json", accepted_m1)
        shutil.copyfile(KIT / "m1-preflight/preflight-only.log", offline_out / "preflight-only.log")
        shutil.copyfile(KIT / "m1-preflight/preflight-binding.json", offline_out / "preflight-binding.json")
        (offline_out / "preflight-only.ps").write_text(
            f"1185 501 -5 {m1_binary} allocator-compare-s3-30 --profile preflight-only\n"
        )
        host_lines = ["Apple M1 Pro", "Darwin arm64", "ProductName: macOS", "synthetic battery receipt"]
        (offline_out / "host.log").write_text("\n".join(host_lines) + "\n")
        (offline_out / "mach-o.log").write_text("lipo_archs=arm64\nminos 14.0\n")
        (offline_out / "codesign.log").write_text("flags=0x10000(runtime)\n")
        (offline_out / "entitlements.plist").write_bytes(
            plistlib.dumps({"com.apple.security.cs.allow-jit": True})
        )
        (offline_out / "preflight.log").write_text(
            "\n".join(["cpu_idle=95.0% idle_ticks=95 total_ticks=100 over 2 seconds"] * 24) + "\n"
        )
        shutil.copyfile(REFERENCE / "host-load/cpu_idle.c", offline_out / "host-load/cpu_idle.c")
        (offline_out / "host-load/cpu-idle").write_bytes(b"synthetic captured probe executable\n")
        preflight_report = offline_out / "preflight-only.json"
        timeline_entry = {
            "profile": "preflight-only", "pid": 1185, "uid": 501, "effective_nice": -5,
            "scheduling_pid_verified": True, "returncode": 0, "run_outcome": "preflight_passed",
            "benchmark_outcome_passed": True, "metric_audit": "pending_final_m1_metric_audit",
            "raw_sha256": digest(preflight_report), "raw_size_bytes": preflight_report.stat().st_size,
            "captured_json_object": True,
        }
        offline_receipt = {
            "controller_version": RUNNER_VERSION, "status": "transport_only_metrics_pending",
            "profile": "preflight-only", "round": 1, "output": str(offline_out),
            "output_archive_ref": "series:preflight/try-1", "binary": m1_binary,
            "binary_sha256": m1_binary_sha, "source_binding_sha256": manifest()["source_binding_sha256"],
            "input_pins": pins, "uid": 501,
            "host_load_preflight": {"probes": 24, "min_idle_pct": 95.0, "median_idle_pct": 95.0, "accepted": True},
            "during": None, "host_load_rejection": None, "preflight_binding": read_json(KIT / "m1-preflight/preflight-binding.json"),
            "timeline": [timeline_entry], "file_sha256": {},
        }
        for path in offline_out.rglob("*"):
            if path.is_file() and path.name != "receipt.json":
                offline_receipt["file_sha256"][path.relative_to(offline_out).as_posix()] = digest(path)
        json_file(offline_out / "receipt.json", offline_receipt)
        assert replay(offline_out)["status"] == "preflight_passed"
        offline_preflight_replay_passed = True
        (offline_out / "preflight-only.ps").write_text(
            f"1185 502 -5 {m1_binary} allocator-compare-s3-30 --profile preflight-only\n"
        )
        offline_receipt["file_sha256"]["preflight-only.ps"] = digest(offline_out / "preflight-only.ps")
        json_file(offline_out / "receipt.json", offline_receipt)
        try:
            replay(offline_out)
        except AssertionError:
            offline_preflight_ps_mutation_rejected = True
        else:
            raise AssertionError("offline replay accepted mutated preflight ps UID")
    fresh_preflight_ok = False
    embedded_mutations = []
    with tempfile.TemporaryDirectory() as directory:
        fresh_dir = Path(directory) / "series/preflight/try-2"
        fresh_dir.mkdir(parents=True)
        fresh = json.loads(json.dumps(accepted_m1))
        fresh["preflight"]["s3_30c_baseline_emission_census"]["elapsed_preparation_ns"] += 1
        for index, row in enumerate(fresh["preflight"]["case_rows"]):
            native_by_variant = {entry["variant"]: entry for entry in row["native"]}
            alloc_by_variant = {entry["variant"]: entry for entry in row["allocation_observation"]}
            for variant_index, variant in enumerate(("fixed_homes4", "strict_dead_home")):
                different_aslr_digest = f"{(index * 2 + variant_index + 1):064x}"
                native_by_variant[variant]["in_process_emitted_code_sha256"] = different_aslr_digest
                alloc_by_variant[variant]["in_process_emitted_code_sha256"] = different_aslr_digest
        fresh_path = fresh_dir / "preflight-only.json"
        fresh_log = fresh_dir / "preflight-only.log"
        json_file(fresh_path, fresh)
        fresh_log.write_text("stock_exec_pid_uid_nice=97777 501 -5\n")
        fresh_binding = verify_native_preflight(fresh_path, m1_binary, m1_binary_sha, m1_source)
        json_file(fresh_dir / "preflight-binding.json", fresh_binding)
        assert digest(fresh_path) != manifest()["m1_preflight_sha256"]
        frozen, fresh_verified, _ = validate_fresh_preflight_against_m1(
            fresh_dir, m1_binary, m1_binary_sha, manifest()["source_binding_sha256"], fresh_binding,
        )
        assert stable_preflight(fresh_verified["preflight"]) == stable_preflight(frozen["preflight"])
        timed_workload = {key: value for key, value in fresh["workload"].items()
                          if key != "instruction_budget_and_full_state"}
        timed_preflight = {
            "binary_identity": fresh["binary_identity"],
            "host_metadata": fresh["host_metadata"],
            "workload": {
                **timed_workload, "ordinary_eager_flags": True,
                "correctness": "untimed full interpreter, baseline/candidate direct entry, baseline/candidate FIFO dispatcher preflight passed",
            },
            "profile": "warm_fifo16_dispatch",
            "preflight": fresh["preflight"],
        }
        validate_timed_preflight_against_m1(
            timed_preflight, fresh_dir, m1_binary, m1_binary_sha, manifest()["source_binding_sha256"],
        )
        fresh_preflight_ok = True
        for label, mutate in (
            ("timed_workload", lambda obj: obj["workload"].update(trace_sha256="0" * 64)),
            ("timed_host_build", lambda obj: obj["host_metadata"]["execution"].update(working_tree_dirty=True)),
            ("timed_native_exit", lambda obj: obj["preflight"]["case_rows"][0]["native"][0].update(exit="BudgetExhausted")),
            ("timed_fifo_code_bytes", lambda obj: obj["preflight"]["fifo_preflight"]["sides"][0]["case_rows"][4].update(resident_code_bytes_delta=1)),
        ):
            altered = json.loads(json.dumps(timed_preflight))
            mutate(altered)
            try:
                validate_timed_preflight_against_m1(
                    altered, fresh_dir, m1_binary, m1_binary_sha, manifest()["source_binding_sha256"],
                )
            except (AssertionError, KeyError, TypeError):
                embedded_mutations.append(label)
            else:
                raise AssertionError(f"timed preflight mutation accepted: {label}")
    assert fresh_preflight_ok
    assert embedded_mutations == ["timed_workload", "timed_host_build", "timed_native_exit", "timed_fifo_code_bytes"]
    print(json.dumps({"status": "transport_skeleton_selfcheck_passed", "metrics_accepted": False,
                      "host_load_preflight_24": accepted,
                      "serialized_timing_interval_checked": True,
                      "process_identity_mutations_rejected": identity_rejected,
                      "preflight_mutations_rejected": mutations,
                      "m1_preflight_semantic_mutations_rejected": semantic_mutations,
                      "offline_preflight_replay_passed": offline_preflight_replay_passed,
                      "offline_preflight_ps_mutation_rejected": offline_preflight_ps_mutation_rejected,
                      "fresh_preflight_aslr_variation_accepted": fresh_preflight_ok,
                      "timed_preflight_mutations_rejected": embedded_mutations,
                      "minimal_forged_replay_rejected": replay_mutation_rejected}, indent=2))


if __name__ == "__main__":
    action, *args = sys.argv[1:]
    result = None
    if action == "selftest" and not args:
        selftest()
    elif action == "run" and len(args) in (6, 7):
        result = run(args[0], args[1], args[2], args[3], args[4], int(args[5]),
                     args[6] if len(args) == 7 else None)
    elif action == "replay" and len(args) == 1:
        result = replay(args[0])
    elif action == "live-reinspect" and len(args) == 1:
        result = live_reinspect(args[0])
    elif action == "replay-series" and len(args) == 4:
        result = replay_series(args[0], *args[1:])
    else:
        raise SystemExit("usage: runner.py selftest | run SOURCE BINARY SHA OUT PROFILE PROCESS_RUN [PREFLIGHT_OUT] | replay OUT | replay-series PROFILE OUT1 OUT2 OUT3 | live-reinspect OUT")
    if result is not None:
        print(json.dumps(result, indent=2))
        if result.get("status") in ("host_preflight_rejected", "host_load_rejected"):
            raise SystemExit(75)
        if result.get("status") in ("benchmark_rejected", "transport_failed"):
            raise SystemExit(2)
