from datetime import datetime
import re
from statistics import median

IDLE = re.compile(r"cpu_idle=(\d{1,3}\.\d)% idle_ticks=(\d+) total_ticks=(\d+) over 2 seconds")
PROBES = 24
MIN_IDLE = 80.0
MEDIAN_IDLE = 90.0
# The archived watcher takes a 2 s probe, then waits 2 s. Its timestamps
# have whole-second precision. Allow 2 s of slack for precision and scheduling.
MAX_SAMPLE_GAP_SECONDS = 6
MAX_EDGE_PROBE_SECONDS = 4


class CoverageError(ValueError):
    pass


def sample_idle(line):
    match = IDLE.fullmatch(line)
    assert match, line
    value, idle, total = float(match[1]), int(match[2]), int(match[3])
    assert 0 <= idle <= total and total > 0 and abs(value - 100 * idle / total) <= 0.051, line
    return value


def preflight_result(text):
    values = [sample_idle(line) for line in text.splitlines()]
    minimum = min(values, default=None)
    middle = median(values) if values else None
    return {
        "probes": len(values),
        "min_idle_pct": minimum,
        "median_idle_pct": middle,
        "accepted": len(values) == PROBES and minimum >= MIN_IDLE and middle >= MEDIAN_IDLE,
    }


def aware_timestamp(text):
    value = datetime.fromisoformat(text)
    assert value.utcoffset() is not None, f"timestamp has no UTC offset: {text}"
    return value


def host_load_result(text, timeline):
    if not __debug__:
        raise RuntimeError("run host-load validation without Python optimization")
    timestamps = []
    values = []
    for line in text.splitlines():
        parts = line.split(maxsplit=1)
        assert len(parts) == 2, f"invalid host-load sample: {line}"
        timestamp, idle = parts
        timestamps.append(aware_timestamp(timestamp))
        values.append(sample_idle(idle))
    if len(timestamps) < 2:
        raise CoverageError("host-load log needs at least two samples")
    gaps = [(after - before).total_seconds() for before, after in zip(timestamps, timestamps[1:])]
    assert min(gaps) > 0, "host-load timestamps are not strictly increasing"
    longest_gap = max(gaps)
    if longest_gap > MAX_SAMPLE_GAP_SECONDS:
        raise CoverageError(f"host-load sample gap {longest_gap}s exceeds 6s")

    assert timeline, "scored timeline is empty"
    intervals = [(aware_timestamp(entry["started_at"]), aware_timestamp(entry["completed_at"])) for entry in timeline]
    assert all(start < finish for start, finish in intervals), "invalid scored interval"
    assert all(before[1] <= after[0] for before, after in zip(intervals, intervals[1:])), "scored intervals overlap"
    scored_start, scored_end = intervals[0][0], intervals[-1][1]
    start_offset = (timestamps[0] - scored_start).total_seconds()
    end_offset = (scored_end - timestamps[-1]).total_seconds()
    if not -MAX_SAMPLE_GAP_SECONDS <= start_offset <= MAX_EDGE_PROBE_SECONDS:
        raise CoverageError(f"host-load start coverage offset {start_offset}s")
    if not -MAX_EDGE_PROBE_SECONDS <= end_offset <= MAX_SAMPLE_GAP_SECONDS:
        raise CoverageError(f"host-load end coverage offset {end_offset}s")
    return {
        "status": "verified",
        "samples": len(values),
        "min_idle_pct": min(values),
        "median_idle_pct": median(values),
        "max_idle_pct": max(values),
        "max_sample_gap_seconds": longest_gap,
        "first_sample_at": timestamps[0].isoformat(),
        "last_sample_at": timestamps[-1].isoformat(),
        "first_scored_start_at": scored_start.isoformat(),
        "last_scored_completion_at": scored_end.isoformat(),
        "first_sample_seconds_after_scored_start": start_offset,
        "last_sample_seconds_before_scored_completion": end_offset,
    }

