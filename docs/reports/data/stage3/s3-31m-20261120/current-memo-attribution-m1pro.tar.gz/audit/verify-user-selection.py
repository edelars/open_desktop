#!/usr/bin/env python3
"""Reproduce the separately authorized S3-31 round 3, attempt 1 selection."""

from datetime import timedelta
from hashlib import sha256
import json
from pathlib import Path
import runpy
import subprocess
import sys


PROFILE = "current-memo-attribution"
ATTEMPT = Path(PROFILE) / "round-3/try-1"
REPORT_SHA = "38fe235739a6e1c1f731a612ca1e845841714ada11958d401bf9a63ffad611f1"
WATCHER_PARSER = Path("reference/short-windows-v1/runner-check/host_load.py")
REPLAY_RESULT = "load_rejected_retryable"
REJECTION = "timed overlap idle floor rejected: 79.0"
FLOOR_PCT = 80.0
OVERRIDE_MINIMUM_PCT = 79.0


def check(controller, support, series):
    attempt = series / ATTEMPT
    run = subprocess.run(
        [sys.executable, "-B", str(controller), "replay", str(attempt),
         "--support-kit", str(support)],
        capture_output=True,
        check=False,
    )
    replay_path = attempt.with_name("try-1.replay.json")
    assert run.returncode == int(attempt.with_name("try-1.replay.exit").read_text()) == 0
    assert run.stdout == replay_path.read_bytes()
    assert run.stderr == attempt.with_name("try-1.replay.stderr").read_bytes() == b""
    assert int(attempt.with_name("try-1.run.exit").read_text()) == 75
    assert json.loads(run.stdout) == {
        "status": "replay_passed",
        "derived_result": REPLAY_RESULT,
        "process_run": 3,
        "report_sha256": REPORT_SHA,
    }
    receipt = json.loads((attempt / "receipt.json").read_bytes())
    assert receipt["result"] == REPLAY_RESULT
    assert receipt["mode"] == "timed" and receipt["process_run"] == 3
    assert receipt["report_sha256"] == REPORT_SHA
    assert receipt["host_load"] == {"status": "rejected", "reason": REJECTION}
    assert receipt["host_preflight"]["accepted"] is True
    assert receipt["watcher_completion"] == {"exit_code": 0}
    failure = json.loads((attempt / "failure.json").read_bytes())
    assert failure == {"kind": "HostLoadRejected", "message": REJECTION, "result": REPLAY_RESULT}
    timeline = receipt["timeline"]
    assert timeline["scheduling_pid_verified"] is True
    assert timeline["returncode"] == 0 and timeline["effective_nice"] == -5
    assert timeline["uid"] == json.loads((attempt / "pins.json").read_bytes())["m1_uid"]
    assert sha256((attempt / "report.json").read_bytes()).hexdigest() == REPORT_SHA

    # The approved parser verifies timestamp order, gaps, coverage edges, and
    # each recorded value against its exact idle/total tick counts.
    watcher_log = (attempt / "host-load.log").read_text()
    approved = runpy.run_path(str(support / WATCHER_PARSER))
    coverage = approved["host_load_result"](watcher_log, [timeline])
    assert coverage["status"] == "verified"
    aware = approved["aware_timestamp"]
    sample_idle = approved["sample_idle"]
    start, end = (aware(timeline[key]) for key in ("started_at", "completed_at"))
    samples = [(aware(stamp), sample_idle(sample))
               for stamp, sample in (line.split(maxsplit=1) for line in watcher_log.splitlines())]
    overlap = [(stamp, idle) for stamp, idle in samples
               if stamp + timedelta(seconds=1) > start and stamp - timedelta(seconds=2) < end]
    minimum = min(idle for _, idle in overlap)
    assert minimum == OVERRIDE_MINIMUM_PCT
    below = [{"sample_at": stamp.isoformat(), "idle_pct": idle}
             for stamp, idle in overlap if idle < FLOOR_PCT]
    return {
        "schema": 1,
        "decision": "included_by_explicit_user_override",
        "user_direction": "The user explicitly directed accepting this attempt after the automatic load rejection.",
        "attempt": f"raw/series/{ATTEMPT.as_posix()}",
        "scope": "Timed overlap CPU-idle floor for this attempt only.",
        "automated_result": REPLAY_RESULT,
        "automated_rejection": REJECTION,
        "timed_overlap_required_minimum_pct": FLOOR_PCT,
        "timed_overlap_observed_minimum_pct": minimum,
        "timed_overlap_sample_count": len(overlap),
        "timed_overlap_below_floor_count": len(below),
        "timed_overlap_below_floor": below,
        "watcher_coverage": coverage,
        "file_sha256": {
            name: sha256(path.read_bytes()).hexdigest()
            for name, path in {
                "report.json": attempt / "report.json",
                "receipt.json": attempt / "receipt.json",
                "failure.json": attempt / "failure.json",
                "host-load.log": attempt / "host-load.log",
                "try-1.replay.json": replay_path,
                "approved_host_load.py": support / WATCHER_PARSER,
            }.items()
        },
    }


if __name__ == "__main__":
    if not __debug__:
        raise SystemExit("enable assertions for replay")
    print(json.dumps(check(*(Path(arg) for arg in sys.argv[1:])), indent=2, sort_keys=True))
