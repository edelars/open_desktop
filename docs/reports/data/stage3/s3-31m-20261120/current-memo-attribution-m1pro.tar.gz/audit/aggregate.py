#!/usr/bin/env python3
"""Summarize three controller-selected S3-31 current-memo V2 reports."""

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
import math
from pathlib import Path


PAIR_COUNT = 20
SIDE_FLOOR_NS = 200_000_000
ACTIVE_PHASES = (
    "block_build_and_admission",
    "key_snapshot_and_initial_lookup",
    "host_execution_boundary",
)
INACTIVE_PHASES = (
    "ir_lowering",
    "allocation",
    "emission_and_finalization",
    "publication",
)
MEMO_PHASE = "continuation_memo_resolution"
RESIDUAL = "unattributed_residual"
OBSERVED_ONLY_FIELDS = (
    MEMO_PHASE,
    "key_lookup_count",
    "memo_resolved_count",
    "attributed_phase_ns",
    "unattributed_residual_ns",
)
CACHE_FIELDS = (
    "hits",
    "misses",
    "successful_compiles",
    "successful_publications",
    "evictions",
)


@dataclass(frozen=True)
class FixtureWork:
    native: int
    retired: int
    key_lookups: int
    memo_resolved: int

    def side_counts(self, calls):
        return {
            "dispatch_calls": calls,
            "retired_guest_instructions": calls * self.retired,
            "native_block_executions": calls * self.native,
            "cache_delta": {
                "hits": calls * self.native,
                "misses": 0,
                "successful_compiles": 0,
                "successful_publications": 0,
                "evictions": 0,
            },
        }

    def observed_counts(self, calls):
        return {
            "key_lookup_count": calls * self.key_lookups,
            "memo_resolved_count": calls * self.memo_resolved,
            "continuation_memo_resolution_calls": calls * (self.native - 1),
        }


FIXTURES = {
    "same_4096": FixtureWork(native=4096, retired=8192, key_lookups=1, memo_resolved=4095),
    "two_64": FixtureWork(native=127, retired=191, key_lookups=2, memo_resolved=125),
    "two_4096": FixtureWork(native=8191, retired=12287, key_lookups=2, memo_resolved=8189),
    "three_64": FixtureWork(native=190, retired=254, key_lookups=190, memo_resolved=0),
}


@dataclass(frozen=True)
class Pair:
    dispatch_calls: int
    ordinary_ns: int
    observed_ns: int
    observed_phase_ns: dict


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(record, key, minimum=0):
    value = record[key]
    require(type(value) is int and value >= minimum, f"{key} must be an integer >= {minimum}")
    return value


def unique_object(items):
    result = {}
    for key, value in items:
        require(key not in result, f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError(f"invalid JSON constant {value}")


def side_time(side, work, calls):
    expected = work.side_counts(calls)
    for field in ("dispatch_calls", "retired_guest_instructions", "native_block_executions"):
        require(integer(side, field) == expected[field], f"{field} differs from expected work")
    for field in CACHE_FIELDS:
        require(
            integer(side["cache_delta"], field) == expected["cache_delta"][field],
            f"cache_delta.{field} differs from expected work",
        )
    return integer(side, "dispatch_call_elapsed_ns", SIDE_FLOOR_NS)


def observed_phases(side, work, calls, elapsed_ns):
    counts = work.observed_counts(calls)
    for field in ("key_lookup_count", "memo_resolved_count"):
        require(integer(side, field) == counts[field], f"{field} differs from expected work")

    phases = unique_object((item["phase"], item) for item in side["phase_totals"])
    require(set(phases) == set(ACTIVE_PHASES + INACTIVE_PHASES), "unexpected phase_totals names")
    elapsed = {}
    for name in ACTIVE_PHASES:
        phase = phases[name]
        require(integer(phase, "calls") == work.native * calls, f"{name} call count differs")
        elapsed[name] = integer(phase, "elapsed_ns")
    for name in INACTIVE_PHASES:
        phase = phases[name]
        require(
            integer(phase, "calls") == 0 and integer(phase, "elapsed_ns") == 0,
            f"{name} must be zero",
        )
        elapsed[name] = 0

    memo = side[MEMO_PHASE]
    require(
        integer(memo, "calls") == counts["continuation_memo_resolution_calls"],
        "continuation memo resolution call count differs",
    )
    elapsed[MEMO_PHASE] = integer(memo, "elapsed_ns")
    attributed = integer(side, "attributed_phase_ns")
    residual = integer(side, "unattributed_residual_ns")
    require(attributed == sum(elapsed.values()), "attributed phase total does not reconcile")
    require(attributed + residual == elapsed_ns, "observed residual does not reconcile")
    elapsed[RESIDUAL] = residual
    return elapsed


def parse_pair(record, work, sweeps, pair_number):
    require(integer(record, "pair") == pair_number, "pair index differs from its position")
    require(integer(record, "sweeps_per_side") == sweeps, "pair sweep count differs from stratum")
    ordinary, observed = record["ordinary"], record["observed"]
    require(ordinary["phase_totals"] == [], "ordinary phase_totals must be an empty list")
    require(
        not any(field in ordinary for field in OBSERVED_ONLY_FIELDS),
        "ordinary side has observer data",
    )
    ordinary_ns = side_time(ordinary, work, sweeps)
    observed_ns = side_time(observed, work, sweeps)
    ratio = record["ratio_observed_over_ordinary"]
    require(
        type(ratio) in (int, float) and math.isclose(ratio, observed_ns / ordinary_ns, rel_tol=1e-12),
        "reported paired time ratio does not reconcile",
    )
    return Pair(sweeps, ordinary_ns, observed_ns, observed_phases(observed, work, sweeps, observed_ns))


def load_run(path, run_number):
    raw = path.read_bytes()
    data = json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_constant)
    require(
        integer(data, "schema") == 1 and data["profile"] == "current-memo-attribution",
        "unexpected schema or profile",
    )
    require(integer(data, "process_run") == run_number, f"expected process_run {run_number}")
    require(
        data["timing_started"] is True and data["run_outcome"] == "complete",
        "expected complete timed run",
    )
    timing = data["timing_contract"]
    require(integer(timing, "measured_pairs") == PAIR_COUNT, "unexpected measured pair count")
    require(integer(timing, "minimum_side_ns") == SIDE_FLOOR_NS, "unexpected minimum side time")
    strata = unique_object((stratum["fixture"]["name"], stratum) for stratum in data["strata"])
    require(set(strata) == set(FIXTURES), "unexpected fixture set")

    pairs, fixtures = {}, {}
    for name, work in FIXTURES.items():
        stratum = strata[name]
        fixture = stratum["fixture"]
        require(
            integer(fixture, "expected_native_blocks") == work.native,
            f"{name}: unexpected native geometry",
        )
        require(
            integer(fixture, "expected_retired_instructions") == work.retired,
            f"{name}: unexpected retirement geometry",
        )
        fixtures[name] = fixture
        sweeps = integer(stratum, "common_sweeps_per_sample", minimum=1)
        records = stratum["pairs"]
        require(
            isinstance(records, list) and len(records) == PAIR_COUNT,
            f"{name}: expected {PAIR_COUNT} pairs",
        )
        pairs[name] = []
        for pair_number, record in enumerate(records, 1):
            try:
                pairs[name].append(parse_pair(record, work, sweeps, pair_number))
            except (KeyError, TypeError, ValueError, OverflowError) as error:
                raise ValueError(f"{name} pair {pair_number}: {error}") from error

    identity = {
        "source_identity": data["source_identity"],
        "binary_identity": data["binary_identity"],
        "capture_host": data["capture_host"],
        "measure_host": data["measure_host"],
        "timing_contract": timing,
        "fixture_identities": fixtures,
    }
    provenance = {"process_run": run_number, "filename": path.name, "sha256": sha256(raw).hexdigest()}
    return identity, provenance, pairs


def distribution(values):
    ordered = sorted(values)

    def percentile(fraction):
        position = (len(ordered) - 1) * fraction
        lower = math.floor(position)
        upper = math.ceil(position)
        return ordered[lower] + (position - lower) * (ordered[upper] - ordered[lower])

    return {
        "min": ordered[0],
        "p10": percentile(0.1),
        "p50": percentile(0.5),
        "p90": percentile(0.9),
        "max": ordered[-1],
    }


def summarize(pairs, work):
    calls = sum(pair.dispatch_calls for pair in pairs)
    ordinary_per_call = [pair.ordinary_ns / pair.dispatch_calls for pair in pairs]
    observed_per_call = [pair.observed_ns / pair.dispatch_calls for pair in pairs]
    return {
        "pair_count": len(pairs),
        "minimum_timed_side_ns": min(min(pair.ordinary_ns, pair.observed_ns) for pair in pairs),
        "counts_per_side_total": work.side_counts(calls),
        "observed_resolution_counts_total": work.observed_counts(calls),
        "ordinary": {
            "ns_per_dispatch_call": distribution(ordinary_per_call),
            "ns_per_native_execution": distribution(ns / work.native for ns in ordinary_per_call),
        },
        "observed": {
            "ns_per_dispatch_call": distribution(observed_per_call),
            "ns_per_native_execution": distribution(ns / work.native for ns in observed_per_call),
            "shares_percent": {
                name: distribution(
                    100 * pair.observed_phase_ns[name] / pair.observed_ns for pair in pairs
                )
                for name in ACTIVE_PHASES + INACTIVE_PHASES + (MEMO_PHASE, RESIDUAL)
            },
        },
        "observed_over_ordinary_paired_ratio": distribution(
            pair.observed_ns / pair.ordinary_ns for pair in pairs
        ),
    }


def aggregate(paths):
    reference_identity = None
    raw_runs = []
    run_pairs = []
    for run_number, path in enumerate(paths, 1):
        try:
            identity, provenance, pairs = load_run(path, run_number)
            if reference_identity is None:
                reference_identity = identity
            else:
                for key, value in reference_identity.items():
                    require(identity[key] == value, f"{key} differs from run 1")
        except (OSError, KeyError, TypeError, ValueError, OverflowError) as error:
            raise ValueError(f"{path}: {error}") from error
        raw_runs.append(provenance)
        run_pairs.append(pairs)

    strata = {}
    for name, work in FIXTURES.items():
        pooled = [pair for run in run_pairs for pair in run[name]]
        strata[name] = {
            "counts_per_dispatch_call": work.side_counts(1),
            "observed_resolution_counts_per_dispatch_call": work.observed_counts(1),
            "pooled": summarize(pooled, work),
            "per_run": [
                {"process_run": run_number, **summarize(run[name], work)}
                for run_number, run in enumerate(run_pairs, 1)
            ],
        }
    return {
        "schema": 1,
        "profile": "current-memo-attribution",
        "aggregate_script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "raw_runs": raw_runs,
        "provenance": reference_identity,
        "statistics_contract": (
            "Each summary weights pairs equally, including when runs use different sweeps per side. "
            "Percentiles linearly interpolate at (n - 1) * p in sorted values. "
            "Paired ratios are recomputed from observed and ordinary elapsed ns in the same row."
        ),
        "attribution_contract": (
            "Every phase and residual share uses its pair's observed full dispatch elapsed time. "
            "The instrumented shares cannot be subtracted from ordinary time to estimate cost or used "
            "to infer removable residual or direct-link benefit. "
            "Percentiles of individual shares need not sum to 100. "
            "Summaries are descriptive because rows within a process may be dependent."
        ),
        "strata": strata,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "runs", nargs=3, type=Path, metavar="RUN", help="selected raw JSON reports in run 1/2/3 order"
    )
    args = parser.parse_args()
    try:
        summary = aggregate(args.runs)
    except ValueError as error:
        parser.exit(1, f"error: {error}\n")
    print(json.dumps(summary, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
