"""Replay retained attempts and validate first-passing selections across relocation."""
import csv
from datetime import datetime
from itertools import groupby
import json
from pathlib import Path
import subprocess
import sys


def check(controller, support, series, remote_series):
    with (series / "schedule.tsv").open() as stream:
        table = csv.DictReader(stream, delimiter="\t")
        assert table.fieldnames == ["timestamp", "profile", "round", "attempt", "outcome"]
        rows = list(table)
    assert rows and len(rows) % 2 == 0
    times = [datetime.fromisoformat(row["timestamp"]) for row in rows]
    assert times == sorted(times)
    for start, end in zip(rows[::2], rows[1::2], strict=True):
        assert start["outcome"] == "running" and end["outcome"] != "running"
        key = ("profile", "round", "attempt")
        assert tuple(start[item] for item in key) == tuple(end[item] for item in key)

    def replay(*args):
        return subprocess.run(
            [sys.executable, "-B", str(controller), *map(str, args), "--support-kit", str(support)],
            capture_output=True, check=False,
        )

    timed = "current-memo-attribution"
    grouped = [(group, list(items)) for group, items in groupby(
        rows[1::2], key=lambda row: (row["profile"], row["round"]))]
    assert [item[0] for item in grouped] == [
        ("preflight-only", "1"), (timed, "1"), (timed, "2"), (timed, "3"),
    ]

    selected = []
    recorded_paths = []
    total = 0
    for (profile, round_index), attempts in grouped:
        if profile == "preflight-only":
            relative_parent = Path("preflight")
            expected = "preflight_passed"
        else:
            relative_parent = Path(timed) / f"round-{round_index}"
            expected = "accepted"
        parent = series / relative_parent
        assert 1 <= len(attempts) <= 4
        assert sorted(entry.name for entry in parent.iterdir() if entry.is_dir()) == [
            f"try-{i}" for i in range(1, len(attempts) + 1)
        ]
        for index, event in enumerate(attempts, 1):
            name = f"try-{index}"
            assert event["attempt"] == str(index)
            dir_path = parent / name
            result = replay("replay", dir_path)
            assert result.returncode == int((parent / f"{name}.replay.exit").read_text()) == 0
            assert result.stdout == (parent / f"{name}.replay.json").read_bytes()
            assert result.stderr == (parent / f"{name}.replay.stderr").read_bytes()
            proof = json.loads(result.stdout)
            actual = proof["derived_result"]
            assert proof["status"] == "replay_passed" and proof["process_run"] == int(round_index)
            assert actual == event["outcome"]
            run_rc = int((parent / f"{name}.run.exit").read_text())
            if index == len(attempts):
                assert actual == expected and run_rc == 0
                original = str(remote_series / relative_parent / name)
                if profile == "preflight-only":
                    assert (parent / "accepted.txt").read_text().splitlines() == [original]
                else:
                    selected.append(dir_path)
                    recorded_paths.append(original)
            else:
                assert actual == "load_rejected_retryable" and run_rc == 75
            if profile == timed:
                total += 1
    timed_dirs = [series / row["profile"] / f"round-{row['round']}" / f"try-{row['attempt']}"
                  for row in rows[1::2] if row["profile"] == timed]
    assert len(timed_dirs) == total
    assert (series / timed / "accepted.txt").read_text().splitlines() == recorded_paths
    final = replay("replay-series", *timed_dirs)
    assert final.returncode == 0 and final.stderr == (series / timed / "series.stderr").read_bytes()
    saved = json.loads((series / timed / "series.json").read_bytes())
    again = json.loads(final.stdout)
    if saved.get("selected_attempts") != again.get("selected_attempts"):
        assert saved["selected_attempts"] == recorded_paths
        assert again["selected_attempts"] == [str(path) for path in selected]
        again["selected_attempts"] = recorded_paths
    assert saved == again and again["status"] == "three_attempt_series_passed"
    print(f"Replayed all {len(rows) // 2} S3-31 attempts and the selected series.")


if __name__ == "__main__":
    if not __debug__:
        raise SystemExit("enable assertions for replay")
    check(*(Path(arg) for arg in sys.argv[1:]))
