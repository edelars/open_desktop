#!/usr/bin/env python3
"""Archive one complete, replayed S3-31 current-memo V2 capture."""

import argparse
import gzip
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import sys
import tarfile
import tempfile


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
PREP_MARKER = REPO / "work/tmp/latest-current-memo-v2-preparation-path"
SUPPORT = REPO / "work/tmp/s3-30-m1-base.uDY78ah3/allocator-runner-fifo-v1"
CONTROLLER_DIR = "work/tmp/s3-31-current-memo-controller"
SUPPORT_FILES = (
    "runner.py",
    "reference/short-windows-v1/runner-check/exec-nice.sh",
    "reference/short-windows-v1/runner-check/host_load.py",
    "reference/short-windows-v1/runner-check/host-load/cpu_idle.c",
    "reference/short-windows-v1/runner-check/host-load/watch-load.py",
)
PROFILE = "current-memo-attribution"
CONTROL_FILES = {"exit.txt", "launcher.log", "pid", "score-current-memo.zsh"}
ATTEMPT_FILES = {
    "benchmark.log", "benchmark.ps", "preflight.log", "host-load.log", "host-load.stderr",
    "m1-preflight.log", "fixture-archive.json.gz", "m1-preflight/sign.log",
    "m1-preflight/mach-o.txt", "m1-preflight/binary.sha256", "transport/exec-nice.sh",
    "finished", "mach-o.log", "codesign.log", "entitlements.plist", "host-load/cpu_idle.c",
    "host-load/cpu-idle", "host-load/watch-load.py", "failure.json", "pins.json",
    "source-binding.json", "source.patch", "m1-preflight.json", "report.json", "receipt.json",
}
ATTEMPT_DIRS = {"host-load", "transport", "m1-preflight"}
ATTEMPT_SIDE_RECORD = r"try-[1-4]\.(?:run|replay)\.(?:exit|json|stderr)"
STAGE_FILES = ("launch-current-memo.zsh", "score-current-memo.zsh", "kit.tar")
KIT_FILES = (
    "controller.py", "m1-preflight/binary.sha256", "m1-preflight/mach-o.txt",
    "m1-preflight/preflight.json", "m1-preflight/preflight.log", "m1-preflight/sign.log",
    "pins.json", "source-binding.json", "source.patch",
)
DIAGNOSTIC_CONTROLLER_SHA = "97405529bce66d540e839f22e9a5b40168daf5198477654a0936837866cd0d6a"
DIAGNOSTIC_CAPTURE_SHA = "0e7ef08585f41456081bd110f5fa3eeab83d7348141edcd94d65673278866ce0"
DIAGNOSTIC_NAMESPACE = "diagnostic-controller-v1"
DIAGNOSTIC_ATTEMPT = f"series/{PROFILE}/round-1/try-1"
AGGREGATE_SHA = "2d53e389239e8bde7e330704aac0f26c07a18a180a30ec7a0c583a109dc0d951"
AUDITOR_SHA = "a57a29bb16abfa1f131c083f7ee478ab270c3b43dcecf9055e1ace1f2031e26f"
OVERRIDE_VERIFIER_SHA = "ec38b7b6b4f2db2dcbb2f7d68b935dadec9802346fbbd67b9ed55acd511f4c56"
FIXTURE_SHA = "9f3215e110e8804b5b47d0c40b4fd967e17b5c9849451f8f7f681f120e2d4c64"
SAMPLER_SOURCE_SHA = "171dc74d1e23bb1088d29949c75a053a46df2cee775920f95483cc1f9c514645"
SAMPLER_COMMAND = (
    "MACOSX_DEPLOYMENT_TARGET=14.0 /usr/bin/clang "
    "-std=c11 -O2 -Wall -Wextra -Werror cpu_idle.c -o cpu-idle"
)
SAMPLER_REFERENCE = REPO / (
    "docs/reports/data/stage3/s3-30e-20261120/allocator-direct-entry-m1.json.gz"
)
SAMPLER_REFERENCE_SHA = "5426baf373ad9959283270572bcb2ccc7121369ff37e5998b383a93aaeb3edb7"
SAMPLER_REBUILT_SHA = "1dbdbd17602be34ddc397f872cb75068ab1c7b144b55ab40ca32da3069129089"
REBUILD_LOG = "audit/sampler-rebuild.log"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return sha256(data).hexdigest()


def read_file(path):
    require(path.is_file() and not path.is_symlink(), f"expected regular file {path}")
    return path.read_bytes()


def pinned_file(path, expected):
    data = read_file(path)
    require(digest(data) == expected, f"digest mismatch for {path}")
    return data


def accepted_kind(path):
    if path in {"control", "series", "series/preflight", f"series/{PROFILE}"}:
        return "dir"
    if path in {
        *(f"control/{name}" for name in CONTROL_FILES),
        "series/schedule.tsv", "series/preflight/accepted.txt", f"series/{PROFILE}/accepted.txt",
        f"series/{PROFILE}/series.json", f"series/{PROFILE}/series.stderr",
    }:
        return "file"
    pattern = rf"series/(?:preflight|{PROFILE}/round-[1-3])"
    if re.fullmatch(rf"series/{PROFILE}/round-[1-3]", path):
        return "dir"
    if re.fullmatch(rf"{pattern}/{ATTEMPT_SIDE_RECORD}", path):
        return "file"
    attempt = re.fullmatch(rf"{pattern}/try-[1-4](?:/(.*))?", path)
    if attempt:
        child = attempt[1]
        if child is None or child in ATTEMPT_DIRS:
            return "dir"
        if child in ATTEMPT_FILES:
            return "file"
    return None


def validate_apple_double(data, name):
    header = struct.Struct(">II16xH")
    entry = struct.Struct(">III")
    require(len(data) >= header.size, f"truncated AppleDouble header {name}")
    magic, version, count = header.unpack_from(data)
    require((magic, version) == (0x00051607, 0x00020000), f"invalid AppleDouble header {name}")
    entries_end = header.size + count * entry.size
    require(count > 0 and entries_end <= len(data), f"invalid AppleDouble entry table {name}")
    sections = []
    identifiers = set()
    for identifier, offset, length in entry.iter_unpack(data[header.size:entries_end]):
        require(identifier not in identifiers, f"duplicate AppleDouble entry {name}")
        require(entries_end <= offset <= offset + length <= len(data),
                f"AppleDouble entry outside payload {name}")
        identifiers.add(identifier)
        sections.append((offset, offset + length))
    section_end = entries_end
    for start, end in sorted(sections):
        require(start >= section_end, f"overlapping AppleDouble entries {name}")
        section_end = end


def read_capture(raw, upstream, expected_exit=b"0\n"):
    files, dirs, apple_double = {}, set(), {}
    with tarfile.open(fileobj=BytesIO(upstream), mode="r:gz") as capture:
        for member in capture:
            name = member.name.removeprefix("./").rstrip("/")
            path = PurePosixPath(name)
            if path.name.startswith("._"):
                require(member.isfile() and member.size <= 65536,
                        f"invalid AppleDouble sidecar {name}")
                require(name not in apple_double, f"duplicate AppleDouble sidecar {name}")
                sidecar = capture.extractfile(member).read()
                validate_apple_double(sidecar, name)
                apple_double[name] = digest(sidecar)
                continue
            kind = accepted_kind(name)
            require(kind is not None, f"unexpected upstream archive path {member.name}")
            require(name not in files and name not in dirs, f"duplicate upstream archive path {name}")
            if kind == "dir":
                require(member.isdir(), f"expected upstream directory {name}")
                dirs.add(name)
            else:
                require(member.isfile(), f"expected regular upstream file {name}")
                files[name] = capture.extractfile(member).read()
    known = files.keys() | dirs
    for name in apple_double:
        path = PurePosixPath(name)
        require(str(path.with_name(path.name[2:])) in known, f"orphaned AppleDouble sidecar {name}")
    local_files, local_dirs = set(), set()
    for path in raw.rglob("*"):
        name = path.relative_to(raw).as_posix()
        require(not path.is_symlink(), f"unexpected local symlink {name}")
        if name in apple_double:
            require(digest(read_file(path)) == apple_double[name], f"local AppleDouble differs: {name}")
            continue
        if path.is_dir():
            local_dirs.add(name)
        else:
            local_files.add(name)
    require(local_files == files.keys() and local_dirs == dirs, "local raw tree differs from upstream")
    for name, data in files.items():
        require(read_file(raw / name) == data, f"local raw bytes differ from upstream for {name}")
    require(files.get("control/exit.txt") == expected_exit, "unexpected score launcher exit")
    return files, dirs, apple_double


def select_reports(files):
    accepted = files[f"series/{PROFILE}/accepted.txt"].decode().splitlines()
    require(len(accepted) == 3, "expected three selected timed attempts")
    remote_series = None
    reports = []
    for run, recorded in enumerate(accepted, 1):
        path = PurePosixPath(recorded)
        require(path.is_absolute() and ".." not in path.parts, f"invalid selected path {recorded}")
        require(
            path.parent.name == f"round-{run}"
            and path.parent.parent.name == PROFILE
            and re.fullmatch(r"try-[1-4]", path.name),
            f"selected path has the wrong run or attempt: {recorded}",
        )
        root = path.parents[2]
        require(root.name == "series", f"selected path has no series root: {recorded}")
        require(remote_series in (None, root), "selected attempts use different remote series roots")
        remote_series = root
        relative = Path("series") / Path(str(path.relative_to(root)))
        report = (relative / "report.json").as_posix()
        require(report in files, f"selected report is missing: {report}")
        reports.append(report)
    return remote_series, reports


def sampler_reference():
    archive = json.loads(gzip.decompress(pinned_file(SAMPLER_REFERENCE, SAMPLER_REFERENCE_SHA)))
    log = archive["files"][REBUILD_LOG].encode()
    source = archive["files"][f"kit/{SUPPORT_FILES[3]}"].encode()
    require(digest(source) == SAMPLER_SOURCE_SHA, "prior rebuild used a different sampler source")
    require(digest(log) == archive["file_sha256"][REBUILD_LOG], "prior rebuild receipt digest mismatch")
    require(
        f"recreated_sampler_sha256={SAMPLER_REBUILT_SHA}".encode() in log.splitlines()
        and set(archive["omitted_reproducible_sampler_sha256"].values()) == {SAMPLER_REBUILT_SHA},
        "prior rebuild and captured sampler digests differ",
    )
    return log


def omit_samplers(files, archive_root="raw", attempt_without_receipt=None):
    omitted = {}
    for name in sorted(files):
        data = files[name]
        if name.endswith("/host-load/cpu-idle"):
            attempt = name.removesuffix("/host-load/cpu-idle")
            expected = digest(data)
            receipt_path = f"{attempt}/receipt.json"
            if attempt == attempt_without_receipt:
                require(receipt_path not in files, f"unexpected receipt for diagnostic attempt {attempt}")
            else:
                receipt = json.loads(files[receipt_path])
                require(expected == receipt["file_sha256"]["host-load/cpu-idle"],
                        f"sampler digest differs from the capture receipt: {name}")
            require(expected == SAMPLER_REBUILT_SHA, f"sampler requires a new matching toolchain rebuild: {name}")
            require(
                digest(files[f"{attempt}/host-load/cpu_idle.c"]) == SAMPLER_SOURCE_SHA,
                f"sampler source pin changed: {name}",
            )
            omitted[f"{archive_root}/{name}"] = expected
        elif name.endswith("/fixture-archive.json.gz"):
            require(digest(data) == FIXTURE_SHA, f"fixture archive pin changed: {name}")
        else:
            require(b"\0" not in data, f"unexpected binary file: {name}")
            data.decode("utf-8")
    require(omitted, "capture has no retained sampler binaries")
    return omitted


def verify_manifest(files, names, manifest):
    expected = "".join(f"{digest(files[name])}  {name}\n" for name in sorted(names))
    require(files[manifest] == expected.encode(), f"files do not match {manifest}")


def archived_stage(stage_path, controller_sha):
    stage = {name: read_file(stage_path / name) for name in (*STAGE_FILES, "stage.sha256")}
    verify_manifest(stage, STAGE_FILES, "stage.sha256")
    require(digest(stage["launch-current-memo.zsh"]) ==
            "7d06b7adeef9dca5f4bfe30d8edb4c756fdb6bcc656c29fe13bb43434c68c149",
            "scoring launcher digest changed")
    require(digest(stage["score-current-memo.zsh"]) ==
            "14aef42c4a66d68350fba02efb037fd07556330cbde0c3e1e15a269d20ef95b2",
            "scoring schedule script digest changed")
    files = {f"stage/{name}": data for name, data in stage.items()}
    kit = {name: read_file(stage_path / "kit" / name) for name in (*KIT_FILES, "controller.sha256")}
    verify_manifest(kit, KIT_FILES, "controller.sha256")
    require(digest(kit["controller.py"]) == controller_sha, "approved controller digest changed")
    with tarfile.open(fileobj=BytesIO(stage["kit.tar"]), mode="r:") as archive:
        members = archive.getmembers()
        require(
            sorted(item.name for item in members) == sorted(kit),
            "stage kit tar member set differs",
        )
        for item in members:
            require(item.isfile() and archive.extractfile(item).read() == kit[item.name],
                    f"stage kit bytes differ: {item.name}")
    files.update({f"kit/{name}": data for name, data in kit.items()})
    return files


def archive_capture(capture, stage, prefix="", attempt_without_receipt=None):
    require(stage["stage/score-current-memo.zsh"] == capture["control/score-current-memo.zsh"],
            "captured scorer differs from the approved stage")
    archive_root = f"{prefix}raw"
    omitted = omit_samplers(capture, archive_root, attempt_without_receipt)
    files = {f"{archive_root}/{name}": data for name, data in capture.items()
             if f"{archive_root}/{name}" not in omitted}
    files.update({f"{prefix}{name}": data for name, data in stage.items()})
    return files, omitted


def archive_diagnostic(prep):
    score = prep / f"m1-score-{DIAGNOSTIC_NAMESPACE}"
    upstream = pinned_file(score / "score-m1.tar.gz", DIAGNOSTIC_CAPTURE_SHA)
    capture, dirs, apple_double = read_capture(score / "raw", upstream, expected_exit=b"1\n")
    diagnostic_stage = archived_stage(prep / f"score-package-{DIAGNOSTIC_NAMESPACE}", DIAGNOSTIC_CONTROLLER_SHA)
    report = f"{DIAGNOSTIC_ATTEMPT}/report.json"
    require(json.loads(capture[report])["run_outcome"] == "complete", "diagnostic raw report was incomplete")
    require(capture[f"series/{PROFILE}/accepted.txt"] == b"", "diagnostic unexpectedly has selections")
    prefix = f"{DIAGNOSTIC_NAMESPACE}/"
    files, omitted = archive_capture(capture, diagnostic_stage, prefix, DIAGNOSTIC_ATTEMPT)
    metadata = {
        "status": "excluded_from_scoring",
        "reason": (
            "The original controller failed its observed-phase schema assertion, leaving no timed "
            "attempt receipt. The retained watcher also recorded CPU idle below the score floor."
        ),
        "upstream_m1_tar_sha256": digest(upstream),
        "upstream_appledouble_sha256": apple_double,
        "controller_sha256": DIAGNOSTIC_CONTROLLER_SHA,
        "native_report": f"{prefix}raw/{report}",
    }
    return files, omitted, {f"{prefix}raw/{name}" for name in dirs}, metadata


def capture_stdout(*argv):
    run = subprocess.run([sys.executable, "-B", *map(str, argv)], capture_output=True, check=False)
    require(run.returncode == 0 and not run.stderr,
            f"{argv[0]} failed ({run.returncode}): {run.stderr.decode(errors='replace')}")
    return run.stdout


def replay_archive(auditor, remote_series, local_series, files, override_verifier):
    with tempfile.TemporaryDirectory(prefix="s3-31-replay-") as temporary:
        root = Path(temporary).resolve()
        controller = root / CONTROLLER_DIR / "controller.py"
        controller.parent.mkdir(parents=True)
        controller.write_bytes(files["kit/controller.py"])
        support = root / SUPPORT.relative_to(REPO)
        for name in SUPPORT_FILES:
            asset = support / name
            asset.parent.mkdir(parents=True, exist_ok=True)
            asset.write_bytes(files[f"support/{name}"])
        replay = capture_stdout(auditor, controller, support, local_series, remote_series)
        override = (capture_stdout(override_verifier, controller, support, local_series)
                    if override_verifier else None)
        return replay, override


def write_archive(output, files, dirs):
    all_dirs = dirs | {str(parent) for name in files for parent in PurePosixPath(name).parents
                       if parent != PurePosixPath(".")}
    with tempfile.NamedTemporaryFile(dir=output.parent) as temp:
        with gzip.GzipFile(filename="", mode="wb", fileobj=temp, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as result:
                for name in sorted(all_dirs | files.keys()):
                    member = tarfile.TarInfo(name)
                    if name in all_dirs:
                        member.type = tarfile.DIRTYPE
                        member.mode = 0o755
                        result.addfile(member)
                    else:
                        data = files[name]
                        member.mode = 0o644
                        member.size = len(data)
                        result.addfile(member, BytesIO(data))
        temp.flush()
        os.link(temp.name, output)


def pack(prep, output, controller_sha, include_diagnostic=False, accept_user_override=False):
    score = prep / "m1-score"
    raw = score / "raw"
    upstream = read_file(score / "score-m1.tar.gz")
    capture, capture_dirs, apple_double = read_capture(raw, upstream)
    remote_series, automated_reports = select_reports(capture)
    stage = archived_stage(prep / "score-package", controller_sha)
    files, omitted = archive_capture(capture, stage)
    dirs = {f"raw/{name}" for name in capture_dirs}
    files.update({f"support/{name}": read_file(SUPPORT / name) for name in SUPPORT_FILES})
    files["README.md"] = read_file(HERE / "REPLAY.md")
    files["audit/pack-evidence.py"] = read_file(Path(__file__).resolve())
    auditor = prep / "verify-series-record.py"
    aggregator = HERE / "aggregate.py"
    files["audit/verify-series-record.py"] = pinned_file(auditor, AUDITOR_SHA)
    files["audit/aggregate.py"] = pinned_file(aggregator, AGGREGATE_SHA)
    files["audit/sampler-rebuild-reference.log"] = sampler_reference()
    override_verifier = HERE / "verify-user-selection.py" if accept_user_override else None
    if override_verifier is not None:
        files["audit/verify-user-selection.py"] = pinned_file(override_verifier, OVERRIDE_VERIFIER_SHA)
    replay, override = replay_archive(auditor, remote_series, raw / "series", files, override_verifier)
    files["audit/replay.log"] = replay
    reports = automated_reports
    if override is not None:
        files["audit/user-override.json"] = override
        files["audit/automated-summary.json"] = capture_stdout(
            aggregator, *(raw / name for name in automated_reports)
        )
        require(automated_reports[:2] == [
            f"series/{PROFILE}/round-{index}/try-1/report.json" for index in (1, 2)
        ], "user override requires the original round 1 and round 2 selections")
        manual_report = f"series/{PROFILE}/round-3/try-1/report.json"
        require(automated_reports[2] != manual_report, "user override attempt was already accepted")
        reports = [*automated_reports[:2], manual_report]
    files["audit/summary.json"] = capture_stdout(aggregator, *(raw / name for name in reports))
    manifest = {
        "schema": 1,
        "format": "s3-31-current-memo-v2-evidence",
        "upstream_m1_tar_sha256": digest(upstream),
        "upstream_appledouble_sha256": apple_double,
        "controller_sha256": controller_sha,
        "original_remote_series": str(remote_series),
        "selected_reports": [f"raw/{name}" for name in reports],
        "selection_status": "user_override_for_round_3_try_1" if override is not None else "automated",
        "automated_selected_reports": [f"raw/{name}" for name in automated_reports],
        "sampler_rebuild": {
            "command": SAMPLER_COMMAND,
            "source_sha256": SAMPLER_SOURCE_SHA,
            "prior_rebuild_archive": SAMPLER_REFERENCE.relative_to(REPO).as_posix(),
            "prior_rebuild_archive_sha256": SAMPLER_REFERENCE_SHA,
        },
    }
    if include_diagnostic:
        extra_files, extra_omitted, extra_dirs, metadata = archive_diagnostic(prep)
        files.update(extra_files)
        omitted.update(extra_omitted)
        dirs.update(extra_dirs)
        manifest["diagnostic_controller_v1"] = metadata
    manifest["file_sha256"] = {name: digest(data) for name, data in sorted(files.items())}
    manifest["omitted_reproducible_sampler_sha256"] = omitted
    files["manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    write_archive(output, files, dirs)
    return len(files), len(omitted)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new evidence .tar.gz file")
    parser.add_argument("--controller-sha256", required=True, help="approved corrected stage controller digest")
    parser.add_argument("--include-diagnostic", action="store_true", help="retain the separate unscored first capture")
    parser.add_argument("--accept-user-override", action="store_true",
                        help="apply the recorded user exception to round 3, try 1 only")
    parser.add_argument("--prep-root", type=Path, help="preparation root, defaults to the V2 path marker")
    args = parser.parse_args()
    try:
        controller_sha = args.controller_sha256
        require(re.fullmatch(r"[0-9a-f]{64}", controller_sha) and controller_sha != DIAGNOSTIC_CONTROLLER_SHA,
                "specify an independently approved corrected controller SHA-256")
        prep = args.prep_root or Path(PREP_MARKER.read_text().strip())
        count, omitted = pack(prep.resolve(), args.output, controller_sha, args.include_diagnostic,
                              args.accept_user_override)
        print(f"{digest(read_file(args.output))}  {args.output}")
        print(f"Archived {count} files and recorded {omitted} reproducible sampler omissions.")
    except (KeyError, OSError, ValueError, tarfile.TarError) as error:
        parser.exit(1, f"error: {error}\n")


if __name__ == "__main__":
    main()
