#!/bin/zsh
set -euo pipefail
umask 077
unsetopt BG_NICE
export LC_ALL=C LANG=C

stage=$1
candidate=$2
stock=$3
output_root=$4
expected_binary_sha=$5
control_dir="$output_root/control"
source_root="$candidate/source"
binary="$candidate/od-bench"
controller_dir="$stock/.git/benchmarks/s3-31-current-memo-controller"
support_kit="$stock/.git/benchmarks/s3-30-m1-base.uDY78ah3/allocator-runner-fifo-v1"

test "$(cat "$candidate/control/exit.txt")" = 0
test "$(git -C "$stock" rev-parse HEAD)" = eb314737664ad1dd40297db4b92e8e1a9de4b6ea
test -z "$(git -C "$stock" status --porcelain --untracked-files=all)"
test -f "$support_kit/runner.py"
test ! -e "$controller_dir"
test ! -e "$output_root"
test "$(shasum -a 256 "$binary" | awk '{print $1}')" = "$expected_binary_sha"
(cd "$stage"; shasum -a 256 -c stage.sha256)
mkdir -m 700 "$controller_dir" "$output_root" "$control_dir"
/usr/bin/tar -xf "$stage/kit.tar" -C "$controller_dir"
(cd "$controller_dir"; shasum -a 256 -c controller.sha256)
test -z "$(git -C "$stock" status --porcelain --untracked-files=all)"
cp "$stage/score-current-memo.zsh" "$control_dir/"
live=$(/bin/ps -Ao command= | /usr/bin/awk '$0 !~ /awk/ && (/\/od-bench [a-z]/ || /cargo build.*od-bench/) {print}')
[[ -z "$live" ]] || { print -ru2 -- "$live"; exit 1; }
cd "$stock"
/usr/bin/nohup /usr/bin/caffeinate -i -s /bin/zsh -c '
set -euo pipefail
unsetopt BG_NICE
control_dir=$1
shift
record_exit() {
    local result=$?
    print -r -- "$result" > "$control_dir/exit.tmp"
    /bin/mv "$control_dir/exit.tmp" "$control_dir/exit.txt"
    sleep 45
}
trap record_exit EXIT
/bin/zsh "$control_dir/score-current-memo.zsh" "$@"
' -- "$control_dir" "$controller_dir/controller.py" "$support_kit" "$controller_dir/pins.json" "$source_root" "$binary" "$output_root/series" \
  </dev/null > "$control_dir/launcher.log" 2>&1 &
print -r -- "$!" > "$control_dir/pid"
print -r -- "m1_s3_31_current_memo_controller_pid=$!"
