#!/bin/zsh
set -euo pipefail
controller=$1
support_kit=$2
pins=$3
source_root=$4
binary=$5
out=$6
mkdir -m 700 "$out" "$out/preflight" "$out/current-memo-attribution"
ledger="$out/schedule.tsv"
printf '%s\t%s\t%s\t%s\t%s\n' timestamp profile round attempt outcome > "$ledger"

record() {
    printf '%s\t%s\t%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$1" "$2" "$3" "$4" >> "$ledger"
}

run_and_replay() {
    local mode=$1 round=$2 attempt=$3 attempt_dir=$4
    local -a args
    args=(run --pins-json "$pins" --source-root "$source_root" --binary "$binary" --output "$attempt_dir" --process-run "$round" --support-kit "$support_kit")
    if [[ "$mode" == preflight-only ]]; then
        args+=(--preflight-only)
    fi
    record "$mode" "$round" "$attempt" running
    local run_rc=0 replay_rc=0
    python3 -B "$controller" "${args[@]}" > "$attempt_dir.run.json" 2> "$attempt_dir.run.stderr" || run_rc=$?
    printf '%s\n' "$run_rc" > "$attempt_dir.run.exit"
    [[ -f "$attempt_dir/receipt.json" ]] || return 1
    python3 -B "$controller" replay "$attempt_dir" --support-kit "$support_kit" \
        > "$attempt_dir.replay.json" 2> "$attempt_dir.replay.stderr" || replay_rc=$?
    printf '%s\n' "$replay_rc" > "$attempt_dir.replay.exit"
    python3 -B - "$attempt_dir" "$mode" "$round" "$run_rc" "$replay_rc" <<'PY'
import json
from pathlib import Path
import sys

stem, mode, round_index, run_rc, replay_rc = sys.argv[1:]
round_index, run_rc, replay_rc = map(int, (round_index, run_rc, replay_rc))
assert replay_rc == 0 and run_rc in (0, 2, 75), (run_rc, replay_rc)
run = json.loads(Path(f"{stem}.run.json").read_bytes())
replay = json.loads(Path(f"{stem}.replay.json").read_bytes())
assert run["process_run"] == replay["process_run"] == round_index
assert run["profile"] == "current-memo-attribution"
assert run["mode"] == ("preflight-only" if mode == "preflight-only" else "timed")
assert replay["status"] == "replay_passed"
result = replay["derived_result"]
assert run["result"] == result
success = "preflight_passed" if mode == "preflight-only" else "accepted"
expected = {success: 0, "load_rejected_retryable": 75, "failed_nonretryable": 2}
assert result in expected and run_rc == expected[result]
print(result)
PY
}

readiness=''
for attempt in 1 2 3 4; do
    trial="$out/preflight/try-$attempt"
    outcome=$(run_and_replay preflight-only 1 "$attempt" "$trial")
    record preflight-only 1 "$attempt" "$outcome"
    case "$outcome" in
        preflight_passed)
            readiness="$trial"
            break
            ;;
        load_rejected_retryable) ;;
        *) exit 2 ;;
    esac
done
[[ -n "$readiness" ]] || exit 3
printf '%s\n' "$readiness" > "$out/preflight/accepted.txt"

mode=current-memo-attribution
all_runs=()
accepted_file="$out/$mode/accepted.txt"
: > "$accepted_file"
for round in 1 2 3; do
    mkdir -m 700 "$out/$mode/round-$round"
    picked=false
    for attempt in 1 2 3 4; do
        trial="$out/$mode/round-$round/try-$attempt"
        all_runs+=("$trial")
        outcome=$(run_and_replay "$mode" "$round" "$attempt" "$trial")
        record "$mode" "$round" "$attempt" "$outcome"
        case "$outcome" in
            accepted)
                printf '%s\n' "$trial" >> "$accepted_file"
                picked=true
                break
                ;;
            load_rejected_retryable) ;;
            *) exit 2 ;;
        esac
    done
    [[ "$picked" == true ]] || exit 3
done
python3 -B "$controller" replay-series "${all_runs[@]}" --support-kit "$support_kit" \
    > "$out/$mode/series.json" 2> "$out/$mode/series.stderr"
