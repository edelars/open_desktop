#!/bin/sh
set -eu
expected_uid=$1
shift
identity=$(/bin/ps -p "$$" -o pid= -o uid= -o nice= |
    /usr/bin/awk -v pid="$$" -v uid="$expected_uid" \
        'NF == 3 && $1 == pid && $2 == uid && $2 > 0 && $3 == -5 { print $1, $2, $3 }')
[ -n "$identity" ]
printf 'stock_exec_pid_uid_nice=%s\n' "$identity"
exec "$@"
