from datetime import UTC, datetime
from pathlib import Path
import subprocess
import sys
import time

probe = Path(__file__).resolve().parent / "cpu-idle"
finished = Path(sys.argv[1])
while not finished.exists():
    sample = subprocess.check_output([str(probe)], text=True, timeout=8).strip()
    print(datetime.now(UTC).isoformat(timespec="seconds"), sample, flush=True)
    for _ in range(2):
        if finished.exists():
            break
        time.sleep(1)
