#!/usr/bin/env python3
"""Thin S3-31 M1 host-load controller and offline replay adapter.

The process, CPU-idle and timed-load transports are imported from the approved
S3-30 runner. This adapter binds them to the current-memo attribution report.
It writes only beneath the selected ignored work/tmp output directory.
"""
from __future__ import annotations

import argparse
from datetime import UTC, datetime, timedelta
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import plistlib
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback
from typing import Any

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
KIT = REPO / "work/tmp/s3-30-m1-base.uDY78ah3/allocator-runner-fifo-v1"
RUNNER_PATH = KIT / "runner.py"
RUNNER_SHA256 = "381053a3f49d70b383706d82e18e97feabf28bb305f66fafc687ef870dcfebf0"
NICE_SHIM = KIT / "reference/short-windows-v1/runner-check/exec-nice.sh"
NICE_SHIM_SHA256 = "2a8adfa7c8dacc4be3a1b6733418e3d00921cf27352f1e7315296135f73037e8"
HOST_LOAD_PY = KIT / "reference/short-windows-v1/runner-check/host_load.py"
HOST_LOAD_PY_SHA256 = "236e3ab30ea10964ef936663b07cb8fa11ed072a1c21eafc0d1899d28e2bb3c3"
WATCH_LOAD_PY = KIT / "reference/short-windows-v1/runner-check/host-load/watch-load.py"
WATCH_LOAD_PY_SHA256 = "47251432ef87ab530b82cab47c3dd12f1274180e1311b59a3fb73c20d698274b"
CPU_IDLE_C = KIT / "reference/short-windows-v1/runner-check/host-load/cpu_idle.c"
CPU_IDLE_C_SHA256 = "171dc74d1e23bb1088d29949c75a053a46df2cee775920f95483cc1f9c514645"
FIXTURES = ("same_4096", "two_64", "two_4096", "three_64")
PROFILE = "current-memo-attribution"
MIN_SIDE_NS = 200_000_000
TARGET_SIDE_NS = 400_000_000
FIXTURE_ARCHIVE_SHA256 = "9f3215e110e8804b5b47d0c40b4fd967e17b5c9849451f8f7f681f120e2d4c64"
SOURCE_PATCH_SHA256 = "9475473792d5d7ddabff7cf8508b3d0fc3e9cf0937a6d83481ed0e6a602eb192"
SOURCE_BINDING_SHA256 = "166e7ef260c074b9c6a8ff41a8f214a11c0b160c5ca8a9452b1164b7622a1d49"
M1_BINARY_SHA256 = "49ffac86ac074508c22a94bbf975cedee8fb9985621ad17020e79451a2b320fc"
M1_PREFLIGHT_SHA256 = "1bc5a4f5826d31078a2ddfa01c7f10b01e65e5c56f390dbba407724aa4248133"
M1_PREFLIGHT_LOG_SHA256 = "3c002e80aa23654e9b312af12497ce1c17a96caa24f79d0188c5bfccacd1294f"
M1_PREFLIGHT_PID = 3072
BASE_TREE_SHA256 = "d2dc41843da0bb2f409f04bb4d87bf9dbd9a7f86"
RUNNER: Any = None


def set_support_kit(path: Path | None) -> None:
    """Select one of the two approved local locations; never follow a symlink."""
    global KIT, RUNNER_PATH, NICE_SHIM, HOST_LOAD_PY, WATCH_LOAD_PY, CPU_IDLE_C, RUNNER
    if path is None:
        candidate = KIT
        alternate = REPO / ".git/benchmarks/s3-30-m1-base.uDY78ah3/allocator-runner-fifo-v1"
        if not candidate.exists() and alternate.exists():
            candidate = alternate
    else:
        candidate = path
    candidate = candidate.absolute()
    allowed = {
        (REPO / "work/tmp/s3-30-m1-base.uDY78ah3/allocator-runner-fifo-v1").absolute(),
        (REPO / ".git/benchmarks/s3-30-m1-base.uDY78ah3/allocator-runner-fifo-v1").absolute(),
    }
    assert candidate in allowed, f"support kit must use an approved local path: {candidate}"
    assert not candidate.is_symlink(), f"support kit path cannot be a symlink: {candidate}"
    KIT = candidate
    RUNNER_PATH = KIT / "runner.py"
    NICE_SHIM = KIT / "reference/short-windows-v1/runner-check/exec-nice.sh"
    HOST_LOAD_PY = KIT / "reference/short-windows-v1/runner-check/host_load.py"
    WATCH_LOAD_PY = KIT / "reference/short-windows-v1/runner-check/host-load/watch-load.py"
    CPU_IDLE_C = KIT / "reference/short-windows-v1/runner-check/host-load/cpu_idle.c"
    for source in (RUNNER_PATH, NICE_SHIM, HOST_LOAD_PY, WATCH_LOAD_PY, CPU_IDLE_C):
        assert not source.is_symlink(), f"support asset cannot be a symlink: {source}"
    RUNNER = None


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def failure_reason(error: Exception) -> str:
    message = str(error)
    if message:
        return message
    frames = traceback.extract_tb(error.__traceback__)
    if frames:
        frame = frames[-1]
        return f"{type(error).__name__} at {Path(frame.filename).name}:{frame.lineno}"
    return type(error).__name__


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def stock_exec_receipt(text: str) -> tuple[int, int, int]:
    matches = re.findall(r"stock_exec_pid_uid_nice=(\d+) (\d+) (-?\d+)", text)
    assert len(matches) == 1, f"expected one stock exec identity receipt, got {len(matches)}"
    return tuple(map(int, matches[0]))


def now() -> str:
    return datetime.now(UTC).isoformat()


def helper() -> Any:
    global RUNNER
    assert RUNNER_PATH.is_file() and sha256(RUNNER_PATH) == RUNNER_SHA256, "approved runner pin changed"
    assert NICE_SHIM.is_file() and sha256(NICE_SHIM) == NICE_SHIM_SHA256, "approved exec-nice shim pin changed"
    assert HOST_LOAD_PY.is_file() and sha256(HOST_LOAD_PY) == HOST_LOAD_PY_SHA256, "approved host-load parser pin changed"
    assert WATCH_LOAD_PY.is_file() and sha256(WATCH_LOAD_PY) == WATCH_LOAD_PY_SHA256, "approved host-load sampler pin changed"
    assert CPU_IDLE_C.is_file() and sha256(CPU_IDLE_C) == CPU_IDLE_C_SHA256, "approved cpu-idle probe pin changed"
    if RUNNER is None:
        spec = importlib.util.spec_from_file_location("approved_s3_30_runner", RUNNER_PATH)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        RUNNER = module
    return RUNNER


def validate_pins(path: Path, source_root: Path, binary: Path) -> tuple[dict[str, Any], Path, Path]:
    pins = read_json(path)
    required = {
        "schema", "base_revision", "base_tree", "overlay_patch_sha256",
        "source_binding_sha256", "native_binary_sha256", "m1_uid",
        "fixture_driver_sha256", "m1_preflight_sha256",
    }
    assert required <= set(pins), f"pins missing fields: {sorted(required - set(pins))}"
    assert pins["schema"] == 1
    assert pins["base_revision"] == "eb314737664ad1dd40297db4b92e8e1a9de4b6ea"
    assert pins["base_tree"] == BASE_TREE_SHA256
    assert pins["m1_uid"] == 501
    assert pins["fixture_driver_sha256"] == "3a9c28b5b2899052be3a4faf1ba229252ff5e224965a06cb5c543234cf343d69"
    for key in ("base_revision", "base_tree", "overlay_patch_sha256", "source_binding_sha256",
                "native_binary_sha256", "fixture_driver_sha256", "m1_preflight_sha256"):
        assert re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", str(pins[key])), key
    assert pins["overlay_patch_sha256"] == SOURCE_PATCH_SHA256
    assert pins["source_binding_sha256"] == SOURCE_BINDING_SHA256
    assert pins["native_binary_sha256"] == M1_BINARY_SHA256
    assert pins["m1_preflight_sha256"] == M1_PREFLIGHT_SHA256
    assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip() == pins["base_revision"]
    assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD^{tree}"], text=True).strip() == pins["base_tree"]
    stock_status = subprocess.check_output(["git", "-C", str(REPO), "status", "--porcelain"], text=True)
    assert not stock_status.strip(), f"measured execution checkout is not clean: {stock_status}"

    bundle = path.resolve().parent
    binding_path = bundle / "source-binding.json"
    patch_path = bundle / "source.patch"
    preflight_path = bundle / "m1-preflight/preflight.json"
    preflight_log = bundle / "m1-preflight/preflight.log"
    sign_log = bundle / "m1-preflight/sign.log"
    mach_o = bundle / "m1-preflight/mach-o.txt"
    binary_sha_file = bundle / "m1-preflight/binary.sha256"
    assert sha256(binding_path) == pins["source_binding_sha256"]
    assert sha256(patch_path) == pins["overlay_patch_sha256"]
    assert sha256(preflight_path) == pins["m1_preflight_sha256"]
    assert sha256(preflight_log) == M1_PREFLIGHT_LOG_SHA256
    assert sign_log.is_file() and mach_o.is_file() and binary_sha_file.is_file()
    assert M1_BINARY_SHA256 in binary_sha_file.read_text()

    binding = read_json(binding_path)
    assert set(binding) == {"revision", "tree", "files"}
    assert binding["revision"] == pins["base_revision"]
    assert binding["tree"] == pins["base_tree"]
    assert isinstance(binding["files"], dict) and binding["files"]
    head = subprocess.check_output(["git", "-C", str(source_root), "rev-parse", "HEAD"], text=True).strip()
    tree = subprocess.check_output(["git", "-C", str(source_root), "rev-parse", "HEAD^{tree}"], text=True).strip()
    assert (head, tree) == (pins["base_revision"], pins["base_tree"]), (head, tree)
    live_patch = subprocess.check_output(["git", "-C", str(source_root), "diff", "--binary", "HEAD"])
    assert hashlib.sha256(live_patch).hexdigest() == pins["overlay_patch_sha256"], "working patch differs from pinned source.patch"
    for relative, expected in binding["files"].items():
        source = (source_root / relative).resolve()
        assert source.is_relative_to(source_root.resolve()) and source.is_file(), relative
        assert sha256(source) == expected, f"source binding mismatch: {relative}"
    fixture_archive = source_root / "docs/reports/data/stage3/s3-31l-m1pro-20261119/s3-31l-warm-m1pro-evidence.json.gz"
    assert sha256(fixture_archive) == FIXTURE_ARCHIVE_SHA256
    fixture = json.loads(gzip.decompress(fixture_archive.read_bytes()))
    driver_source = fixture["files"]["harness/measure.rs"]
    driver_digest = hashlib.sha256(driver_source.encode("utf-8")).hexdigest()
    assert fixture["file_sha256"]["harness/measure.rs"] == pins["fixture_driver_sha256"] == driver_digest
    assert binary.is_file() and sha256(binary) == pins["native_binary_sha256"]
    assert preflight_log.is_file(), f"pinned M1 preflight log missing: {preflight_log}"
    assert stock_exec_receipt(preflight_log.read_text()) == (M1_PREFLIGHT_PID, pins["m1_uid"], -5)
    anchor = read_json(preflight_path)
    check_report(anchor, pins, anchor["process_run"], True, binary)
    return pins, binding_path, preflight_path


def capture_signing(binary: Path, pins: dict[str, Any], pins_path: Path, out: Path) -> dict[str, Any]:
    module = helper()
    module.PROVENANCE_PATH = pins_path
    # binary_evidence is reused unchanged; its provenance lookup is bound to the
    # caller's pinned native_binary_sha256 field.
    evidence = module.binary_evidence(binary, pins["native_binary_sha256"])
    for name, content in evidence.items():
        (out / name).write_bytes(content)
    signature = subprocess.run(
        ["/usr/bin/codesign", "-dv", "--verbose=4", str(binary)], capture_output=True, check=True,
    )
    entitlements = plistlib.loads(evidence["entitlements.plist"])
    return {
        "binary_sha256": sha256(binary),
        "codesign_details_sha256": hashlib.sha256(evidence["codesign.log"]).hexdigest(),
        "entitlements": entitlements,
        "codesign_stderr_sha256": hashlib.sha256(signature.stderr).hexdigest(),
    }


def ps_row(pid: int) -> str:
    result = subprocess.run(
        ["/bin/ps", "-ww", "-p", str(pid), "-o", "pid=", "-o", "uid=", "-o", "nice=", "-o", "command="],
        text=True, capture_output=True,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def process_identity(row: str, binary: Path) -> tuple[int, int, int] | None:
    fields = row.split(maxsplit=3)
    if len(fields) != 4 or not fields[3].startswith(f"{binary} warm-dispatch-phases "):
        return None
    try:
        return tuple(map(int, fields[:3]))
    except ValueError:
        return None


def live_host_evidence() -> dict[str, str]:
    """Read the same OS/version/architecture/CPU fields as HostMetadata::current."""
    def rust_command_text(argv: list[str]) -> str:
        result = subprocess.run(argv, text=True, capture_output=True)
        if result.returncode == 0:
            return result.stdout.strip()
        return f"unavailable: {Path(argv[0]).name} exited with status exit status: {result.returncode}"

    rustc = subprocess.check_output(["rustc", "--version"], text=True).strip()
    verbose = subprocess.check_output(["rustc", "--version", "--verbose"], text=True)
    host_target = next(line.split(":", 1)[1].strip() for line in verbose.splitlines() if line.startswith("host:"))
    machine = subprocess.check_output(["/usr/bin/uname", "-m"], text=True).strip()
    architecture = {"arm64": "aarch64", "x86_64": "x86_64"}.get(machine, machine)
    return {
        "os": "macos",
        "os_version": subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip(),
        "architecture": architecture,
        "cpu_model": rust_command_text(["sysctl", "-n", "machdep.cpu.brand_string"]),
        "rustc": rustc,
        "rust_target": host_target,
        "machine": machine,
    }


def verify_host_receipts(raw: dict[str, Any], pins: dict[str, Any], execution_root: Path,
                         live: dict[str, str]) -> None:
    capture = raw["capture_host"]
    measure = raw["measure_host"]
    assert capture == measure, "capture_host and measure_host differ within raw report"
    assert capture["os"] == live["os"]
    assert capture["os_version"] == live["os_version"]
    assert capture["architecture"] == live["architecture"]
    assert capture["cpu_model"] == live["cpu_model"]
    build = capture["build"]
    execution = capture["execution"]
    assert build["rustc"] == live["rustc"]
    assert build["source_revision"] == pins["base_revision"]
    assert re.fullmatch(r"[0-9a-f]{64}", build["source_sha256"])
    assert build["source_tree_dirty"] is True
    assert build["profile"].lower() == raw["binary_identity"]["build_mode"].lower()
    assert build["target"] == live["rust_target"]
    assert execution["working_directory"] == str(execution_root.resolve())
    assert execution["repository_revision"] == pins["base_revision"]
    assert execution["working_tree_dirty"] is False


def verify_benchmark_launch(out: Path, receipt: dict[str, Any], pins: dict[str, Any]) -> None:
    timeline = receipt["timeline"]
    if not timeline or not timeline.get("scheduling_pid_verified"):
        if receipt["result"] == "load_rejected_retryable":
            assert receipt["host_preflight"] and not receipt["host_preflight"]["accepted"]
            assert receipt["report_sha256"] is None and receipt["host_load"]["status"] == "preflight_rejected"
            assert not (out / "benchmark.log").exists() and not (out / "benchmark.ps").exists()
        else:
            assert receipt["result"] == "failed_nonretryable"
        return
    pid, uid, nice = stock_exec_receipt((out / "benchmark.log").read_text())
    assert pid > 1 and uid == pins["m1_uid"] and nice == -5
    assert (pid, uid, nice) == (timeline["pid"], timeline["uid"], timeline["effective_nice"])
    assert isinstance(timeline["returncode"], int)
    row = (out / "benchmark.ps").read_text().strip()
    assert process_identity(row, Path(receipt["binary_path"])) == (pid, uid, nice)
    columns = row.split(maxsplit=3)
    command = columns[3].split()
    expected_run_args = ["warm-dispatch-phases", "--profile", PROFILE,
                         "--process-run", str(receipt["process_run"]), "--output", str(Path(receipt["output_path"]) / "report.json")]
    if receipt["mode"] == "preflight-only":
        expected_run_args.append("--preflight-only")
    assert command == [receipt["binary_path"], *expected_run_args], command
    shim = receipt["exec_nice_shim_path"]
    assert sha256(out / "transport/exec-nice.sh") == receipt["exec_nice_shim_sha256"] == NICE_SHIM_SHA256
    expected_argv = ["/usr/bin/sudo", "-n", "/usr/bin/nice", "-n", "-5",
                     "/usr/bin/sudo", "-n", "-u", f"#{pins['m1_uid']}", "--", "/bin/sh", shim,
                     str(pins["m1_uid"]), receipt["binary_path"], *expected_run_args]
    assert timeline["argv"] == expected_argv


def verify_timed_host_artifacts(out: Path, receipt: dict[str, Any]) -> None:
    """Require retained watcher evidence to match the live monitor success path."""
    assert receipt["mode"] == "timed"
    assert receipt["watcher_completion"] == {"exit_code": 0}
    assert (out / "finished").is_file(), "watcher completion marker missing"
    assert (out / "host-load.log").is_file(), "watcher log missing"
    stderr = out / "host-load.stderr"
    assert stderr.is_file() and not stderr.read_bytes(), "watcher stderr is missing or non-empty"


def verify_retained_signing(out: Path, receipt: dict[str, Any], pins: dict[str, Any]) -> None:
    assert receipt["binary_sha256"] == pins["native_binary_sha256"] == M1_BINARY_SHA256
    mach_o = (out / "mach-o.log").read_text()
    codesign = (out / "codesign.log").read_text()
    entitlements = plistlib.loads((out / "entitlements.plist").read_bytes())
    assert mach_o.startswith("lipo_archs=arm64\n")
    assert re.findall(r"^\s*minos\s+(\S+)\s*$", mach_o, re.MULTILINE) == ["14.0"]
    assert "runtime)" in codesign
    assert re.search(r"^Identifier=\S+", codesign, re.MULTILINE)
    assert entitlements == {"com.apple.security.cs.allow-jit": True}
    sign = receipt["signing"]
    assert sign["binary_sha256"] == pins["native_binary_sha256"]
    assert sign["entitlements"] == entitlements
    assert sign["codesign_details_sha256"] == sha256(out / "codesign.log")


def validate_captured_duration(raw: dict[str, Any], timeline: dict[str, Any]) -> dict[str, int]:
    start = helper().aware_timestamp(timeline["started_at"])
    end = helper().aware_timestamp(timeline["completed_at"])
    delta = end - start
    captured_ns = ((delta.days * 86_400 + delta.seconds) * 1_000_000_000 + delta.microseconds * 1_000)
    serialized_ns = int(raw["total_elapsed_ns"])
    assert captured_ns + 1_000_000 >= serialized_ns, (captured_ns, serialized_ns)
    return {"captured_elapsed_ns": captured_ns, "serialized_elapsed_ns": serialized_ns, "rounding_tolerance_ns": 1_000_000}


def run_native(out: Path, source_root: Path, binary: Path, pins: dict[str, Any], process_run: int,
               preflight_only: bool) -> tuple[dict[str, Any], dict[str, Any]]:
    raw_path = out / "report.json"
    log_path = out / "benchmark.log"
    timeline = {"profile": PROFILE, "process_run": process_run, "started_at": now()}
    argv = [
        "/usr/bin/sudo", "-n", "/usr/bin/nice", "-n", "-5",
        "/usr/bin/sudo", "-n", "-u", f"#{pins['m1_uid']}", "--", "/bin/sh", str(NICE_SHIM),
        str(pins["m1_uid"]), str(binary), "warm-dispatch-phases", "--profile", PROFILE,
        "--process-run", str(process_run), "--output", str(raw_path),
    ]
    if preflight_only:
        argv.append("--preflight-only")
    timeline["argv"] = argv
    child = None
    pid = None
    with log_path.open("xb") as stream:
        child = subprocess.Popen(argv, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            deadline = time.monotonic() + 12
            while time.monotonic() < deadline:
                log = log_path.read_text(errors="replace")
                matches = re.findall(r"stock_exec_pid_uid_nice=(\d+) (\d+) (-?\d+)", log)
                if matches:
                    assert len(matches) == 1, matches
                    pid, uid, nice = map(int, matches[0])
                    assert (uid, nice) == (pins["m1_uid"], -5), (uid, nice)
                    observed_ps = ps_row(pid)
                    observed = process_identity(observed_ps, binary)
                    if observed is not None:
                        assert observed == (pid, pins["m1_uid"], -5), observed
                        (out / "benchmark.ps").write_text(observed_ps + "\n")
                        timeline.update(pid=pid, uid=uid, effective_nice=nice, scheduling_pid_verified=True)
                        break
                assert child.poll() is None, log
                time.sleep(0.001)
            else:
                raise RuntimeError("no live benchmark PID/UID/nice receipt from approved shim")
            timeline["returncode"] = child.wait(timeout=900)
        finally:
            if child.poll() is None:
                # The process group is created by this adapter invocation and
                # is terminated only when the expected executable identity is
                # still live; the saved log remains available for diagnosis.
                if pid is not None and process_identity(ps_row(pid), binary) == (pid, pins["m1_uid"], -5):
                    try:
                        os.kill(pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=5)
            timeline.setdefault("returncode", child.poll())
            timeline["completed_at"] = now()
    assert raw_path.is_file(), f"benchmark report missing; see {log_path}"
    timeline.update(raw_sha256=sha256(raw_path), raw_size_bytes=raw_path.stat().st_size)
    return timeline, read_json(raw_path)


def check_report(raw: dict[str, Any], pins: dict[str, Any], process_run: int, preflight_only: bool,
                 binary_path: Path | None = None, anchor: dict[str, Any] | None = None) -> None:
    required = {
        "schema", "profile", "process_run", "timing_started", "run_outcome",
        "source_identity", "binary_identity", "capture_host", "measure_host",
        "timing_contract", "timing_scope", "phase_boundary_contract", "residual_contract", "strata",
        "total_elapsed_ns",
    }
    assert set(raw) == required, f"report top-level schema differs: missing={sorted(required - set(raw))}, extra={sorted(set(raw) - required)}"
    assert raw["schema"] == 1
    assert raw["profile"] == PROFILE and raw["process_run"] == process_run
    assert raw["source_identity"]["base_revision"] == pins["base_revision"]
    assert raw["source_identity"]["fixture_archive_path"] == "docs/reports/data/stage3/s3-31l-m1pro-20261119/s3-31l-warm-m1pro-evidence.json.gz"
    assert raw["source_identity"]["fixture_archive_sha256"] == FIXTURE_ARCHIVE_SHA256
    assert raw["source_identity"]["fixture_driver_path"] == "harness/measure.rs"
    assert raw["source_identity"]["fixture_driver_sha256"] == pins["fixture_driver_sha256"]
    assert set(raw["source_identity"]) == {"base_revision", "fixture_archive_path", "fixture_archive_sha256", "fixture_driver_path", "fixture_driver_sha256"}
    assert raw["binary_identity"]["executable_sha256"] == pins["native_binary_sha256"]
    architecture = str(raw["binary_identity"]["target_architecture"]).lower()
    assert "arm64" in architecture or "aarch64" in architecture, architecture
    if binary_path is not None:
        assert raw["binary_identity"]["executable_path"] == str(binary_path)
    assert set(raw["binary_identity"]) == {"build_mode", "executable_path", "executable_sha256", "target_architecture"}
    assert set(raw["timing_contract"]) == {"measured_pairs", "target_side_ns", "minimum_side_ns",
        "maximum_calibration_attempts", "maximum_series_restarts", "initial_order_rule"}
    if anchor is not None:
        assert raw["source_identity"] == anchor["source_identity"]
        assert raw["binary_identity"] == anchor["binary_identity"]
        assert raw["capture_host"] == anchor["capture_host"]
        assert raw["measure_host"] == anchor["measure_host"]
        assert raw["timing_contract"] == anchor["timing_contract"]
        assert raw["timing_scope"] == anchor["timing_scope"]
        assert raw["phase_boundary_contract"] == anchor["phase_boundary_contract"]
        assert raw["residual_contract"] == anchor["residual_contract"]
        assert len(raw["strata"]) == len(anchor["strata"])
        for current, pinned in zip(raw["strata"], anchor["strata"]):
            assert current["fixture"] == pinned["fixture"]
            assert current["preflight"] == pinned["preflight"]
    assert raw["timing_contract"]["measured_pairs"] == 20
    assert raw["timing_contract"]["target_side_ns"] == TARGET_SIDE_NS
    assert raw["timing_contract"]["minimum_side_ns"] == MIN_SIDE_NS
    assert raw["timing_contract"]["maximum_calibration_attempts"] == 8
    assert raw["timing_contract"]["maximum_series_restarts"] == 8
    assert [item["fixture"]["name"] for item in raw["strata"]] == list(FIXTURES)
    if preflight_only:
        assert raw["timing_started"] is False and raw["run_outcome"] == "preflight_complete"
        for item in raw["strata"]:
            assert set(item) == {"fixture", "preflight", "calibration_attempts", "series_restarts", "common_sweeps_per_sample", "pairs"}
            fixture = item["fixture"]
            assert set(fixture) == {"code_hex", "code_sha256", "expected_dispatch_exit", "expected_interpreter_exit",
                "expected_native_blocks", "expected_remaining_budget", "expected_retired_instructions", "initial_rax",
                "initial_rcx", "initial_rflags", "instruction_budget", "name", "stop_rip", "unique_admitted_entries"}
            assert hashlib.sha256(bytes.fromhex(fixture["code_hex"])).hexdigest() == fixture["code_sha256"]
            preflight_fields = {"cold_prewarm_counters_after", "cold_prewarm_counters_before", "cold_prewarm_delta",
                "interpreter_exit_retirement_and_full_state_match", "observed_key_lookup_count",
                "observed_memo_resolution_phase_calls", "observed_memo_resolved_count", "observed_phase_counts_match_work",
                "observed_warm_counters_after", "observed_warm_counters_before", "observed_warm_delta",
                "ordinary_and_observed_dispatch_results_match", "ordinary_and_observed_full_state_match",
                "ordinary_warm_counters_after", "ordinary_warm_counters_before", "ordinary_warm_delta"}
            assert set(item["preflight"]) == preflight_fields
            assert int(item["common_sweeps_per_sample"]) == 0
            for key in ("interpreter_exit_retirement_and_full_state_match", "observed_phase_counts_match_work",
                        "ordinary_and_observed_dispatch_results_match", "ordinary_and_observed_full_state_match"):
                assert item["preflight"][key] is True, (fixture["name"], key)
            assert not item.get("pairs") and not item.get("calibration_attempts")
            assert item["series_restarts"] == []
    else:
        assert raw["timing_started"] is True and raw["run_outcome"] == "complete"
        assert raw["total_elapsed_ns"] > 0
        # Recompute paired elapsed floors without synthesizing or inferring
        # any fixture counters.
        serialized_elapsed_work = 0
        for stratum in raw["strata"]:
            assert set(stratum) == {"fixture", "preflight", "calibration_attempts", "series_restarts", "common_sweeps_per_sample", "pairs"}
            fixture_name = stratum["fixture"]["name"]
            assert hashlib.sha256(bytes.fromhex(stratum["fixture"]["code_hex"])).hexdigest() == stratum["fixture"]["code_sha256"]
            assert all(stratum["preflight"][key] is True for key in (
                "interpreter_exit_retirement_and_full_state_match", "observed_phase_counts_match_work",
                "ordinary_and_observed_dispatch_results_match", "ordinary_and_observed_full_state_match")), fixture_name
            pairs = stratum["pairs"]
            assert len(pairs) == 20, fixture_name
            assert [int(pair["pair"]) for pair in pairs] == list(range(1, 21)), fixture_name
            fixture = stratum["fixture"]
            block_count = int(fixture["expected_native_blocks"])
            retired = int(fixture["expected_retired_instructions"])
            sweeps = int(stratum["common_sweeps_per_sample"])
            assert sweeps > 0
            assert {int(pair["sweeps_per_side"]) for pair in pairs} == {sweeps}, fixture_name

            calibrations = stratum["calibration_attempts"]
            assert 1 <= len(calibrations) <= 8, fixture_name
            assert [int(item["attempt"]) for item in calibrations] == list(range(1, len(calibrations) + 1))
            assert set(calibrations[0]) == {"attempt", "sweeps_per_side", "ordinary_dispatch_call_elapsed_ns", "observed_dispatch_call_elapsed_ns"}
            assert int(calibrations[0]["sweeps_per_side"]) == 1, fixture_name
            for index, item in enumerate(calibrations):
                assert set(item) == {"attempt", "sweeps_per_side", "ordinary_dispatch_call_elapsed_ns", "observed_dispatch_call_elapsed_ns"}
                assert int(item["sweeps_per_side"]) > 0
                assert int(item["ordinary_dispatch_call_elapsed_ns"]) > 0
                assert int(item["observed_dispatch_call_elapsed_ns"]) > 0
                both_ready = min(int(item["ordinary_dispatch_call_elapsed_ns"]), int(item["observed_dispatch_call_elapsed_ns"])) >= TARGET_SIDE_NS
                assert both_ready == (index == len(calibrations) - 1), fixture_name
                if index + 1 < len(calibrations):
                    minimum = min(int(item["ordinary_dispatch_call_elapsed_ns"]), int(item["observed_dispatch_call_elapsed_ns"]))
                    scale = max(2, math.ceil(MIN_SIDE_NS / max(minimum, 1)))
                    expected_sweeps = int(item["sweeps_per_side"]) * scale + 1
                    assert int(calibrations[index + 1]["sweeps_per_side"]) == expected_sweeps, fixture_name
            assert sweeps == int(calibrations[-1]["sweeps_per_side"]), fixture_name
            calibration_sweeps = sum(int(item["sweeps_per_side"]) for item in calibrations)
            calibration_elapsed = sum(int(item["ordinary_dispatch_call_elapsed_ns"]) + int(item["observed_dispatch_call_elapsed_ns"])
                                       for item in calibrations)
            stratum_elapsed_work = calibration_elapsed
            baseline = dict(stratum["preflight"]["cold_prewarm_counters_after"])
            assert isinstance(baseline.get("hits"), int)
            baseline["hits"] += 2 * block_count * calibration_sweeps
            for pair in pairs:
                assert set(pair) == {"pair", "first_variant", "sweeps_per_side", "ratio_observed_over_ordinary", "ordinary", "observed"}
                expected_first = "phase_observed" if ((int(pair["pair"]) - 1 + process_run) % 2) != 0 else "ordinary_noop_observer"
                assert pair["first_variant"] == expected_first
                assert set(pair["ordinary"]) == {"dispatch_calls", "retired_guest_instructions", "native_block_executions",
                    "dispatch_call_elapsed_ns", "cache_delta", "counters_before", "counters_after", "phase_totals"}
                assert set(pair["observed"]) == set(pair["ordinary"]) | {"continuation_memo_resolution", "key_lookup_count",
                    "memo_resolved_count", "attributed_phase_ns", "unattributed_residual_ns"}
                ordinary_ns = int(pair["ordinary"]["dispatch_call_elapsed_ns"])
                observed_ns = int(pair["observed"]["dispatch_call_elapsed_ns"])
                assert ordinary_ns >= MIN_SIDE_NS and observed_ns >= MIN_SIDE_NS, fixture_name
                expected_ratio = observed_ns / ordinary_ns
                assert abs(float(pair["ratio_observed_over_ordinary"]) - expected_ratio) <= max(1e-12, expected_ratio * 1e-12)
                assert int(pair["ordinary"]["dispatch_calls"]) == int(pair["observed"]["dispatch_calls"])
                assert int(pair["ordinary"]["retired_guest_instructions"]) == int(pair["observed"]["retired_guest_instructions"])
                assert int(pair["ordinary"]["native_block_executions"]) == int(pair["observed"]["native_block_executions"])
                expected_cache = {"hits": block_count * sweeps, "misses": 0,
                                  "successful_compiles": 0, "successful_publications": 0, "evictions": 0}
                ordered_sides = ("observed", "ordinary") if expected_first == "phase_observed" else ("ordinary", "observed")
                for side_name in ordered_sides:
                    side = pair[side_name]
                    assert int(side["dispatch_calls"]) == sweeps
                    assert int(side["retired_guest_instructions"]) == retired * sweeps
                    assert int(side["native_block_executions"]) == block_count * sweeps
                    assert side["cache_delta"] == expected_cache
                    assert side["counters_before"] == baseline, (fixture_name, pair["pair"], side_name, "before")
                    after = dict(baseline)
                    after["hits"] += block_count * sweeps
                    assert side["counters_after"] == after, (fixture_name, pair["pair"], side_name, "after")
                    snapshot_delta = {
                        "hits": after["hits"] - baseline["hits"],
                        "misses": after["misses"] - baseline["misses"],
                        "successful_compiles": after["compiles"] - baseline["compiles"],
                        "successful_publications": after["publications"] - baseline["publications"],
                        "evictions": after["evictions"] - baseline["evictions"],
                    }
                    assert snapshot_delta == side["cache_delta"]
                    baseline = after
                    stratum_elapsed_work += int(side["dispatch_call_elapsed_ns"])
                memo = pair["observed"]["continuation_memo_resolution"]
                assert set(memo) == {"calls", "elapsed_ns"}
                assert int(memo["calls"]) == (block_count - 1) * sweeps
                assert int(memo["elapsed_ns"]) >= 0
                assert pair["ordinary"]["phase_totals"] == []
                totals = pair["observed"]["phase_totals"]
                phase_names = {"block_build_and_admission", "key_snapshot_and_initial_lookup", "host_execution_boundary"}
                zero_work_phases = {"ir_lowering", "allocation", "emission_and_finalization", "publication"}
                expected_phase_names = phase_names | zero_work_phases
                assert (isinstance(totals, list) and len(totals) == len(expected_phase_names)
                        and {item["phase"] for item in totals} == expected_phase_names)
                assert all(set(item) == {"phase", "calls", "elapsed_ns"} for item in totals)
                assert all(type(item["calls"]) is int and type(item["elapsed_ns"]) is int for item in totals)
                assert all(int(item["calls"]) == block_count * sweeps and int(item["elapsed_ns"]) >= 0
                           for item in totals if item["phase"] in phase_names)
                assert all(int(item["calls"]) == 0 and int(item["elapsed_ns"]) == 0
                           for item in totals if item["phase"] in zero_work_phases)
                observed = pair["observed"]
                assert int(observed["key_lookup_count"]) == int(stratum["preflight"]["observed_key_lookup_count"]) * sweeps
                assert int(observed["memo_resolved_count"]) == int(stratum["preflight"]["observed_memo_resolved_count"]) * sweeps
                attributed = sum(int(item["elapsed_ns"]) for item in observed["phase_totals"]) + int(memo["elapsed_ns"])
                residual = int(observed["dispatch_call_elapsed_ns"]) - attributed
                assert int(observed["attributed_phase_ns"]) == attributed, fixture_name
                assert int(observed["unattributed_residual_ns"]) == residual and residual >= 0, fixture_name
            assert stratum["series_restarts"] == [], fixture_name
            serialized_elapsed_work += stratum_elapsed_work
        assert int(raw["total_elapsed_ns"]) >= serialized_elapsed_work


def verify_saved_input_bundle(out: Path, pins: dict[str, Any]) -> dict[str, Any]:
    assert pins["source_binding_sha256"] == SOURCE_BINDING_SHA256
    assert pins["overlay_patch_sha256"] == SOURCE_PATCH_SHA256
    assert pins["native_binary_sha256"] == M1_BINARY_SHA256
    assert pins["m1_preflight_sha256"] == M1_PREFLIGHT_SHA256
    binding_path = out / "source-binding.json"
    patch_path = out / "source.patch"
    archive_path = out / "fixture-archive.json.gz"
    anchor_path = out / "m1-preflight.json"
    m1_log = out / "m1-preflight.log"
    assert sha256(binding_path) == pins["source_binding_sha256"]
    assert sha256(patch_path) == pins["overlay_patch_sha256"]
    assert sha256(archive_path) == FIXTURE_ARCHIVE_SHA256
    assert sha256(anchor_path) == pins["m1_preflight_sha256"]
    assert sha256(m1_log) == M1_PREFLIGHT_LOG_SHA256
    binding = read_json(binding_path)
    assert binding["revision"] == pins["base_revision"] and binding["tree"] == pins["base_tree"]
    fixture = json.loads(gzip.decompress(archive_path.read_bytes()))
    driver = fixture["files"]["harness/measure.rs"]
    assert fixture["file_sha256"]["harness/measure.rs"] == pins["fixture_driver_sha256"]
    assert hashlib.sha256(driver.encode("utf-8")).hexdigest() == pins["fixture_driver_sha256"]
    assert stock_exec_receipt(m1_log.read_text()) == (M1_PREFLIGHT_PID, pins["m1_uid"], -5)
    for name in ("sign.log", "mach-o.txt", "binary.sha256"):
        assert (out / "m1-preflight" / name).is_file()
    assert M1_BINARY_SHA256 in (out / "m1-preflight/binary.sha256").read_text()
    anchor = read_json(anchor_path)
    check_report(anchor, pins, anchor["process_run"], True, Path(anchor["binary_identity"]["executable_path"]))
    return anchor


def attempt(pins_path: Path, source_root: Path, binary: Path, out: Path, process_run: int,
           preflight_only: bool) -> dict[str, Any]:
    attempt_started_at = now()
    assert process_run in (1, 2, 3)
    assert not out.exists(), f"refusing to overwrite attempt output {out}"
    out = out.resolve()
    out.mkdir(parents=True)
    pins_path = pins_path.resolve()
    source_root = source_root.resolve()
    binary = binary.resolve()
    pins, binding_path, m1_preflight = validate_pins(pins_path, source_root, binary)
    shutil.copyfile(pins_path, out / "pins.json")
    shutil.copyfile(binding_path, out / "source-binding.json")
    shutil.copyfile(pins_path.parent / "source.patch", out / "source.patch")
    shutil.copyfile(m1_preflight, out / "m1-preflight.json")
    shutil.copyfile(pins_path.parent / "m1-preflight/preflight.log", out / "m1-preflight.log")
    fixture_archive = source_root / "docs/reports/data/stage3/s3-31l-m1pro-20261119/s3-31l-warm-m1pro-evidence.json.gz"
    shutil.copyfile(fixture_archive, out / "fixture-archive.json.gz")
    (out / "m1-preflight").mkdir()
    for name in ("sign.log", "mach-o.txt", "binary.sha256"):
        shutil.copyfile(pins_path.parent / "m1-preflight" / name, out / "m1-preflight" / name)
    (out / "transport").mkdir()
    shutil.copyfile(NICE_SHIM, out / "transport/exec-nice.sh")
    anchor = verify_saved_input_bundle(out, pins)
    sign = capture_signing(binary, pins, pins_path, out)
    actual_host = live_host_evidence()
    host_preflight: dict[str, Any] | None = None

    timeline: dict[str, Any] | None = None
    report: dict[str, Any] | None = None
    load: dict[str, Any] | None = None
    timing_capture: dict[str, int] | None = None
    watcher_completion: dict[str, int] | None = None
    try:
        host_preflight = helper().run_host_preflight(out)
        if not host_preflight["accepted"]:
            raise helper().HostLoadRejected(f"host idle preflight rejected: {host_preflight}")
        if preflight_only:
            timeline, report = run_native(out, source_root, binary, pins, process_run, True)
        else:
            timeline_box: list[dict[str, Any]] = []
            def invoke() -> None:
                nonlocal timeline, report
                timeline, report = run_native(out, source_root, binary, pins, process_run, False)
                timeline_box.append(timeline)
            load = helper().monitor_timed_profile(out, invoke, timeline_box)
            watcher_completion = {"exit_code": 0}
            timeline = timeline_box[0]
        assert timeline is not None and report is not None
        check_report(report, pins, process_run, preflight_only, binary, anchor)
        assert timeline["scheduling_pid_verified"] is True
        assert timeline["returncode"] == 0, timeline
        verify_host_receipts(report, pins, REPO, actual_host)
        if not preflight_only:
            timing_capture = validate_captured_duration(report, timeline)
        assert sha256(binary) == pins["native_binary_sha256"]
        # Revalidate source and signing inputs after the process has completed.
        validate_pins(pins_path, source_root, binary)
        result = "preflight_passed" if preflight_only else "accepted"
    except Exception as error:
        # Only an otherwise successful benchmark whose sole rejection is the
        # approved host-load coverage/floor check is retryable.
        failure = error
        if isinstance(error, helper().HostLoadRejected):
            try:
                validate_pins(pins_path, source_root, binary)
                if timeline and report:
                    watcher_completion = {"exit_code": 0}
                    check_report(report, pins, process_run, False, binary, anchor)
                    assert timeline.get("returncode") == 0
                    verify_host_receipts(report, pins, REPO, actual_host)
                    timing_capture = validate_captured_duration(report, timeline)
                    load = {"status": "rejected", "reason": str(error)}
                else:
                    load = {"status": "preflight_rejected", "reason": str(error)}
                result = "load_rejected_retryable"
            except Exception as retry_validation_error:
                failure = retry_validation_error
                result = "failed_nonretryable"
        else:
            result = "failed_nonretryable"
        write_json(out / "failure.json", {"kind": type(failure).__name__, "message": failure_reason(failure), "result": result})
    captured_files = (
        "benchmark.log", "benchmark.ps", "preflight.log", "host-load.log", "host-load.stderr", "m1-preflight.log",
        "fixture-archive.json.gz", "m1-preflight/sign.log", "m1-preflight/mach-o.txt", "m1-preflight/binary.sha256",
        "transport/exec-nice.sh", "finished",
        "mach-o.log", "codesign.log", "entitlements.plist", "host-load/cpu_idle.c",
        "host-load/cpu-idle", "host-load/watch-load.py", "failure.json",
    )
    file_hashes = {name: sha256(out / name) for name in captured_files if (out / name).is_file()}
    receipt = {
        "schema": 1, "profile": PROFILE, "process_run": process_run,
        "attempt_started_at": attempt_started_at, "attempt_completed_at": now(),
        "mode": "preflight-only" if preflight_only else "timed",
        "result": result, "pins_sha256": sha256(out / "pins.json"),
        "source_binding_sha256": sha256(out / "source-binding.json"),
        "source_patch_sha256": sha256(out / "source.patch"),
        "m1_preflight_sha256": sha256(out / "m1-preflight.json"),
        "m1_preflight_log_sha256": sha256(out / "m1-preflight.log"),
        "source_root": str(source_root), "execution_root": str(REPO),
        "output_path": str(out), "exec_nice_shim_path": str(NICE_SHIM.resolve()),
        "exec_nice_shim_sha256": sha256(out / "transport/exec-nice.sh"),
        "support_kit": str(KIT), "binary_path": str(binary), "binary_sha256": sha256(binary), "signing": sign,
        "system_host_evidence": actual_host,
        "host_preflight": host_preflight, "timeline": timeline, "host_load": load, "timing_capture": timing_capture,
        "watcher_completion": watcher_completion,
        "report_sha256": sha256(out / "report.json") if (out / "report.json").is_file() else None,
        "file_sha256": file_hashes,
    }
    write_json(out / "receipt.json", receipt)
    try:
        verify_benchmark_launch(out, receipt, pins)
        verify_retained_signing(out, receipt, pins)
    except Exception as error:
        receipt["result"] = "failed_nonretryable"
        write_json(out / "failure.json", {"kind": type(error).__name__, "message": failure_reason(error),
                                            "result": "failed_nonretryable"})
        file_hashes["failure.json"] = sha256(out / "failure.json")
        receipt["file_sha256"] = file_hashes
        write_json(out / "receipt.json", receipt)
        return receipt
    return receipt


def replay_attempt(out: Path) -> dict[str, Any]:
    receipt = read_json(out / "receipt.json")
    assert receipt["schema"] == 1 and receipt["profile"] == PROFILE
    assert datetime.fromisoformat(receipt["attempt_started_at"]) < datetime.fromisoformat(receipt["attempt_completed_at"])
    for name, field in (("pins.json", "pins_sha256"), ("source-binding.json", "source_binding_sha256"),
                        ("source.patch", "source_patch_sha256"), ("m1-preflight.json", "m1_preflight_sha256"),
                        ("m1-preflight.log", "m1_preflight_log_sha256")):
        assert sha256(out / name) == receipt[field], name
    pins = read_json(out / "pins.json")
    assert receipt["source_binding_sha256"] == pins["source_binding_sha256"]
    assert receipt["binary_sha256"] == pins["native_binary_sha256"]
    anchor = verify_saved_input_bundle(out, pins)
    for name, expected in receipt["file_sha256"].items():
        assert sha256(out / name) == expected, name
    verify_benchmark_launch(out, receipt, pins)
    verify_retained_signing(out, receipt, pins)
    module = helper()
    preflight = module.preflight_result((out / "preflight.log").read_text())
    assert preflight == receipt["host_preflight"]
    assert preflight["probes"] == 24
    derived = "failed_nonretryable"
    if not preflight["accepted"]:
        derived = "load_rejected_retryable"
        assert receipt["timeline"] is None and receipt["report_sha256"] is None
        assert receipt["host_load"]["status"] == "preflight_rejected"
    elif receipt["report_sha256"] is not None:
        derived = "unresolved"
        assert sha256(out / "report.json") == receipt["report_sha256"]
        raw = read_json(out / "report.json")
        try:
            check_report(raw, pins, receipt["process_run"], receipt["mode"] == "preflight-only",
                         Path(receipt["binary_path"]), anchor)
            verify_host_receipts(raw, pins, Path(receipt["execution_root"]), receipt["system_host_evidence"])
        except AssertionError:
            if receipt["result"] != "failed_nonretryable":
                raise
            derived = "failed_nonretryable"
        if derived == "failed_nonretryable":
            pass
        else:
            timeline = receipt["timeline"]
            if timeline and timeline.get("returncode") == 0 and timeline.get("scheduling_pid_verified") is True:
                if receipt["mode"] == "preflight-only":
                    derived = "preflight_passed"
                else:
                    assert validate_captured_duration(raw, timeline) == receipt["timing_capture"]
                    verify_timed_host_artifacts(out, receipt)
                    host_log = (out / "host-load.log").read_text()
                    try:
                        replayed_load, minima = module.analyze_timed_load(host_log, [timeline])
                    except module.HostLoadRejected:
                        derived = "load_rejected_retryable"
                    else:
                        assert replayed_load == receipt["host_load"]
                        assert minima and min(minima) >= 80
                        derived = "accepted"
            else:
                derived = "failed_nonretryable"
    else:
        assert receipt["result"] == "failed_nonretryable", "missing benchmark report is not retryable"
        derived = "failed_nonretryable"
    if derived == "load_rejected_retryable" and receipt["report_sha256"] is not None:
        assert receipt["timeline"] and receipt["timeline"]["returncode"] == 0
        # The host-load rejection must itself be reproducible from the saved
        # watcher log and the complete, successful raw benchmark report.
        try:
            module.analyze_timed_load((out / "host-load.log").read_text(), [receipt["timeline"]])
        except module.HostLoadRejected:
            pass
        else:
            raise AssertionError("recorded timed host-load rejection did not replay")
    assert derived == receipt["result"], (derived, receipt["result"])
    if receipt["result"] == "accepted":
        assert receipt["mode"] == "timed" and receipt["host_load"]["status"] == "verified"
        assert receipt["timeline"]["scheduling_pid_verified"] is True
        assert receipt["timeline"]["uid"] == pins["m1_uid"] and receipt["timeline"]["effective_nice"] == -5
    return {"status": "replay_passed", "derived_result": derived, "process_run": receipt["process_run"],
            "report_sha256": receipt["report_sha256"]}


def replay_series(paths: list[Path]) -> dict[str, Any]:
    assert len(paths) >= 3
    attempts = [replay_attempt(path) for path in paths]
    rows = [read_json(path / "receipt.json") for path in paths]
    by_run: dict[int, list[tuple[Path, dict[str, Any]]]] = {1: [], 2: [], 3: []}
    for path, row in zip(paths, rows):
        assert row["process_run"] in by_run
        by_run[row["process_run"]].append((path, row))
    accepted = []
    for run in (1, 2, 3):
        candidates = by_run[run]
        assert candidates, f"no attempt for process run {run}"
        assert len(candidates) <= 4, f"process run {run} exceeds the approved four-attempt cap"
        timestamps = [datetime.fromisoformat(row["attempt_started_at"]) for _, row in candidates]
        assert timestamps == sorted(timestamps), f"process run {run} attempts are not chronological"
        assert all(datetime.fromisoformat(before[1]["attempt_completed_at"]) <= datetime.fromisoformat(after[1]["attempt_started_at"])
                   for before, after in zip(candidates, candidates[1:])), f"process run {run} attempts overlap"
        for _, previous in candidates[:-1]:
            assert previous["result"] == "load_rejected_retryable", "only source-valid load-only rejection can retry"
        passes = [item for item in candidates if item[1]["result"] == "accepted"]
        assert len(passes) == 1 and candidates[-1] is passes[0], f"process run {run} has no unique first passing attempt"
        accepted.append(passes[0])
    reports = [read_json(path / "report.json") for path, _ in accepted]
    assert len(reports) == 3
    stable = []
    for report in reports:
        stable.append({
            "source_identity": report["source_identity"],
            "binary_identity": report["binary_identity"],
            "capture_host": report["capture_host"],
            "measure_host": report["measure_host"],
            "timing_contract": report["timing_contract"],
            "timing_scope": report["timing_scope"],
            "phase_boundary_contract": report["phase_boundary_contract"],
            "residual_contract": report["residual_contract"],
            "strata": [{"fixture": item["fixture"], "preflight": item["preflight"]}
                       for item in report["strata"]],
        })
    assert all(canonical(value) == canonical(stable[0]) for value in stable[1:]), "stable attribution/source/host evidence changed across runs"
    return {"status": "three_attempt_series_passed", "profile": PROFILE,
            "process_runs": [1, 2, 3], "selected_attempts": [str(path) for path, _ in accepted],
            "report_sha256": [sha256(path / "report.json") for path, _ in accepted],
            "metrics_accepted": False, "stable_phase_attribution": True}


def selftest() -> dict[str, Any]:
    """Clock-free checks against the signed M1 anchor and approved host parser."""
    prep_path = REPO / "work/tmp/latest-current-memo-v2-preparation-path"
    assert prep_path.is_file(), f"V2 M1 preparation path pin missing: {prep_path}"
    prep = Path(prep_path.read_text().strip())
    anchor_path = prep / "m1/preflight.json"
    anchor = read_json(anchor_path)
    pins = {
        "base_revision": "eb314737664ad1dd40297db4b92e8e1a9de4b6ea",
        "fixture_driver_sha256": "3a9c28b5b2899052be3a4faf1ba229252ff5e224965a06cb5c543234cf343d69",
        "native_binary_sha256": M1_BINARY_SHA256,
    }
    check_report(anchor, pins, anchor["process_run"], True, Path(anchor["binary_identity"]["executable_path"]))
    fixture_archive = REPO / anchor["source_identity"]["fixture_archive_path"]
    archive = json.loads(gzip.decompress(fixture_archive.read_bytes()))
    driver = archive["files"]["harness/measure.rs"]
    assert sha256(fixture_archive) == FIXTURE_ARCHIVE_SHA256
    assert hashlib.sha256(driver.encode("utf-8")).hexdigest() == pins["fixture_driver_sha256"]

    module = helper()
    idle_line = "cpu_idle=100.0% idle_ticks=100 total_ticks=100 over 2 seconds"
    preflight = module.preflight_result("\n".join([idle_line] * 24))
    assert preflight == {"probes": 24, "min_idle_pct": 100.0, "median_idle_pct": 100.0, "accepted": True}
    timeline = [{"started_at": "2026-11-20T00:00:00+00:00", "completed_at": "2026-11-20T00:00:40+00:00"}]
    host_text = "\n".join(
        f"{(datetime(2026, 11, 20, 0, 0, tzinfo=UTC) + timedelta(seconds=offset)).isoformat()} {idle_line}"
        for offset in (-1, 5, 11, 17, 23, 29, 35, 41)
    )
    load, minima = module.analyze_timed_load(host_text, timeline)
    assert load["status"] == "verified" and load["max_sample_gap_seconds"] == 6 and minima == [100.0]
    return {"status": "selftest_passed", "clock_free": True, "m1_anchor_schema_checked": True,
            "fixture_archive_driver_pin_checked": True, "approved_24_probe_parser_checked": True,
            "approved_timed_host_coverage_parser_checked": True}

def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    run = sub.add_parser("run")
    run.add_argument("--pins-json", type=Path, required=True)
    run.add_argument("--source-root", type=Path, required=True)
    run.add_argument("--binary", type=Path, required=True)
    run.add_argument("--output", type=Path, required=True)
    run.add_argument("--process-run", type=int, choices=(1, 2, 3), required=True)
    run.add_argument("--preflight-only", action="store_true")
    run.add_argument("--support-kit", type=Path)
    replay = sub.add_parser("replay")
    replay.add_argument("output", type=Path)
    replay.add_argument("--support-kit", type=Path)
    series = sub.add_parser("replay-series")
    series.add_argument("outputs", nargs="+", type=Path)
    series.add_argument("--support-kit", type=Path)
    self_test = sub.add_parser("selftest")
    self_test.add_argument("--support-kit", type=Path)
    args = parser.parse_args()
    set_support_kit(args.support_kit)
    if args.action == "run":
        try:
            result = attempt(args.pins_json, args.source_root, args.binary, args.output, args.process_run, args.preflight_only)
        except Exception as error:
            if args.output.exists() and args.output.is_dir():
                write_json(args.output / "failure.json", {"kind": type(error).__name__, "message": failure_reason(error),
                                                            "result": "failed_nonretryable"})
            result = {"result": "failed_nonretryable", "kind": type(error).__name__, "message": failure_reason(error)}
    elif args.action == "replay":
        result = replay_attempt(args.output)
    elif args.action == "replay-series":
        result = replay_series(args.outputs)
    else:
        result = selftest()
    print(json.dumps(result, indent=2, sort_keys=True))
    if args.action == "run" and result["result"] == "load_rejected_retryable":
        raise SystemExit(75)
    if args.action == "run" and result["result"] == "failed_nonretryable":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
