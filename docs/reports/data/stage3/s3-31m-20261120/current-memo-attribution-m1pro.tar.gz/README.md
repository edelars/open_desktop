# S3-31 current-memo V2 scoring evidence

Extract the evidence archive into a fresh directory and run the steps below from
its root. Use Python 3.11 or newer with assertions enabled. The replay reads the
retained files and does not start the benchmark or run a load probe.

```sh
python3 -B - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

root = Path.cwd()
manifest = json.loads((root / "manifest.json").read_bytes())
actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
expected = set(manifest["file_sha256"]) | {"manifest.json"}
assert actual == expected, (actual - expected, expected - actual)
for name, expected in manifest["file_sha256"].items():
    path = root / name
    assert path.is_file() and not path.is_symlink(), name
    assert sha256(path.read_bytes()).hexdigest() == expected, name
print(f"Verified {len(manifest['file_sha256'])} archived file digests.")
PY
```

`raw/control/` and `raw/series/` retain the original control files, schedule,
readiness and timed attempts, run and replay outputs, and first passing
selections. The raw report and fixture gzip files retain their original bytes.
`kit/` records the exact controller, signed-preflight anchor and signature
evidence, source patch, and source binding. `stage/` preserves the original
launcher, score script, and kit with its stage checksum manifest. The upstream
M1 capture digest and the original remote series path are in `manifest.json`.
The manifest records digests for macOS tar's AppleDouble sidecars separately
from the retained file contents.

When present, `diagnostic-controller-v1/` retains the earlier incomplete
controller capture and its own exact stage and controller. The diagnostic native
report finished, but the original controller stopped on a phase schema assertion
before it wrote a timed attempt receipt. The watcher also recorded idle below
the scoring floor. The diagnostic files are excluded from the replayed series
and the summary. Their upstream digest is listed separately in `manifest.json`.

## Restore the excluded sampler files

Git omits compiled output. Each omitted `host-load/cpu-idle` has its own
SHA-256 in `manifest.json`. Recreate the sampler from the retained C source on
Apple Silicon with Apple clang 15.0.0 (clang-1500.3.9.4) and macOS SDK 14.5.
The S3-30e recorded rebuild used the same source and produced the capture
digest with these flags. Its transcript is preserved under `audit/`.

```sh
archive_root=$(pwd -P)
replay_root=$(mktemp -d)
replay_root=$(cd "$replay_root" && pwd -P)
mkdir "$replay_root/sampler"
cp support/reference/short-windows-v1/runner-check/host-load/cpu_idle.c "$replay_root/sampler/"
(
  cd "$replay_root/sampler"
  MACOSX_DEPLOYMENT_TARGET=14.0 /usr/bin/clang \
    -std=c11 -O2 -Wall -Wextra -Werror cpu_idle.c -o cpu-idle
)
python3 -B - "$replay_root/sampler/cpu-idle" <<'PY'
from hashlib import sha256
import json
from pathlib import Path
import sys

manifest = json.loads(Path("manifest.json").read_bytes())
binary = Path(sys.argv[1]).read_bytes()
digest = sha256(binary).hexdigest()
for name, expected in manifest["omitted_reproducible_sampler_sha256"].items():
    assert digest == expected, (name, digest, expected)
for name in manifest["omitted_reproducible_sampler_sha256"]:
    with Path(name).open("xb") as target:
        target.write(binary)
print(f"Restored {len(manifest['omitted_reproducible_sampler_sha256'])} verified sampler files.")
PY
```

The sampler can be built on a separate machine with the specified toolchain
and copied to `$replay_root/sampler/cpu-idle` for digest verification. A
different Apple clang or SDK can produce different bytes.

## Replay and regenerate the summary

Place the controller and the five support assets in the approved relative
layout under a scratch root. Invoke the auditor with the controller, the
support kit, the extracted series, and the series location recorded on M1
in that order.

```sh
controller_dir="$replay_root/work/tmp/s3-31-current-memo-controller"
support_dir="$replay_root/work/tmp/s3-30-m1-base.uDY78ah3/allocator-runner-fifo-v1"
mkdir -p "$controller_dir" "$support_dir"
cp kit/controller.py "$controller_dir/"
cp -R support/. "$support_dir/"
remote_series=$(python3 -B -c 'import json; print(json.load(open("manifest.json"))["original_remote_series"])')
python3 -B audit/verify-series-record.py \
  "$controller_dir/controller.py" "$support_dir" "$archive_root/raw/series" "$remote_series"

python3 -B - "$replay_root/summary.json" <<'PY'
import json
from pathlib import Path
import subprocess
import sys

manifest = json.loads(Path("manifest.json").read_bytes())
with Path(sys.argv[1]).open("xb") as output:
    subprocess.run(
        [sys.executable, "-B", "audit/aggregate.py", *manifest["selected_reports"]],
        stdout=output,
        check=True,
    )
PY
cmp audit/summary.json "$replay_root/summary.json"
```

The auditor replays every attempt, reproduces the retained per-attempt
outputs, and recomputes the first passing selection in each run. The
summary pools the selected 20 pairs per run across the three runs within
each fixture and preserves the separate run distributions.

## User-authorized selection

If `manifest.json` records a user override, the primary `audit/summary.json`
uses round 3, attempt 1 by explicit user authorization. The automated result
for that attempt remains `load_rejected_retryable`. Its observed timed
overlap minimum was 79.0% against an 80.0% floor. The dedicated audit checks
the report from the pinned signed binary and the original replay, verifies
the approved coverage checks, and records the below-floor samples and
their count.

```sh
python3 -B audit/verify-user-selection.py \
  "$controller_dir/controller.py" "$support_dir" "$archive_root/raw/series" \
  > "$replay_root/user-override.json"
cmp audit/user-override.json "$replay_root/user-override.json"

python3 -B - "$replay_root/automated-summary.json" <<'PY'
import json
from pathlib import Path
import subprocess
import sys

manifest = json.loads(Path("manifest.json").read_bytes())
with Path(sys.argv[1]).open("xb") as output:
    subprocess.run(
        [sys.executable, "-B", "audit/aggregate.py", *manifest["automated_selected_reports"]],
        stdout=output,
        check=True,
    )
PY
cmp audit/automated-summary.json "$replay_root/automated-summary.json"
```

The automated selection and its summary remain available for comparison.
